/*
 * ViewBase.cpp
 *
 *  Created on: Oct 11, 2013
 *      Author: sam
 */

#include "ViewBase.h"

using namespace RLLibViz;

ViewBase::ViewBase(QWidget *parent) :
    QWidget(parent)
{
}

ViewBase::~ViewBase()
{
}
