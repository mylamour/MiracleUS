/* -*- mode: c++; c-basic-offset: 4; indent-tabs-mode: nil -*-

   this file is part of rcssserver3D
   Fri May 9 2003
   Copyright (C) 2002,2003 Koblenz University
   Copyright (C) 2003 RoboCup Soccer Server 3D Maintenance Group
   $Id: sparkmonitorlogfileserver_c.cpp 265 2011-03-27 21:47:57Z hedayat $

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; version 2 of the License.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#include "sparkmonitorlogfileserver.h"

using namespace std;
using namespace oxygen;

FUNCTION(SparkMonitorLogFileServer, setFileName)
{
    string inName;

    if (
        (in.GetSize() != 1) ||
        (! in.GetValue(in[0], inName))
        )
        {
            return false;
        }

    obj->SetFileName(inName);
    return true;
}

FUNCTION(SparkMonitorLogFileServer, pauseMode)
{
    if (in.GetSize() != 0)
        {
            return false;
        }

    obj->Pause();
    return true;
}

FUNCTION(SparkMonitorLogFileServer, stepForward)
{
    if (in.GetSize() != 0)
        {
            return false;
        }

    obj->ForwardStep();
    return true;
}

FUNCTION(SparkMonitorLogFileServer, stepBackward)
{
    if (in.GetSize() != 0)
        {
            return false;
        }

    obj->BackwardStep();
    return true;
}

FUNCTION(SparkMonitorLogFileServer, playBackward)
{
    if (in.GetSize() != 0)
        {
            return false;
        }

    obj->BackwardPlayback();
    return true;
}

void
CLASS(SparkMonitorLogFileServer)::DefineClass()
{
    DEFINE_BASECLASS(oxygen/SimControlNode);
    DEFINE_FUNCTION(setFileName);
    DEFINE_FUNCTION(pauseMode);
    DEFINE_FUNCTION(stepForward);
    DEFINE_FUNCTION(stepBackward);
    DEFINE_FUNCTION(playBackward);
}
