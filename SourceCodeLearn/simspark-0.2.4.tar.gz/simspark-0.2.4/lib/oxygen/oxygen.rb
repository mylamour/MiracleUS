#
# this is the init script of the Oxygen library
#

# (empty)
