#!/bin/bash
#
# RoboCup 2010 kill script for 3D soccer simulation
#

killall -9 gdut2013
