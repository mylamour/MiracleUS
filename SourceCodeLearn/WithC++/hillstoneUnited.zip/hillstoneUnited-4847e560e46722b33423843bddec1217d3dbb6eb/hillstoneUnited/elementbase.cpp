#include "elementbase.hpp"

ElementBase::ElementBase(){
  finish_flag = false;
}
