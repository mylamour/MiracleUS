#!/bin/sh

pkill -f hillstoneUnited

