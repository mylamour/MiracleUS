##hillstoneUnited readme  
hillstoneUnited is agent program of "Robocup 3D Simulation".  
Our purpose is studying. so robots might not be good soccer player.  
We develop this code in Ubuntu (12.04 is majority now).  
Our webpage is here. <http://hillstoneunited.github.com/hillstoneUnited>

##compiling  
please type following command at 'hillstoneUnited' directory (existing readme.md file).  
If you don't have some commands(like autoconf), you can install them from apt-get.

    $autoheader
    $aclocal
    $automake --add-missing
    $automake
    $autoconf
    $./configure
    $make

##license  
    rcssagent (sample agent of robocup 3d sim) is Copyright (C) 2003 Koblenz University

    ticktack is Copyright (C) 2009 Fukui University of Technology
    ODENS_3D is Copyright (C) 2012 Osaka Electro-Communication University
    hillstoneUnited is Copyright (C) 2009-2012 Keio University
    
    This program is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Public License as published by the Free Software
    Foundation; either version 2 of the License, or (at your option) any later
    version.
	
    This program is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
    FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
    details.
	
    You should have received a copy of the GNU General Public License along with
    this program; if not, write to the Free Software Foundation, Inc., 59 Temple
    Place, Suite 330, Boston, MA 02111-1307 USA