#include "canturnleft.ih"

rf<Behavior::Goal> CanTurnLeft::generateGoal(unsigned step, unsigned slot)
{
/*
  _debugLevel4("CanTurnLeft::generateGoal " << step << " " << slot);
  WorldModel& wm = WorldModel::getInstance();
  
  rf<Goal> goal = new Goal();
  rf<OrNode> dis = goal->addDisjunct();
  rf<AndNode> con = dis->addConjunct();

//  Vector3D normal = wm.getFieldNormal();

//  double angle = 0.0;

//  con->addVar("Angle", angle, angle);

  
  return goal;
*/
  return d_goal;
}
