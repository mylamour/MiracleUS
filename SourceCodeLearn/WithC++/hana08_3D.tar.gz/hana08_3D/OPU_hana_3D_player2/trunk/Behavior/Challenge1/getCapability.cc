#include "challenge1.ih"

Behavior::ConfidenceInterval Challenge1::getCapability(rf<State> s, rf<Goal> g)
{
  return ConfidenceInterval(0.5, 0.2);
}
