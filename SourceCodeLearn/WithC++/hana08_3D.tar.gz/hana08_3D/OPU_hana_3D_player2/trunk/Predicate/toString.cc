#include "predicate.hh"

using namespace bats;
using namespace std;

string Predicate::toString()
{
  std::ostringstream o;
  generate(o);
  return o.str();
}
