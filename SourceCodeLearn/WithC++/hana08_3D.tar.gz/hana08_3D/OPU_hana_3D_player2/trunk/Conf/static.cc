#include "conf.ih"

Conf* Conf::s_conf = 0;
