ccbuild build humanoidbat.cc --args " -Wall -D BATS_NO_DEBUG -O3 -D CVS" $@
