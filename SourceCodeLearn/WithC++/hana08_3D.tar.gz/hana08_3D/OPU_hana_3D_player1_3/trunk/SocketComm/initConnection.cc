#include "socketcomm.ih"

void SocketComm::initConnection()
{
  d_socket.setBlocking(true);
}
