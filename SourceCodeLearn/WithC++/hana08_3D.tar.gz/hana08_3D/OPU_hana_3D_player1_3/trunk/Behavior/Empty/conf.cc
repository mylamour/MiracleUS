
#include "empty.ih"
#include <iostream>
int main()
{
	Empty h("Empty");
	h.generateConf(cout);
	return 0;
}
