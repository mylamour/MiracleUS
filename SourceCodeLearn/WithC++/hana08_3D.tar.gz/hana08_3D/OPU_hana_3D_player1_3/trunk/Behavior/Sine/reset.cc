#include "sine.ih"

void Sine::reset()
{
  Behavior::reset();
  d_startTime = -1;
}

