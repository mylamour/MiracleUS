#include "goodposition.ih"

rf<Behavior::Goal> GoodPosition::generateGoal(unsigned step, unsigned slot)
{
  
  return d_goal;
}
