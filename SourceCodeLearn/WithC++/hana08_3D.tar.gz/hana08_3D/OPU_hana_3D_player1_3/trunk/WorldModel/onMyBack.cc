#include "worldmodel.ih"

bool WorldModel::onMyBack()
{
  return d_fieldNormal.getX() > 0.95 && d_gyro.length() < 2.0;
}

