#include "worldmodel.ih"

bool WorldModel::onMyBelly()
{
  return d_fieldNormal.getX() < -0.7 && d_gyro.length() < 2.0;
}

