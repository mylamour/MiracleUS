#include "normaldistribution3d.ih"

void NormalDistribution3D::calcDeterminant()
{
  /*  d_determinant = d_sigma[0] * d_sigma[4] * d_sigma[8] +
                  d_sigma[1] * d_sigma[5] * d_sigma[6] +
                  d_sigma[2] * d_sigma[3] * d_sigma[7] -
                  d_sigma[2] * d_sigma[4] * d_sigma[6] -
                  d_sigma[1] * d_sigma[3] * d_sigma[8] -
                  d_sigma[0] * d_sigma[5] * d_sigma[7];*/
}
