#!/bin/sh

xsltproc dobehave.xsl $1 | dot -Tjpeg | xview stdin
