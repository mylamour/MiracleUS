#include "input.ih"

Input *Input::s_instance(0);

