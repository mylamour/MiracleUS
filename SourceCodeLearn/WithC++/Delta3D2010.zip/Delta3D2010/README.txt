The first Delta3D source code has been released (, fully), which participated in GermanOpen2010.
The main skills (Walk and Turn) are adapted from Apollo3d source code, the architecture of the code is based on the Ziggurat base code and other parts are written by the member of the team.
Features:
- This is a full code that includes solutions for any issue and problems existing in the humanoid robot field (simulated by simspark).
- This code has very strong localization with only two flags.
- It has powerful skills (Walk, Turn, Standup and etc).
- It has powerful "stability reorganization� base on Gyro and FRP.
- It has a simple decision to play soccer (you must develop and make better it).
  And etc.

If you have any question about code, Please feel free to contact us directly with your response: kamektareen@yahoo.com
We wish you the best with your studies!

Best Regards
Saeid JafariZadeh
Arash Harang
