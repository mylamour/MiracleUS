/*
    <one line to give the program's name and a brief idea of what it does.>
    Copyright (C) <year>  <name of author>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/

#include "leg.h"

Leg::Leg()
{
}


Leg::~Leg()
{
}



void Leg::setValue(float j1, float j2, float j3, float j4, float j5, float j6){
	le1 = j1;
	le2 = j2;
	le3 = j3;
	le4 = j4;
	le5 = j5;
	le6 = j6;
}

float Leg::getlj1(){
	return le1;
}

float Leg::getlj2(){
	return le2;
}

float Leg::getlj3(){
	return le3;
}

float Leg::getlj4(){
	return le4;
}

	float Leg::getlj5(){
	return le5;
}

float Leg::getlj6(){
	return le6;
}

