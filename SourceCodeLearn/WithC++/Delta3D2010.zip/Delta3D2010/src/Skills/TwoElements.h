#ifndef TwoElements_H
#define TwoElements_H
#include <string>
#include <iostream>

using namespace std;

class  TwoElements{
public:
    TwoElements();

    ~TwoElements();
    
    static TwoElements& instance();
    
    static const TwoElements& i(){return instance();}

	float   Befor();
	
	float*  Location();
	
	void   Add(float item);



private:
//
	float   T[2];
	float   *point; 

	
};

#endif
