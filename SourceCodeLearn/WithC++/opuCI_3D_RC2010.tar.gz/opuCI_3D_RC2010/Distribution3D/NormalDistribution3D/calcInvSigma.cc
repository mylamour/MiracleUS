#include "normaldistribution3d.ih"

void NormalDistribution3D::calcInvSigma()
{
  /*  double *s = d_sigma;
  double f = 1.0 / d_determinant;
  
  d_invSigma[0] = f * s[4] * s[8] - s[5] * s[7];
  d_invSigma[1] = f * s[2] * s[7] - s[1] * s[8];
  d_invSigma[2] = f * s[1] * s[5] - s[2] * s[4];
  
  d_invSigma[3] = f * s[5] * s[6] - s[3] * s[8];
  d_invSigma[4] = f * s[0] * s[8] - s[2] * s[6];
  d_invSigma[5] = f * s[2] * s[3] - s[0] * s[5];
  
  d_invSigma[6] = f * s[3] * s[7] - s[4] * s[6];
  d_invSigma[7] = f * s[1] * s[6] - s[0] * s[7];
  d_invSigma[8] = f * s[0] * s[4] - s[1] * s[3];*/
}
