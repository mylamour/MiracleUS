
#include "logger.ih"

Logger *Logger::s_ptr(0);
bool Logger::s_disabled(true);
