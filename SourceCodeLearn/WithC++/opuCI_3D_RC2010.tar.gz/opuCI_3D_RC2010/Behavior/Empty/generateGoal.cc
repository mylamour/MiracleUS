#include "empty.ih"

rf<Behavior::Goal> Empty::generateGoal(unsigned step, unsigned slot)
{
  rf<Goal> goal = new Goal();
	return goal;
}
