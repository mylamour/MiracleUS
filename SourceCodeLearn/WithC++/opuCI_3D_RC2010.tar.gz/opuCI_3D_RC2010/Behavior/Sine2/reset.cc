#include "sine2.ih"

void Sine2::reset()
{
  Behavior::reset();
  d_startTime = -1;

}

