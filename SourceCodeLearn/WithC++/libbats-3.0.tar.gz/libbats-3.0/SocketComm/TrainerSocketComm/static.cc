#include "trainersocketcomm.ih"

using namespace bats;

unsigned TrainerSocketComm::port = 3200;
