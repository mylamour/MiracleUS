#include "playerclass.ih"

PlayerClass::PCMap PlayerClass::s_playerClasses;
