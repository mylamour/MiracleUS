#include "HelloWorldAgent/helloworldagent.hh"

int main()
{
  HelloWorldAgent agent;
  agent.run();
}

