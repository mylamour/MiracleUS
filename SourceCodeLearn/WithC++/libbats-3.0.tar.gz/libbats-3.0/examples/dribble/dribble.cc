#include "DribbleAgent/dribbleagent.hh"

int main()
{
  DribbleAgent agent;
  agent.run();
}

