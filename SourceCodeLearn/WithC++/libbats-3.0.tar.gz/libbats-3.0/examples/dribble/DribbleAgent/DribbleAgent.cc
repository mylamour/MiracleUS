#include "dribbleagent.ih"

DribbleAgent::DribbleAgent()
  : HumanoidAgent("Dribble", "../../xml/conf.xml"),
    d_beamed(false)
{
}
