
#include "agentmodel.ih"

void AgentModel::setUnum(unsigned int const u)
 { d_unum = u; }
