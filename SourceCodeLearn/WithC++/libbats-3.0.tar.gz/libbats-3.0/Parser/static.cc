#include "parser.ih"

Parser::ParseEntry Parser::s_unifiedTable[256*16];

unsigned long long Parser::s_counters[6] = {0,0,0,0,0,0};
