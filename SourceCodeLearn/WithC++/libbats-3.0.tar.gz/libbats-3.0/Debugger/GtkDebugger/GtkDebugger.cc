#include "gtkdebugger.ih"

GtkDebugger::GtkDebugger()
: d_running(false),
  d_ticks(0)
{
}

