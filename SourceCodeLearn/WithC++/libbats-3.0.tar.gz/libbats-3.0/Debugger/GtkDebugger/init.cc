#include "gtkdebugger.ih"

void GtkDebugger::init(int argc, char** argv)
{

}

