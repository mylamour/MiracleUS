#include "robovizdebugger.ih"

void RoboVizDebugger::onThinkEnd()
{
  reDraw();
}

