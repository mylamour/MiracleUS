#include "predicate.ih"

unsigned Predicate::s_predCount = 0;

void Predicate::destroy()
{
  --s_predCount;
  //cerr << "predCount: " << s_predCount << endl;
}
