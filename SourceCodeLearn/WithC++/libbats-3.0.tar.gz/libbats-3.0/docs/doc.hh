#error This file is for Doxygen only; do not include

/**
   @defgroup agent Agent
   Everything you need to quickly create a working agent

   Blabladhygsd
*/

/**
   @defgroup communication Server Communication
   Down and dirty: low level communication stuff
*/

/**
   @defgroup localization Localization
   How to figure out where everything is
*/

/**
   @defgroup control Controlling
   The stuff to make your agent move
*/

/**
   @defgroup configuration Configuration
   The libbats XML configuration module
*/

/**
   @defgroup debugging Debugging
   Some things to show you what is going wrong
 */
