#include "random.ih"

void Random::seed(unsigned s)
{
  srand(s);
}

