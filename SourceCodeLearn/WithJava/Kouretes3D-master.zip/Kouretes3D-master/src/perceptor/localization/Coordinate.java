/*******************************************************************************
 * Technical University of Crete
 * 
 * Thesis Project
 * 
 * Author:	Methenitis K. Georgios
 * 
 * Abstract  : Player Behavior and Team Strategy 
 * 			for the RoboCup 3D Simulation League
 * 
 * Date:  		July 2012
 ******************************************************************************/
package perceptor.localization;

public class Coordinate {
	public double X, Y;

	public Coordinate(double x, double y) {
		X = x;
		Y = y;
	}

	public double getX() {
		return X;
	}

	public void setX(double x) {
		X = x;
	}

	public double getY() {
		return Y;
	}

	public void setY(double y) {
		Y = y;
	}

	public static Coordinate addCoordinate(Coordinate a, Coordinate b) {

		Coordinate c = new Coordinate((a.X + b.X), (b.Y + b.Y));

		return c;

	}

}
