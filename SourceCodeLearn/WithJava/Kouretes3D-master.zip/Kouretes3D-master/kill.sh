# Kill agents
AGENT="AST_3D"
killall -9 $AGENT
sleep 1
