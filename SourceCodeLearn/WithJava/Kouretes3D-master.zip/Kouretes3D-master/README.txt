Kouretes3D

Compatibility:
rcssserver3d 0.6.5
simspark 0.2.2

Third Party Libraries:
commons-lang-2.6.jar (Apache Commons)
jts-1.8.jar (com.vividsolutions)
vecmath.jar (Java3D Team)

-- Instructions for running agent --
Run full team:
./start.sh <host>

Kill team:
./kill.sh

*************************************************************************************
*XML Motion files were created by FIIT RoboCup 3D team.
*Classic Motion files from WEBOTS SoccerStadium simulator and from TUC's Kuretes SPL team.
*************************************************************************************
 
