package com.bexp;


/**
 * 
 * This class is now only a tag to indicate centralized exception handler to not to print stack trace.
 *
 */
public class BEXPException extends Exception implements java.io.Serializable

{
	String msg;
    public BEXPException(String _statement)
        {
        super(_statement);
        msg = _statement;
        }
    public BEXPException(String _statement, String _msg)
	    {
	    super(_statement);
	    msg = _msg;
	    }
    public String getDetailedMessage()
    	{ return msg; }
}
