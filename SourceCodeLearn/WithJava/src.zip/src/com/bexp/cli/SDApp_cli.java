package com.bexp.cli;

import com.bexp.*;
import com.bexp.ejb.*;
import org.JWrapper.*;

import java.io.*;
import java.util.*;

public class SDApp_cli
    extends SDApp
{
    public SDApp_cli() throws Exception
        {
        super();
        }

    public void run(String[] args) throws Exception
        {
        if(args.length==0)
            {
            System.out.println(usage);
            //  String.
            System.exit(0);
            }
                
        ObjSession.getSession().connect(args[0],args[1],args[2]);
        //Thread.sleep(3000);
        readSiteMap();
        //Thread.sleep(1000);
        
        String command = args[3];
        //System.out.println("emap= "+getEntitiesMap());//testing
        if(command.equals("readfile"))
            {
            BufferedReader reader = new BufferedReader(new FileReader(args[4]));
            while(reader.ready())
                {
                String line = reader.readLine();
                System.out.println("---"+line);//testing
                interpret(line.split("\\s"));
                }
            } else
            {
            String[] subargs = new String[args.length-3];
            for(int i=3; i<args.length; i++)
                { subargs[i-3]=args[i]; }
            interpret(subargs);
            }
        System.exit(0);
        }
    
public void interpret(String[] args) throws Exception
    {   
    String command = args[0];
    if(args.length==1) {throw new Exception("Specify an entity!");}
    EntityWrpSrc src =
        getEntitiesMap().get(Class.forName("com.bexp.ejb."+args[1]+".SDObj").getPackage());
    
    if(command.equals("view"))
    {
    System.out.println("view selected");//testing
    System.out.println(getEntitiesMap().size());//testing
    JCompositeWrapper result = src.createDefaultWrapper(src.defaultObjSrc);
    for(int i=0; i<result.size(); i++)
        {
        JWrapper cw = result.getWrapper(i);
        System.out.println("---");
    for(JWrapper wrp : ((JCompositeWrapper)cw).getChildren())
        {
        System.out.println(wrp);
        }
        System.out.println("+++");
    //System.out.println(result);
        }
    }
        else
    if(command.equals("create"))
    {
    System.out.println("create selected");//testing
    //JCompositeWrapper result = src.createDefaultWrapper(src.defaultObjSrc);
    Obj result =
        ObjSession.getSession().getHome(Class.forName("com.bexp.ejb."+args[1]+".SDObj"))
            .createObj();
    JCompositeWrapper wrp = src.getDefaultInfo().getDefaultWrapper(result);
        for(int i=0; i<wrp.getChildren().length; i++)
            try
            {
            System.out.println("Setting "+wrp.getChildren()[i].getName());
            ((JLeafWrapper)wrp.getChildren()[i]).setValue(args[2+i]);
            } catch(Exception ex) { System.out.println("*/"); }
    result.save();
    System.out.println(result);
    }
    else
        if(command.equals("delete"))
        {
        System.out.println("delete selected");//testing
        //JCompositeWrapper result = src.createDefaultWrapper(src.defaultObjSrc);
            ObjSession.getSession().getHome(Class.forName("com.bexp.ejb."+args[1]+".SDObj"))
                .delete(new Long(args[2]));
        System.out.println("Object deleted");
        }
    }
    
    protected boolean isInteractive()
        { return false; }
    
@Override
public boolean confirm(String str) {
    // TODO Auto-generated method stub
    return false;
}

@Override
protected SDDialog createDialog(JWrapper wrp, SDDialog parent, boolean modal) throws Exception {
    // TODO Auto-generated method stub
    return null;
}

@Override
protected Pair<SDDialog, function0<List<JWrapper> >> getStockWrappersSelector(JCompositeWrapper cw) throws Exception {
    // TODO Auto-generated method stub
    return null;
}

@Override
public java.util.List<JWrapper> selectWrappers(JCompositeWrapper cw) throws Exception {
    // TODO Auto-generated method stub
    return null;
}

@Override
public java.util.List<JWrapper> selectWrappers(JDiscreteWrapper<JHomeDynamicCompositeWrapper> dw) throws Exception {
    // TODO Auto-generated method stub
    return null;
}

@Override
protected void show_single_wrapper(JLeafWrapper _ref_wrp, JHomeDynamicCompositeWrapper _dcwrp, function0<Void> _edit_f) throws Exception {
    // TODO Auto-generated method stub
    
}

@Override
public void showDocumentation() {
    // TODO Auto-generated method stub
    
}

@Override
public void showWrapper(JWrapper wrp) {
    // TODO Auto-generated method stub
    
}

public void setWaitingState(boolean wait) {
    // TODO Auto-generated method stub
    
}

final static String usage = "java -cp run.jar com.bexp.cli.main host user passwd command [args]";

}
