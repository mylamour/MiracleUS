package com.bexp;

import com.bexp.ASSERT.Alerter;

public class DefaultAlerter implements Alerter
{
public DefaultAlerter() {}
public void alert(Object subject)
    {
    System.out.println(subject);
    if(subject instanceof Exception)
        {System.out.println(((Exception)subject).getCause());}
    }
public void alert(Object source, Object subject)
    {
    System.out.print(source.getClass().getName());
    System.out.print(":");
    alert(subject);
    }

public void setWaitingState(boolean wait)
    {
    if(wait)
        { System.out.println("Wait..."); }
    else
        { System.out.println("Done."); }
    }
public boolean confirm(String str) throws Exception
    {
    System.out.println(str);
    System.out.println("(yes/no)?");
    // to be done
    if(true) {throw new Exception("not supported");}
    return false;
    }

};
