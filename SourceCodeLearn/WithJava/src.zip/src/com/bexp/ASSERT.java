package com.bexp;


import java.lang.*;

public class ASSERT
{
    public interface Alerter
	{
	public void alert(Object subject);
	public void alert(Object source, Object subject);
    public boolean confirm(String str) throws Exception;
    public void setWaitingState(boolean wait);
	};
	
    private static Alerter alerter;
    private static boolean debug = (System.getenv("bexpdebug")!=null)?(System.getenv("bexpdebug").equals("1")):false;

    private ASSERT(){  }
    
    public static void alert(Object subject)
        {
        try{ getAlerter().alert(subject); }
        catch(Throwable ex) { getAlerter().alert(ex); }
        }
    public static void alert(Object source,Object subject)
        {
        try{ getAlerter().alert(source,subject); }
        catch(Throwable ex) { getAlerter().alert(ex); }
        }
    public static void debug(Object source,Object subject)
        {
        if(debug)
        try{ System.out.println("~DEBUG~: "+source+" : "+subject);  }
        catch(Throwable ex) { getAlerter().alert(ex); }
        }
    public static boolean isDebugEnabled()
        {
        return debug;
        }
    public static boolean confirm(String str) throws Exception
        {
        return getAlerter().confirm(str);
        }
    
    static Integer waiters = new Integer(0);
    
    public static void setWaitingState(boolean state)
        {
        synchronized(waiters)
        {
        if(state) { waiters++; } else { if(waiters>0) {waiters--;} }
        if(waiters>0)
            { getAlerter().setWaitingState(true); }
        else
            { getAlerter().setWaitingState(false); }
        }
        }
    public static Alerter getAlerter()
        {
        if(alerter==null) { alerter=new DefaultAlerter(); }
        return alerter;
        }
    public static void setAlerter(Alerter _alerter)
        { alerter=_alerter; }
}
