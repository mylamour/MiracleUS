package com.bexp.ejb.Location.Street;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.IObj
{

 



    public ObjHandle<com.bexp.ejb.Location.City.SDObj> getCity() throws Exception;
    public void setCity(ObjHandle<com.bexp.ejb.Location.City.SDObj> handle) throws Exception;



    public Set<ObjHandle<com.bexp.ejb.Location.Building.SDObj> > getBuildings();
	public void setBuildings(Set<ObjHandle<com.bexp.ejb.Location.Building.SDObj> > _arg) throws Exception;




//---------------------------------------------------------------------------------
}