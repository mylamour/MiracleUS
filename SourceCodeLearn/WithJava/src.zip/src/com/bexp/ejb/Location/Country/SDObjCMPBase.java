package com.bexp.ejb.Location.Country;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.Location.Country.SDObjCMPBase")
@Table(name = "Country")
public class SDObjCMPBase
    extends com.bexp.ejb.ObjCMPBean
    implements ISDObj,java.io.Serializable
{
   

 





    @Transient
public Set<ObjHandle<com.bexp.ejb.Location.City.SDObj> > getCitys()
 {
        return Obj.ObjsToHandles(this.getCitysCMPs(),
            com.bexp.ejb.Location.City.SDObj.class, false);
        }
public void setCitys(Set<ObjHandle<com.bexp.ejb.Location.City.SDObj> > handles) throws Exception
 {
      setOneToMany(this.getCitysCMPs(),
             handles, com.bexp.ejb.Location.City.SDObjCMPBase.class,
                new function2<Void,com.bexp.ejb.Location.City.SDObjCMPBase, SDObjCMPBase>()
                {public Void Op(com.bexp.ejb.Location.City.SDObjCMPBase owner_cmp,SDObjCMPBase cmp)
                    { owner_cmp.setCountryCMP(cmp); return null; }}
             ,false);
 }
    
        java.util.Set<com.bexp.ejb.Location.City.SDObjCMPBase> citysCMPs;
    @OneToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH,mappedBy="countryCMP")
    public Set<com.bexp.ejb.Location.City.SDObjCMPBase> getCitysCMPs()
        { return citysCMPs; }
    public void setCitysCMPs (Set<com.bexp.ejb.Location.City.SDObjCMPBase> cmps)
        { citysCMPs = cmps;}   
//------------------------------------------------------------------------------            



//---------------------------------------------------------------------------------
}

