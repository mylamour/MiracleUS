package com.bexp.ejb.Location.City;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.Obj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.Location.City.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.Location.City";
    

//---------------------------------------------------------------------------------------





    ObjHandle<com.bexp.ejb.Location.Country.SDObj> country
            = new ObjHandle<com.bexp.ejb.Location.Country.SDObj>(null,false,com.bexp.ejb.Location.Country.SDObj.class);
    public ObjHandle<com.bexp.ejb.Location.Country.SDObj> getCountry() throws Exception
        {
        return country;
        }
    public void setCountry(ObjHandle<com.bexp.ejb.Location.Country.SDObj> handle) throws Exception
        {
        country.copy(handle);
        country.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    Set<ObjHandle<com.bexp.ejb.Location.Street.SDObj> > streets = new CopyOnWriteArraySet();    
    public Set<ObjHandle<com.bexp.ejb.Location.Street.SDObj> > getStreets()
        { return streets; }
    public void setStreets(Set<ObjHandle<com.bexp.ejb.Location.Street.SDObj> > _arg) throws Exception
        { streets.clear(); if(_arg!=null) {streets.addAll(_arg);} }                        
        
//---------------------------------------------------------------------------------------




//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}