package com.bexp.ejb.Location.City;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.Location.City.SDObjCMPBase")
@Table(name = "City")
public class SDObjCMPBase
    extends com.bexp.ejb.ObjCMPBean
    implements ISDObj,java.io.Serializable
{
   

 



    @Transient
    public ObjHandle<com.bexp.ejb.Location.Country.SDObj> getCountry() throws Exception
        {
        ObjCMPBean cmp = getCountryCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Location.Country.SDObj>(cmp,com.bexp.ejb.Location.Country.SDObj.class);
        }
    public void setCountry(ObjHandle<com.bexp.ejb.Location.Country.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setCountryCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Location.Country.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.Location.Country.SDObjCMPBase countryCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Location.Country.SDObjCMPBase getCountryCMP()
        { return countryCMP; }
    public void setCountryCMP(com.bexp.ejb.Location.Country.SDObjCMPBase cicmp)
        { countryCMP = cicmp; }
//------------------------------------------------------------------------------



    @Transient
public Set<ObjHandle<com.bexp.ejb.Location.Street.SDObj> > getStreets()
 {
        return Obj.ObjsToHandles(this.getStreetsCMPs(),
            com.bexp.ejb.Location.Street.SDObj.class, false);
        }
public void setStreets(Set<ObjHandle<com.bexp.ejb.Location.Street.SDObj> > handles) throws Exception
 {
      setOneToMany(this.getStreetsCMPs(),
             handles, com.bexp.ejb.Location.Street.SDObjCMPBase.class,
                new function2<Void,com.bexp.ejb.Location.Street.SDObjCMPBase, SDObjCMPBase>()
                {public Void Op(com.bexp.ejb.Location.Street.SDObjCMPBase owner_cmp,SDObjCMPBase cmp)
                    { owner_cmp.setCityCMP(cmp); return null; }}
             ,false);
 }
    
        java.util.Set<com.bexp.ejb.Location.Street.SDObjCMPBase> streetsCMPs;
    @OneToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH,mappedBy="cityCMP")
    public Set<com.bexp.ejb.Location.Street.SDObjCMPBase> getStreetsCMPs()
        { return streetsCMPs; }
    public void setStreetsCMPs (Set<com.bexp.ejb.Location.Street.SDObjCMPBase> cmps)
        { streetsCMPs = cmps;}   
//------------------------------------------------------------------------------            



//---------------------------------------------------------------------------------
}

