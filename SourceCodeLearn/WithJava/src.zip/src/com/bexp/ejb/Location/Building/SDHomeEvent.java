package com.bexp.ejb.Location.Building;

import com.bexp.ejb.*;

public class SDHomeEvent
extends ObjHomeEvent<ISDObj>
implements java.io.Serializable
{
    public SDHomeEvent()
        {}
    
    protected SDHomeEvent(ISDObj obj, Object _parentPK, int event_id)
        {
        super(obj, event_id);
        parentPK = _parentPK; 
        }
    
        Object parentPK;
    public Object getParentPK()
        { return parentPK; }
    public void setParentPK(Object _pk)
        { parentPK = _pk; }
}
