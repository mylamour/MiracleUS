package com.bexp.ejb.Location.Street;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.Location.Street.SDObjCMPBase")
@Table(name = "Street")
public class SDObjCMPBase
    extends com.bexp.ejb.ObjCMPBean
    implements ISDObj,java.io.Serializable
{
   

 



    @Transient
    public ObjHandle<com.bexp.ejb.Location.City.SDObj> getCity() throws Exception
        {
        ObjCMPBean cmp = getCityCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Location.City.SDObj>(cmp,com.bexp.ejb.Location.City.SDObj.class);
        }
    public void setCity(ObjHandle<com.bexp.ejb.Location.City.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setCityCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Location.City.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.Location.City.SDObjCMPBase cityCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Location.City.SDObjCMPBase getCityCMP()
        { return cityCMP; }
    public void setCityCMP(com.bexp.ejb.Location.City.SDObjCMPBase cicmp)
        { cityCMP = cicmp; }
//------------------------------------------------------------------------------



    @Transient
public Set<ObjHandle<com.bexp.ejb.Location.Building.SDObj> > getBuildings()
 {
        return Obj.ObjsToHandles(this.getBuildingsCMPs(),
            com.bexp.ejb.Location.Building.SDObj.class, false);
        }
public void setBuildings(Set<ObjHandle<com.bexp.ejb.Location.Building.SDObj> > handles) throws Exception
 {
      setOneToMany(this.getBuildingsCMPs(),
             handles, com.bexp.ejb.Location.Building.SDObjCMPBase.class,
                new function2<Void,com.bexp.ejb.Location.Building.SDObjCMPBase, SDObjCMPBase>()
                {public Void Op(com.bexp.ejb.Location.Building.SDObjCMPBase owner_cmp,SDObjCMPBase cmp)
                    { owner_cmp.setStreetCMP(cmp); return null; }}
             ,false);
 }
    
        java.util.Set<com.bexp.ejb.Location.Building.SDObjCMPBase> buildingsCMPs;
    @OneToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH,mappedBy="streetCMP")
    public Set<com.bexp.ejb.Location.Building.SDObjCMPBase> getBuildingsCMPs()
        { return buildingsCMPs; }
    public void setBuildingsCMPs (Set<com.bexp.ejb.Location.Building.SDObjCMPBase> cmps)
        { buildingsCMPs = cmps;}   
//------------------------------------------------------------------------------            



//---------------------------------------------------------------------------------
}

