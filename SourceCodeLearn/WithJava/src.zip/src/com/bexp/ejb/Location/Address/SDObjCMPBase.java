package com.bexp.ejb.Location.Address;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.Location.Address.SDObjCMPBase")
@Table(name = "Address")
public class SDObjCMPBase
    extends com.bexp.ejb.ObjCMPBean
    implements ISDObj,java.io.Serializable
{
   
	protected java.lang.String RoomNumber;
	public java.lang.String getRoomNumber() {
	 return RoomNumber;  	 
	 }
	public void setRoomNumber(java.lang.String locRoomNumber) throws Exception { 
	RoomNumber=locRoomNumber;
	}	


 



    @Transient
    public ObjHandle<com.bexp.ejb.Location.Street.SDObj> getStreet() throws Exception
        {
        ObjCMPBean cmp = getStreetCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Location.Street.SDObj>(cmp,com.bexp.ejb.Location.Street.SDObj.class);
        }
    public void setStreet(ObjHandle<com.bexp.ejb.Location.Street.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setStreetCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Location.Street.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.Location.Street.SDObjCMPBase streetCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Location.Street.SDObjCMPBase getStreetCMP()
        { return streetCMP; }
    public void setStreetCMP(com.bexp.ejb.Location.Street.SDObjCMPBase cicmp)
        { streetCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.Location.Building.SDObj> getBuilding() throws Exception
        {
        ObjCMPBean cmp = getBuildingCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Location.Building.SDObj>(cmp,com.bexp.ejb.Location.Building.SDObj.class);
        }
    public void setBuilding(ObjHandle<com.bexp.ejb.Location.Building.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setBuildingCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Location.Building.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.Location.Building.SDObjCMPBase buildingCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Location.Building.SDObjCMPBase getBuildingCMP()
        { return buildingCMP; }
    public void setBuildingCMP(com.bexp.ejb.Location.Building.SDObjCMPBase cicmp)
        { buildingCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.Location.City.SDObj> getCity() throws Exception
        {
        ObjCMPBean cmp = getCityCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Location.City.SDObj>(cmp,com.bexp.ejb.Location.City.SDObj.class);
        }
    public void setCity(ObjHandle<com.bexp.ejb.Location.City.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setCityCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Location.City.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.Location.City.SDObjCMPBase cityCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Location.City.SDObjCMPBase getCityCMP()
        { return cityCMP; }
    public void setCityCMP(com.bexp.ejb.Location.City.SDObjCMPBase cicmp)
        { cityCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.Location.Country.SDObj> getCountry() throws Exception
        {
        ObjCMPBean cmp = getCountryCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Location.Country.SDObj>(cmp,com.bexp.ejb.Location.Country.SDObj.class);
        }
    public void setCountry(ObjHandle<com.bexp.ejb.Location.Country.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setCountryCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Location.Country.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.Location.Country.SDObjCMPBase countryCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Location.Country.SDObjCMPBase getCountryCMP()
        { return countryCMP; }
    public void setCountryCMP(com.bexp.ejb.Location.Country.SDObjCMPBase cicmp)
        { countryCMP = cicmp; }
//------------------------------------------------------------------------------






//---------------------------------------------------------------------------------
}

