package com.bexp.ejb.Location.Address;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.IObj
{
    public java.lang.String getRoomNumber();
    public void setRoomNumber(java.lang.String locRoomNumber) throws Exception;


 



    public ObjHandle<com.bexp.ejb.Location.Street.SDObj> getStreet() throws Exception;
    public void setStreet(ObjHandle<com.bexp.ejb.Location.Street.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.Location.Building.SDObj> getBuilding() throws Exception;
    public void setBuilding(ObjHandle<com.bexp.ejb.Location.Building.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.Location.City.SDObj> getCity() throws Exception;
    public void setCity(ObjHandle<com.bexp.ejb.Location.City.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.Location.Country.SDObj> getCountry() throws Exception;
    public void setCountry(ObjHandle<com.bexp.ejb.Location.Country.SDObj> handle) throws Exception;






//---------------------------------------------------------------------------------
}