package com.bexp.ejb.Location.Building;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.IObj
{

 



    public ObjHandle<com.bexp.ejb.Location.Street.SDObj> getStreet() throws Exception;
    public void setStreet(ObjHandle<com.bexp.ejb.Location.Street.SDObj> handle) throws Exception;






//---------------------------------------------------------------------------------
}