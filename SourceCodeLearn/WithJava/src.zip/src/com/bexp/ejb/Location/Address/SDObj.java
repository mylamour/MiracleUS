package com.bexp.ejb.Location.Address;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.Obj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.Location.Address.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.Location.Address";
    
	protected java.lang.String RoomNumber;
	public java.lang.String getRoomNumber() {
	 return RoomNumber;  	 
	 }
	public void setRoomNumber(java.lang.String locRoomNumber) throws Exception { 
	RoomNumber=locRoomNumber;
	}	


//---------------------------------------------------------------------------------------





    ObjHandle<com.bexp.ejb.Location.Street.SDObj> street
            = new ObjHandle<com.bexp.ejb.Location.Street.SDObj>(null,false,com.bexp.ejb.Location.Street.SDObj.class);
    public ObjHandle<com.bexp.ejb.Location.Street.SDObj> getStreet() throws Exception
        {
        return street;
        }
    public void setStreet(ObjHandle<com.bexp.ejb.Location.Street.SDObj> handle) throws Exception
        {
        street.copy(handle);
        street.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.Location.Building.SDObj> building
            = new ObjHandle<com.bexp.ejb.Location.Building.SDObj>(null,false,com.bexp.ejb.Location.Building.SDObj.class);
    public ObjHandle<com.bexp.ejb.Location.Building.SDObj> getBuilding() throws Exception
        {
        return building;
        }
    public void setBuilding(ObjHandle<com.bexp.ejb.Location.Building.SDObj> handle) throws Exception
        {
        building.copy(handle);
        building.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.Location.City.SDObj> city
            = new ObjHandle<com.bexp.ejb.Location.City.SDObj>(null,false,com.bexp.ejb.Location.City.SDObj.class);
    public ObjHandle<com.bexp.ejb.Location.City.SDObj> getCity() throws Exception
        {
        return city;
        }
    public void setCity(ObjHandle<com.bexp.ejb.Location.City.SDObj> handle) throws Exception
        {
        city.copy(handle);
        city.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.Location.Country.SDObj> country
            = new ObjHandle<com.bexp.ejb.Location.Country.SDObj>(null,false,com.bexp.ejb.Location.Country.SDObj.class);
    public ObjHandle<com.bexp.ejb.Location.Country.SDObj> getCountry() throws Exception
        {
        return country;
        }
    public void setCountry(ObjHandle<com.bexp.ejb.Location.Country.SDObj> handle) throws Exception
        {
        country.copy(handle);
        country.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------





//---------------------------------------------------------------------------------


    public void save() throws Exception
    {

     super.save();
    }
}