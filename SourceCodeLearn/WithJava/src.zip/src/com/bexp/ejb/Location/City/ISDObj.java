package com.bexp.ejb.Location.City;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.IObj
{

 



    public ObjHandle<com.bexp.ejb.Location.Country.SDObj> getCountry() throws Exception;
    public void setCountry(ObjHandle<com.bexp.ejb.Location.Country.SDObj> handle) throws Exception;



    public Set<ObjHandle<com.bexp.ejb.Location.Street.SDObj> > getStreets();
	public void setStreets(Set<ObjHandle<com.bexp.ejb.Location.Street.SDObj> > _arg) throws Exception;




//---------------------------------------------------------------------------------
}