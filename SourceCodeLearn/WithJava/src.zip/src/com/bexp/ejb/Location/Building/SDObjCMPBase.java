package com.bexp.ejb.Location.Building;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.Location.Building.SDObjCMPBase")
@Table(name = "Building")
public class SDObjCMPBase
    extends com.bexp.ejb.ObjCMPBean
    implements ISDObj,java.io.Serializable
{
   

 



    @Transient
    public ObjHandle<com.bexp.ejb.Location.Street.SDObj> getStreet() throws Exception
        {
        ObjCMPBean cmp = getStreetCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Location.Street.SDObj>(cmp,com.bexp.ejb.Location.Street.SDObj.class);
        }
    public void setStreet(ObjHandle<com.bexp.ejb.Location.Street.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setStreetCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Location.Street.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.Location.Street.SDObjCMPBase streetCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Location.Street.SDObjCMPBase getStreetCMP()
        { return streetCMP; }
    public void setStreetCMP(com.bexp.ejb.Location.Street.SDObjCMPBase cicmp)
        { streetCMP = cicmp; }
//------------------------------------------------------------------------------






//---------------------------------------------------------------------------------
}

