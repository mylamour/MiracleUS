package com.bexp.ejb.Location.Street;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.Obj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.Location.Street.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.Location.Street";
    

//---------------------------------------------------------------------------------------





    ObjHandle<com.bexp.ejb.Location.City.SDObj> city
            = new ObjHandle<com.bexp.ejb.Location.City.SDObj>(null,false,com.bexp.ejb.Location.City.SDObj.class);
    public ObjHandle<com.bexp.ejb.Location.City.SDObj> getCity() throws Exception
        {
        return city;
        }
    public void setCity(ObjHandle<com.bexp.ejb.Location.City.SDObj> handle) throws Exception
        {
        city.copy(handle);
        city.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    Set<ObjHandle<com.bexp.ejb.Location.Building.SDObj> > buildings = new CopyOnWriteArraySet();    
    public Set<ObjHandle<com.bexp.ejb.Location.Building.SDObj> > getBuildings()
        { return buildings; }
    public void setBuildings(Set<ObjHandle<com.bexp.ejb.Location.Building.SDObj> > _arg) throws Exception
        { buildings.clear(); if(_arg!=null) {buildings.addAll(_arg);} }                        
        
//---------------------------------------------------------------------------------------




//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}