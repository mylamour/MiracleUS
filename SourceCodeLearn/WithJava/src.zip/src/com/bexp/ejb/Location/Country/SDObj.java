package com.bexp.ejb.Location.Country;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.Obj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.Location.Country.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.Location.Country";
    

//---------------------------------------------------------------------------------------





    Set<ObjHandle<com.bexp.ejb.Location.City.SDObj> > citys = new CopyOnWriteArraySet();    
    public Set<ObjHandle<com.bexp.ejb.Location.City.SDObj> > getCitys()
        { return citys; }
    public void setCitys(Set<ObjHandle<com.bexp.ejb.Location.City.SDObj> > _arg) throws Exception
        { citys.clear(); if(_arg!=null) {citys.addAll(_arg);} }                        
        
//---------------------------------------------------------------------------------------




//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}