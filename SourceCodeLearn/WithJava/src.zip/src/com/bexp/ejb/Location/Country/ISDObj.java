package com.bexp.ejb.Location.Country;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.IObj
{

 





    public Set<ObjHandle<com.bexp.ejb.Location.City.SDObj> > getCitys();
	public void setCitys(Set<ObjHandle<com.bexp.ejb.Location.City.SDObj> > _arg) throws Exception;




//---------------------------------------------------------------------------------
}