package com.bexp.ejb.Location.Building;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.Obj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.Location.Building.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.Location.Building";
    

//---------------------------------------------------------------------------------------





    ObjHandle<com.bexp.ejb.Location.Street.SDObj> street
            = new ObjHandle<com.bexp.ejb.Location.Street.SDObj>(null,false,com.bexp.ejb.Location.Street.SDObj.class);
    public ObjHandle<com.bexp.ejb.Location.Street.SDObj> getStreet() throws Exception
        {
        return street;
        }
    public void setStreet(ObjHandle<com.bexp.ejb.Location.Street.SDObj> handle) throws Exception
        {
        street.copy(handle);
        street.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------





//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}