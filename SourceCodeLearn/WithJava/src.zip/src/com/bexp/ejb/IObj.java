package com.bexp.ejb;
import java.util.*;

//import org.jboss.aspects.security.*;

/* Are annotations inheritable/overridable ???!!! :( */

//@SecurityDomain("other")//seems like ignored in subclasses
public interface IObj extends java.io.Serializable
{
    public Object getPK();
    public void setPK(Object _PK);
    
    public boolean getIsInTrash();
    public void setIsInTrash(boolean P);
    
    public java.util.Date getCreationTime();
    public void setCreationTime(java.util.Date ctime);//only for glue
    
    public String getDescription() throws Exception;
    //@RolesAllowed({"bexp_admins"})//ignored
    public void setDescription(String descr) throws Exception;
    /*
    public Set<com.bexp.ejb.HistoryItem.ISDObj> getHistory() throws Exception;
    public void setHistory(Set<com.bexp.ejb.HistoryItem.ISDObj> history) throws Exception;//only for glue
    */
    /*
    @Deprecated
    public Set getHistoryPKs() throws Exception;
    @Deprecated
    public void setHistoryPKs(Set historyPKs) throws Exception;//only for glue
    */
    public LazyCollectionAccessAdapter<com.bexp.ejb.HistoryItem.SDObj,ObjCMPBean>
        getHistoryItems() throws Exception;
    public void
        setHistoryItems(LazyCollectionAccessAdapter<com.bexp.ejb.HistoryItem.SDObj,ObjCMPBean> arg) throws Exception;
    
    public Object getCreatorPK() throws Exception;
    public void setCreatorPK(Object _PK) throws Exception;
    
    public Object getOwnerPK() throws Exception;
    public void setOwnerPK(Object _PK) throws Exception;
    
    public Long getCRC() throws Exception;
    public void setCRC(Long newCRC) throws Exception;
    public long countCRC();

    
    public static final int millis_in_minute = 60000;
}
