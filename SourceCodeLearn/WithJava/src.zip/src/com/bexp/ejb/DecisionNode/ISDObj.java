package com.bexp.ejb.DecisionNode;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.IObj
{
    public java.lang.String getShortcode();
    public void setShortcode(java.lang.String locShortcode) throws Exception;


 
	public LazyCollectionAccessAdapter<com.bexp.ejb.DecisionNode.SDObj,SDObjCMPBase> getRelatedDecisionTree();
	public void setRelatedDecisionTree(LazyCollectionAccessAdapter<com.bexp.ejb.DecisionNode.SDObj,SDObjCMPBase> lca) throws Exception;




    public ObjHandle<com.bexp.ejb.Process.SDObj> getProcedure() throws Exception;
    public void setProcedure(ObjHandle<com.bexp.ejb.Process.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.BE.BEType.SDObj> getBEType() throws Exception;
    public void setBEType(ObjHandle<com.bexp.ejb.BE.BEType.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.TypicalTask.SDObj> getTypicalTask() throws Exception;
    public void setTypicalTask(ObjHandle<com.bexp.ejb.TypicalTask.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.OrgUnit.Organization.SDObj> getAffectedOrganization() throws Exception;
    public void setAffectedOrganization(ObjHandle<com.bexp.ejb.OrgUnit.Organization.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.Priority.Impact.SDObj> getImpact() throws Exception;
    public void setImpact(ObjHandle<com.bexp.ejb.Priority.Impact.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.Priority.SDObj> getPriority() throws Exception;
    public void setPriority(ObjHandle<com.bexp.ejb.Priority.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.Service.SDObj> getService() throws Exception;
    public void setService(ObjHandle<com.bexp.ejb.Service.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.DecisionNode.SDObj> getParentDecisionTree() throws Exception;
    public void setParentDecisionTree(ObjHandle<com.bexp.ejb.DecisionNode.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.Priority.Urgency.SDObj> getUrgency() throws Exception;
    public void setUrgency(ObjHandle<com.bexp.ejb.Priority.Urgency.SDObj> handle) throws Exception;



	public LazyCollectionAccessAdapter<com.bexp.ejb.DecisionNode.SDObj,SDObjCMPBase> getChildDecisionTrees();
	public void setChildDecisionTrees(LazyCollectionAccessAdapter<com.bexp.ejb.DecisionNode.SDObj,SDObjCMPBase> lca) throws Exception;

    public Set<ObjHandle<com.bexp.ejb.BE.SDObj> > getRelatedBusinessEvents();
	public void setRelatedBusinessEvents(Set<ObjHandle<com.bexp.ejb.BE.SDObj> > _arg) throws Exception;




//---------------------------------------------------------------------------------
}