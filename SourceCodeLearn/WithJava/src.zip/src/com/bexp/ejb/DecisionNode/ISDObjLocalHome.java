package com.bexp.ejb.DecisionNode;
import com.bexp.ejb.*;
import java.util.*;

public interface ISDObjLocalHome
    extends com.bexp.ejb.IObjLocalHome
{

	public boolean check_Shortcode_2_unique_local(Object PK , java.lang.String Shortcode)  throws Exception;

//---------------------------------------------------------------------------------
public Set GET_Root_Decision_Tree_PKs() throws java.rmi.RemoteException;
}
