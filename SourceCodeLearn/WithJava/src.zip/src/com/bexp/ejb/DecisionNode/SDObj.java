package com.bexp.ejb.DecisionNode;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.Obj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.DecisionNode.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.DecisionNode";
    
	protected java.lang.String Shortcode;
	public java.lang.String getShortcode() {
	 return Shortcode;  	 
	 }
	public void setShortcode(java.lang.String locShortcode) throws Exception { 
	Shortcode=locShortcode;
	}	


//---------------------------------------------------------------------------------------

LazyCollectionAccessAdapter<com.bexp.ejb.DecisionNode.SDObj,SDObjCMPBase> relatedDecisionTree;
public LazyCollectionAccessAdapter<com.bexp.ejb.DecisionNode.SDObj,SDObjCMPBase> getRelatedDecisionTree()
        {
        if(relatedDecisionTree==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.DecisionNode.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.DecisionNode.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedDecisionTreeCMPs(),
                    com.bexp.ejb.DecisionNode.SDObj.class, false);
            }
        }
		relatedDecisionTree = new LazyCollectionAccessAdapter<com.bexp.ejb.DecisionNode.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.DecisionNode.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedDecisionTree;     
        }
    public void setRelatedDecisionTree(LazyCollectionAccessAdapter<com.bexp.ejb.DecisionNode.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedDecisionTree.copy(lca); }        
//---------------------------------------------------------------------------------------




    ObjHandle<com.bexp.ejb.Process.SDObj> procedure
            = new ObjHandle<com.bexp.ejb.Process.SDObj>(null,false,com.bexp.ejb.Process.SDObj.class);
    public ObjHandle<com.bexp.ejb.Process.SDObj> getProcedure() throws Exception
        {
        return procedure;
        }
    public void setProcedure(ObjHandle<com.bexp.ejb.Process.SDObj> handle) throws Exception
        {
        procedure.copy(handle);
        procedure.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.BE.BEType.SDObj> bEType
            = new ObjHandle<com.bexp.ejb.BE.BEType.SDObj>(null,false,com.bexp.ejb.BE.BEType.SDObj.class);
    public ObjHandle<com.bexp.ejb.BE.BEType.SDObj> getBEType() throws Exception
        {
        return bEType;
        }
    public void setBEType(ObjHandle<com.bexp.ejb.BE.BEType.SDObj> handle) throws Exception
        {
        bEType.copy(handle);
        bEType.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.TypicalTask.SDObj> typicalTask
            = new ObjHandle<com.bexp.ejb.TypicalTask.SDObj>(null,false,com.bexp.ejb.TypicalTask.SDObj.class);
    public ObjHandle<com.bexp.ejb.TypicalTask.SDObj> getTypicalTask() throws Exception
        {
        return typicalTask;
        }
    public void setTypicalTask(ObjHandle<com.bexp.ejb.TypicalTask.SDObj> handle) throws Exception
        {
        typicalTask.copy(handle);
        typicalTask.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.OrgUnit.Organization.SDObj> affectedOrganization
            = new ObjHandle<com.bexp.ejb.OrgUnit.Organization.SDObj>(null,false,com.bexp.ejb.OrgUnit.Organization.SDObj.class);
    public ObjHandle<com.bexp.ejb.OrgUnit.Organization.SDObj> getAffectedOrganization() throws Exception
        {
        return affectedOrganization;
        }
    public void setAffectedOrganization(ObjHandle<com.bexp.ejb.OrgUnit.Organization.SDObj> handle) throws Exception
        {
        affectedOrganization.copy(handle);
        affectedOrganization.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.Priority.Impact.SDObj> impact
            = new ObjHandle<com.bexp.ejb.Priority.Impact.SDObj>(null,false,com.bexp.ejb.Priority.Impact.SDObj.class);
    public ObjHandle<com.bexp.ejb.Priority.Impact.SDObj> getImpact() throws Exception
        {
        return impact;
        }
    public void setImpact(ObjHandle<com.bexp.ejb.Priority.Impact.SDObj> handle) throws Exception
        {
        impact.copy(handle);
        impact.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.Priority.SDObj> priority
            = new ObjHandle<com.bexp.ejb.Priority.SDObj>(null,false,com.bexp.ejb.Priority.SDObj.class);
    public ObjHandle<com.bexp.ejb.Priority.SDObj> getPriority() throws Exception
        {
        return priority;
        }
    public void setPriority(ObjHandle<com.bexp.ejb.Priority.SDObj> handle) throws Exception
        {
        priority.copy(handle);
        priority.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.Service.SDObj> service
            = new ObjHandle<com.bexp.ejb.Service.SDObj>(null,false,com.bexp.ejb.Service.SDObj.class);
    public ObjHandle<com.bexp.ejb.Service.SDObj> getService() throws Exception
        {
        return service;
        }
    public void setService(ObjHandle<com.bexp.ejb.Service.SDObj> handle) throws Exception
        {
        service.copy(handle);
        service.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.DecisionNode.SDObj> parentDecisionTree
            = new ObjHandle<com.bexp.ejb.DecisionNode.SDObj>(null,false,com.bexp.ejb.DecisionNode.SDObj.class);
    public ObjHandle<com.bexp.ejb.DecisionNode.SDObj> getParentDecisionTree() throws Exception
        {
        return parentDecisionTree;
        }
    public void setParentDecisionTree(ObjHandle<com.bexp.ejb.DecisionNode.SDObj> handle) throws Exception
        {
        parentDecisionTree.copy(handle);
        parentDecisionTree.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.Priority.Urgency.SDObj> urgency
            = new ObjHandle<com.bexp.ejb.Priority.Urgency.SDObj>(null,false,com.bexp.ejb.Priority.Urgency.SDObj.class);
    public ObjHandle<com.bexp.ejb.Priority.Urgency.SDObj> getUrgency() throws Exception
        {
        return urgency;
        }
    public void setUrgency(ObjHandle<com.bexp.ejb.Priority.Urgency.SDObj> handle) throws Exception
        {
        urgency.copy(handle);
        urgency.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

LazyCollectionAccessAdapter<com.bexp.ejb.DecisionNode.SDObj,SDObjCMPBase> childDecisionTrees;
public LazyCollectionAccessAdapter<com.bexp.ejb.DecisionNode.SDObj,SDObjCMPBase> getChildDecisionTrees()
        {
        if(childDecisionTrees==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.DecisionNode.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.DecisionNode.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getChildDecisionTreesCMPs(),
                    com.bexp.ejb.DecisionNode.SDObj.class, false);
            }
        }
		childDecisionTrees = new LazyCollectionAccessAdapter<com.bexp.ejb.DecisionNode.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.DecisionNode.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  childDecisionTrees;
        }
    public void setChildDecisionTrees(LazyCollectionAccessAdapter<com.bexp.ejb.DecisionNode.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) childDecisionTrees.copy(lca); }        
        
//---------------------------------------------------------------------------------------
    Set<ObjHandle<com.bexp.ejb.BE.SDObj> > relatedBusinessEvents = new CopyOnWriteArraySet();    
    public Set<ObjHandle<com.bexp.ejb.BE.SDObj> > getRelatedBusinessEvents()
        { return relatedBusinessEvents; }
    public void setRelatedBusinessEvents(Set<ObjHandle<com.bexp.ejb.BE.SDObj> > _arg) throws Exception
        { relatedBusinessEvents.clear(); if(_arg!=null) {relatedBusinessEvents.addAll(_arg);} }                        
        
//---------------------------------------------------------------------------------------




//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
    	if (!((ISDObjHome)ObjSession.getSession().getHome(SDObjCMPBase.class)).check_Shortcode_2_unique(this.getPK() , this.getShortcode()) ){
    		throw new com.bexp.BEXPException(com.bexp.SDApp.translate("Shortcode not unique"));}

     super.save();
    }
}