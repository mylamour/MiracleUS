package com.bexp.ejb.DecisionNode;

import javax.persistence.*;
import java.util.*;
import javax.ejb.*;
import com.bexp.ejb.*;

@Remote
public interface ISDObjHome extends com.bexp.ejb.IObjHome
{

	public boolean check_Shortcode_2_unique(Object PK , java.lang.String Shortcode)  throws Exception;


//---------------------------------------------------------------------------------
public java.util.Set getRootDecisionTreePKs() throws Exception;
}
