package com.bexp.ejb.DecisionNode;

import java.util.*;
import javax.annotation.*;
import javax.ejb.*;
import javax.persistence.*;
import javax.naming.*;

import org.jboss.annotation.security.SecurityDomain;
import com.bexp.ejb.*;

@Stateless(name="com.bexp.ejb.DecisionNode.SDObjRemoteHomeBean")
@Remote(ISDObjHome.class)
@Local(ISDObjLocalHome.class)
@SecurityDomain("bexp")
public class SDObjRemoteHomeBean
	extends com.bexp.ejb.ObjHomeBean
    implements ISDObjHome,ISDObjLocalHome
{

//---------------------------------------------------------------------------------
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public boolean check_Shortcode_2_unique(Object PK , java.lang.String Shortcode)  throws Exception{
		lock.lock();
		try{
			return ((ISDObjLocalHome)getLocalHome()).check_Shortcode_2_unique_local(PK , Shortcode) ;			
		}
		finally{lock.unlock();}
	}
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public boolean check_Shortcode_2_unique_local(Object PK , java.lang.String Shortcode)  throws Exception
        {
		if (Shortcode==null) return true;
        List result = 
            ObjHomeBean.getEM()
            .createQuery("FROM "+EntityCMPBeanClass.getName()+" ci WHERE 1=1 and ci.shortcode='"+Shortcode+"'  and ci.id<>"+PK)
            .getResultList();
        if (result.size()>0) return false;
        else return true;        
        }	
        
        
  
//--------------------------------------------------------------------------------------        
	public Set getRootDecisionTreePKs() throws Exception{
		lock.lock();
		try{
			return ((ISDObjLocalHome)getLocalHome()).GET_Root_Decision_Tree_PKs();	
		}
		finally{lock.unlock();}		
	}	
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public Set GET_Root_Decision_Tree_PKs() throws java.rmi.RemoteException
        {
        List result = 
            ObjHomeBean.getEM()
            .createQuery("SELECT ci FROM "+EntityCMPBeanClass.getName()+" ci WHERE ci.parentDecisionTreeCMP=null  and (ci.isRemoved=FALSE OR ci.isRemoved is null)")
            .getResultList();
        System.out.println("Root DecisionTrees are N="+result.size());
       
     
        
        return Obj.ObjsToPKs(new HashSet(result));
        }


        
}
