package com.bexp.ejb.DecisionNode;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.DecisionNode.SDObjCMPBase")
@Table(name = "DecisionNode")
public class SDObjCMPBase
    extends com.bexp.ejb.ObjCMPBean
    implements ISDObj,java.io.Serializable
{
   
	protected java.lang.String Shortcode;
	public java.lang.String getShortcode() {
	 return Shortcode;  	 
	 }
	public void setShortcode(java.lang.String locShortcode) throws Exception { 
	Shortcode=locShortcode;
	}	


 
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.DecisionNode.SDObj,SDObjCMPBase> getRelatedDecisionTree()
 {
        return null;
        }
public void setRelatedDecisionTree(LazyCollectionAccessAdapter<com.bexp.ejb.DecisionNode.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedDecisionTreeCMPs(),
                (Set)lca.get(), com.bexp.ejb.DecisionNode.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.DecisionNode.SDObjCMPBase> relatedDecisionTreeCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "DecisionNode_RelatedDecisionTree",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.DecisionNode.SDObjCMPBase> getRelatedDecisionTreeCMPs()
        { return relatedDecisionTreeCMPs; }
    public void setRelatedDecisionTreeCMPs(Set<com.bexp.ejb.DecisionNode.SDObjCMPBase> cmps)
        { relatedDecisionTreeCMPs = cmps; }
//------------------------------------------------------------------------------



    @Transient
    public ObjHandle<com.bexp.ejb.Process.SDObj> getProcedure() throws Exception
        {
        ObjCMPBean cmp = getProcedureCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Process.SDObj>(cmp,com.bexp.ejb.Process.SDObj.class);
        }
    public void setProcedure(ObjHandle<com.bexp.ejb.Process.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setProcedureCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Process.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.Process.SDObjCMPBase procedureCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Process.SDObjCMPBase getProcedureCMP()
        { return procedureCMP; }
    public void setProcedureCMP(com.bexp.ejb.Process.SDObjCMPBase cicmp)
        { procedureCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.BE.BEType.SDObj> getBEType() throws Exception
        {
        ObjCMPBean cmp = getBETypeCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.BE.BEType.SDObj>(cmp,com.bexp.ejb.BE.BEType.SDObj.class);
        }
    public void setBEType(ObjHandle<com.bexp.ejb.BE.BEType.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setBETypeCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.BE.BEType.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.BE.BEType.SDObjCMPBase bETypeCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.BE.BEType.SDObjCMPBase getBETypeCMP()
        { return bETypeCMP; }
    public void setBETypeCMP(com.bexp.ejb.BE.BEType.SDObjCMPBase cicmp)
        { bETypeCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.TypicalTask.SDObj> getTypicalTask() throws Exception
        {
        ObjCMPBean cmp = getTypicalTaskCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.TypicalTask.SDObj>(cmp,com.bexp.ejb.TypicalTask.SDObj.class);
        }
    public void setTypicalTask(ObjHandle<com.bexp.ejb.TypicalTask.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setTypicalTaskCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.TypicalTask.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.TypicalTask.SDObjCMPBase typicalTaskCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.TypicalTask.SDObjCMPBase getTypicalTaskCMP()
        { return typicalTaskCMP; }
    public void setTypicalTaskCMP(com.bexp.ejb.TypicalTask.SDObjCMPBase cicmp)
        { typicalTaskCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.OrgUnit.Organization.SDObj> getAffectedOrganization() throws Exception
        {
        ObjCMPBean cmp = getAffectedOrganizationCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.OrgUnit.Organization.SDObj>(cmp,com.bexp.ejb.OrgUnit.Organization.SDObj.class);
        }
    public void setAffectedOrganization(ObjHandle<com.bexp.ejb.OrgUnit.Organization.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setAffectedOrganizationCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.OrgUnit.Organization.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.OrgUnit.Organization.SDObjCMPBase affectedOrganizationCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.OrgUnit.Organization.SDObjCMPBase getAffectedOrganizationCMP()
        { return affectedOrganizationCMP; }
    public void setAffectedOrganizationCMP(com.bexp.ejb.OrgUnit.Organization.SDObjCMPBase cicmp)
        { affectedOrganizationCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.Priority.Impact.SDObj> getImpact() throws Exception
        {
        ObjCMPBean cmp = getImpactCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Priority.Impact.SDObj>(cmp,com.bexp.ejb.Priority.Impact.SDObj.class);
        }
    public void setImpact(ObjHandle<com.bexp.ejb.Priority.Impact.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setImpactCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Priority.Impact.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.Priority.Impact.SDObjCMPBase impactCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Priority.Impact.SDObjCMPBase getImpactCMP()
        { return impactCMP; }
    public void setImpactCMP(com.bexp.ejb.Priority.Impact.SDObjCMPBase cicmp)
        { impactCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.Priority.SDObj> getPriority() throws Exception
        {
        ObjCMPBean cmp = getPriorityCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Priority.SDObj>(cmp,com.bexp.ejb.Priority.SDObj.class);
        }
    public void setPriority(ObjHandle<com.bexp.ejb.Priority.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setPriorityCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Priority.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.Priority.SDObjCMPBase priorityCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Priority.SDObjCMPBase getPriorityCMP()
        { return priorityCMP; }
    public void setPriorityCMP(com.bexp.ejb.Priority.SDObjCMPBase cicmp)
        { priorityCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.Service.SDObj> getService() throws Exception
        {
        ObjCMPBean cmp = getServiceCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Service.SDObj>(cmp,com.bexp.ejb.Service.SDObj.class);
        }
    public void setService(ObjHandle<com.bexp.ejb.Service.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setServiceCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Service.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.Service.SDObjCMPBase serviceCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Service.SDObjCMPBase getServiceCMP()
        { return serviceCMP; }
    public void setServiceCMP(com.bexp.ejb.Service.SDObjCMPBase cicmp)
        { serviceCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.DecisionNode.SDObj> getParentDecisionTree() throws Exception
        {
        ObjCMPBean cmp = getParentDecisionTreeCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.DecisionNode.SDObj>(cmp,com.bexp.ejb.DecisionNode.SDObj.class);
        }
    public void setParentDecisionTree(ObjHandle<com.bexp.ejb.DecisionNode.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setParentDecisionTreeCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.DecisionNode.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.DecisionNode.SDObjCMPBase parentDecisionTreeCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.DecisionNode.SDObjCMPBase getParentDecisionTreeCMP()
        { return parentDecisionTreeCMP; }
    public void setParentDecisionTreeCMP(com.bexp.ejb.DecisionNode.SDObjCMPBase cicmp)
        { parentDecisionTreeCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.Priority.Urgency.SDObj> getUrgency() throws Exception
        {
        ObjCMPBean cmp = getUrgencyCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Priority.Urgency.SDObj>(cmp,com.bexp.ejb.Priority.Urgency.SDObj.class);
        }
    public void setUrgency(ObjHandle<com.bexp.ejb.Priority.Urgency.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setUrgencyCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Priority.Urgency.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.Priority.Urgency.SDObjCMPBase urgencyCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Priority.Urgency.SDObjCMPBase getUrgencyCMP()
        { return urgencyCMP; }
    public void setUrgencyCMP(com.bexp.ejb.Priority.Urgency.SDObjCMPBase cicmp)
        { urgencyCMP = cicmp; }
//------------------------------------------------------------------------------



    @Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.DecisionNode.SDObj,SDObjCMPBase> getChildDecisionTrees()
 {
        return null;
        }
    public void setChildDecisionTrees(LazyCollectionAccessAdapter<com.bexp.ejb.DecisionNode.SDObj,SDObjCMPBase> lca) throws Exception
        {
      setOneToMany(this.getChildDecisionTreesCMPs(),
             (Set)lca.get(), com.bexp.ejb.DecisionNode.SDObjCMPBase.class,
                new function2<Void,com.bexp.ejb.DecisionNode.SDObjCMPBase, SDObjCMPBase>()
                {public Void Op(com.bexp.ejb.DecisionNode.SDObjCMPBase owner_cmp,SDObjCMPBase cmp)
                    { owner_cmp.setParentDecisionTreeCMP(cmp); return null; }}
             ,false);                 
        }        
    
        java.util.Set<com.bexp.ejb.DecisionNode.SDObjCMPBase> childDecisionTreesCMPs;
    @OneToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH,mappedBy="parentDecisionTreeCMP")
    public Set<com.bexp.ejb.DecisionNode.SDObjCMPBase> getChildDecisionTreesCMPs()
        { return childDecisionTreesCMPs; }
    public void setChildDecisionTreesCMPs (Set<com.bexp.ejb.DecisionNode.SDObjCMPBase> cmps)
        { childDecisionTreesCMPs = cmps;}   
//------------------------------------------------------------------------------            
    @Transient
public Set<ObjHandle<com.bexp.ejb.BE.SDObj> > getRelatedBusinessEvents()
 {
        return Obj.ObjsToHandles(this.getRelatedBusinessEventsCMPs(),
            com.bexp.ejb.BE.SDObj.class, false);
        }
public void setRelatedBusinessEvents(Set<ObjHandle<com.bexp.ejb.BE.SDObj> > handles) throws Exception
 {
      setOneToMany(this.getRelatedBusinessEventsCMPs(),
             handles, com.bexp.ejb.BE.SDObjCMPBase.class,
                new function2<Void,com.bexp.ejb.BE.SDObjCMPBase, SDObjCMPBase>()
                {public Void Op(com.bexp.ejb.BE.SDObjCMPBase owner_cmp,SDObjCMPBase cmp)
                    { owner_cmp.setRelatedDecisionTreeCMP(cmp); return null; }}
             ,false);
 }
    
        java.util.Set<com.bexp.ejb.BE.SDObjCMPBase> relatedBusinessEventsCMPs;
    @OneToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH,mappedBy="relatedDecisionTreeCMP")
    public Set<com.bexp.ejb.BE.SDObjCMPBase> getRelatedBusinessEventsCMPs()
        { return relatedBusinessEventsCMPs; }
    public void setRelatedBusinessEventsCMPs (Set<com.bexp.ejb.BE.SDObjCMPBase> cmps)
        { relatedBusinessEventsCMPs = cmps;}   
//------------------------------------------------------------------------------            



//---------------------------------------------------------------------------------
}

