package com.bexp.ejb.Email;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.Email.SDObjCMPBase")
@Table(name = "Email")
public class SDObjCMPBase
    extends com.bexp.ejb.ObjCMPBean
    implements ISDObj,java.io.Serializable
{
   

 



    @Transient
    public ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> getEmployee() throws Exception
        {
        ObjCMPBean cmp = getEmployeeCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj>(cmp,com.bexp.ejb.OrgUnit.Employee.SDObj.class);
        }
    public void setEmployee(ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setEmployeeCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.OrgUnit.Employee.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.OrgUnit.Employee.SDObjCMPBase employeeCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.OrgUnit.Employee.SDObjCMPBase getEmployeeCMP()
        { return employeeCMP; }
    public void setEmployeeCMP(com.bexp.ejb.OrgUnit.Employee.SDObjCMPBase cicmp)
        { employeeCMP = cicmp; }
//------------------------------------------------------------------------------






//---------------------------------------------------------------------------------
}

