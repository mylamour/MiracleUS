package com.bexp.ejb.Email;

import java.util.*;
import javax.annotation.*;
import javax.ejb.*;
import javax.persistence.*;
import javax.naming.*;

import org.jboss.annotation.security.SecurityDomain;
import com.bexp.ejb.*;

@Stateless(name="com.bexp.ejb.Email.SDObjRemoteHomeBean")
@Remote(ISDObjHome.class)
@Local(ISDObjLocalHome.class)
@SecurityDomain("bexp")
public class SDObjRemoteHomeBean
	extends com.bexp.ejb.ObjHomeBean
    implements ISDObjHome,ISDObjLocalHome
{

//---------------------------------------------------------------------------------
  
//--------------------------------------------------------------------------------------        

        
}
