package com.bexp.ejb.Holiday;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.Holiday.SDObjCMPBase")
@Table(name = "Holiday")
public class SDObjCMPBase
    extends com.bexp.ejb.ObjCMPBean
    implements ISDObj,java.io.Serializable
{
   
	protected java.util.Date HolidayDate;
	public java.util.Date getHolidayDate() {
	 return HolidayDate;  	 
	 }
	public void setHolidayDate(java.util.Date locHolidayDate) throws Exception { 
	HolidayDate=locHolidayDate;
	}	


 








//---------------------------------------------------------------------------------
}

