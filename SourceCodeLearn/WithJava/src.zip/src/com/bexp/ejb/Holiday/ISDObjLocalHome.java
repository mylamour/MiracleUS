package com.bexp.ejb.Holiday;
import com.bexp.ejb.*;
import java.util.*;

public interface ISDObjLocalHome
    extends com.bexp.ejb.IObjLocalHome
{

//---------------------------------------------------------------------------------
}
