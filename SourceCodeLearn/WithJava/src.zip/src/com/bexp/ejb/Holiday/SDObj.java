package com.bexp.ejb.Holiday;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.Obj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.Holiday.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.Holiday";
    
	protected java.util.Date HolidayDate;
	public java.util.Date getHolidayDate() {
	 return HolidayDate;  	 
	 }
	public void setHolidayDate(java.util.Date locHolidayDate) throws Exception { 
	HolidayDate=locHolidayDate;
	}	


//---------------------------------------------------------------------------------------









//---------------------------------------------------------------------------------


    public void save() throws Exception
    {

     super.save();
    }
}