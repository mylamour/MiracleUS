package com.bexp.ejb;

import javax.ejb.*;
import java.util.*;

public interface ISessionTracker
{
    public void login() throws Exception;
    
    @Remove
    public void logout();
    
    public List<ObjHandle<com.bexp.ejb.Person.SDObj> > getLogged();
}
