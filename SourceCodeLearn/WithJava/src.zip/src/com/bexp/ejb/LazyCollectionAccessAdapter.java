package com.bexp.ejb;

import org.JWrapper.*;
import java.util.*;
import java.io.*;

public class LazyCollectionAccessAdapter<T extends Obj,CMP_t>
    extends JAccessAdapter<Collection<ObjHandle<T> > >
    implements Serializable
{
    function1<Collection<ObjHandle<T>>,CMP_t> getter;
    //function2<Void,CMP_t,Collection<ObjHandle<T>>> setter;
    Object PK;
    Collection<ObjHandle<T>> collection;
    boolean initialized = false;
    Class SDObj_class, CMP_class;
     
    public
    LazyCollectionAccessAdapter(
            Object pk,
            Class<T> _SDObj_class,
            Class<CMP_t> _CMP_class,
            function1<Collection<ObjHandle<T>>,CMP_t> _getter,
            //function2<Void,CMP_t,Collection<ObjHandle<T>>> _setter,
            Collection<ObjHandle<T>> _collection)
        {
        super(_collection.getClass());
        getter = _getter;
        //setter = _setter;
        PK=pk;
        collection = _collection;
        SDObj_class = _SDObj_class;
        CMP_class = _CMP_class;
        }

    class QueryF_t implements function0<Collection<ObjHandle<T>>>,Serializable
        {
        function1<Collection<ObjHandle<T>>,CMP_t> getter;
        Class sdclass;
        Object pk;
        public QueryF_t(){}
        public QueryF_t(Object _pk, Class cls, function1<Collection<ObjHandle<T>>,CMP_t> _getter)
            {sdclass=cls; pk = _pk; getter = _getter; }
        public Collection<ObjHandle<T>> Op() throws Exception
            {
            ObjHomeBean.lock.lock();
            try
                {
                System.out.println("++++++++++"+sdclass);
                System.out.println("++++++++++"+pk);
                IObjLocalHome lhome = ObjSession.getSession().getLocalHome(sdclass);
                return getter.Op((CMP_t)
                lhome.getJTAEntityManager()
                    .find(CMP_class,pk));
                } finally { ObjHomeBean.lock.unlock(); }
            }
        };
    
           
    public Collection<ObjHandle<T>> get() throws Exception
        {
        if(!initialized)
            {
            function0<Collection<ObjHandle<T>>> query_f = new QueryF_t(PK,SDObj_class,getter);
            IObjHome home = ObjSession.getSession().getHome(SDObj_class);
            collection.addAll((Collection<ObjHandle<T>>)
                    home.query(query_f) );
            initialized=true;
            }
        return collection;
        }
    protected void _set(Collection<ObjHandle<T>> handles) throws Exception
        {
        collection.addAll(handles);
        }
    
    public void copy(LazyCollectionAccessAdapter<T,CMP_t> _lca) throws Exception
        {
        if((initialized)&&(_lca!=null))
            {
            collection.addAll(_lca.get());
            }
        }
    public boolean isInitialized()
        { return initialized; }
}
