package com.bexp.ejb.BE;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.WorkflowObject.SDObj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.BE.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.BE";
    
	protected java.util.Date ActualStart;
	public java.util.Date getActualStart() {
	 return ActualStart;  	 
	 }
	public void setActualStart(java.util.Date locActualStart) throws Exception { 
	ActualStart=locActualStart;
	}	

	protected java.util.Date PlannedStart;
	public java.util.Date getPlannedStart() {
	 return PlannedStart;  	 
	 }
	public void setPlannedStart(java.util.Date locPlannedStart) throws Exception { 
	PlannedStart=locPlannedStart;
	}	

	protected java.util.Date ActualFinish;
	public java.util.Date getActualFinish() {
	 return ActualFinish;  	 
	 }
	public void setActualFinish(java.util.Date locActualFinish) throws Exception { 
	ActualFinish=locActualFinish;
	}	


protected java.util.Date Deadline;
public java.util.Date getDeadline()
    {return Deadline;}
public synchronized void setDeadline(java.util.Date deadline) throws Exception
    {
    check_times(getPlannedStart(),deadline);
    Deadline = deadline;
    }

private void check_times(java.util.Date start,java.util.Date deadline) throws Exception
{
if(!ObjSession.getSession().getClientSide()) {return;}
if(deadline!=null)
    {
    if(!(deadline.after(getCreationTime())))
        {com.bexp.ASSERT.alert("Deadline cannot be before creation time !");}
    }
if(start!=null)
    {
    if(!(start.after(getCreationTime())))
            {com.bexp.ASSERT.alert("Start cannot be before creation time !");}
    if(deadline!=null)
        {
        if(start.after(deadline))
            {com.bexp.ASSERT.alert("Start cannot be after deadline !");}
        }
    }
}
//---------------------------------------------------------------------------------------

    Set<ObjHandle<com.bexp.ejb.Person.SDObj> > deadlineRecipients = new CopyOnWriteArraySet();    
    public Set<ObjHandle<com.bexp.ejb.Person.SDObj> > getDeadlineRecipients()
        { return deadlineRecipients; }
    public void setDeadlineRecipients(Set<ObjHandle<com.bexp.ejb.Person.SDObj> > _arg) throws Exception
        { deadlineRecipients.clear(); if(_arg!=null) {deadlineRecipients.addAll(_arg);} }        
//---------------------------------------------------------------------------------------




    ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> caller
            = new ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj>(null,false,com.bexp.ejb.OrgUnit.Employee.SDObj.class);
    public ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> getCaller() throws Exception
        {
        return caller;
        }
    public void setCaller(ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> handle) throws Exception
        {
        caller.copy(handle);
        caller.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.CI.SDObj> relatedCI
            = new ObjHandle<com.bexp.ejb.CI.SDObj>(null,false,com.bexp.ejb.CI.SDObj.class);
    public ObjHandle<com.bexp.ejb.CI.SDObj> getRelatedCI() throws Exception
        {
        return relatedCI;
        }
    public void setRelatedCI(ObjHandle<com.bexp.ejb.CI.SDObj> handle) throws Exception
        {
        relatedCI.copy(handle);
        relatedCI.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.Person.SDObj> assignedTo
            = new ObjHandle<com.bexp.ejb.Person.SDObj>(null,false,com.bexp.ejb.Person.SDObj.class);
    public ObjHandle<com.bexp.ejb.Person.SDObj> getAssignedTo() throws Exception
        {
        return assignedTo;
        }
    public void setAssignedTo(ObjHandle<com.bexp.ejb.Person.SDObj> handle) throws Exception
        {
        assignedTo.copy(handle);
        assignedTo.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.OrgUnit.Organization.SDObj> affectedOrganization
            = new ObjHandle<com.bexp.ejb.OrgUnit.Organization.SDObj>(null,false,com.bexp.ejb.OrgUnit.Organization.SDObj.class);
    public ObjHandle<com.bexp.ejb.OrgUnit.Organization.SDObj> getAffectedOrganization() throws Exception
        {
        return affectedOrganization;
        }
    public void setAffectedOrganization(ObjHandle<com.bexp.ejb.OrgUnit.Organization.SDObj> handle) throws Exception
        {
        affectedOrganization.copy(handle);
        affectedOrganization.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.DecisionNode.SDObj> relatedDecisionTree
            = new ObjHandle<com.bexp.ejb.DecisionNode.SDObj>(null,false,com.bexp.ejb.DecisionNode.SDObj.class);
    public ObjHandle<com.bexp.ejb.DecisionNode.SDObj> getRelatedDecisionTree() throws Exception
        {
        return relatedDecisionTree;
        }
    public void setRelatedDecisionTree(ObjHandle<com.bexp.ejb.DecisionNode.SDObj> handle) throws Exception
        {
        relatedDecisionTree.copy(handle);
        relatedDecisionTree.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.BE.BEType.SDObj> bEType
            = new ObjHandle<com.bexp.ejb.BE.BEType.SDObj>(null,false,com.bexp.ejb.BE.BEType.SDObj.class);
    public ObjHandle<com.bexp.ejb.BE.BEType.SDObj> getBEType() throws Exception
        {
        return bEType;
        }
    public void setBEType(ObjHandle<com.bexp.ejb.BE.BEType.SDObj> handle) throws Exception
        {
        bEType.copy(handle);
        bEType.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.Process.SDObj> procedure
            = new ObjHandle<com.bexp.ejb.Process.SDObj>(null,false,com.bexp.ejb.Process.SDObj.class);
    public ObjHandle<com.bexp.ejb.Process.SDObj> getProcedure() throws Exception
        {
        return procedure;
        }
    public void setProcedure(ObjHandle<com.bexp.ejb.Process.SDObj> handle) throws Exception
        {
        procedure.copy(handle);
        procedure.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.TypicalTask.SDObj> typicalTask
            = new ObjHandle<com.bexp.ejb.TypicalTask.SDObj>(null,false,com.bexp.ejb.TypicalTask.SDObj.class);
    public ObjHandle<com.bexp.ejb.TypicalTask.SDObj> getTypicalTask() throws Exception
        {
        return typicalTask;
        }
    public void setTypicalTask(ObjHandle<com.bexp.ejb.TypicalTask.SDObj> handle) throws Exception
        {
        typicalTask.copy(handle);
        typicalTask.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.Service.SDObj> service
            = new ObjHandle<com.bexp.ejb.Service.SDObj>(null,false,com.bexp.ejb.Service.SDObj.class);
    public ObjHandle<com.bexp.ejb.Service.SDObj> getService() throws Exception
        {
        return service;
        }
    public void setService(ObjHandle<com.bexp.ejb.Service.SDObj> handle) throws Exception
        {
        service.copy(handle);
        service.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    Set<ObjHandle<com.bexp.ejb.Task.SDObj> > relatedTasks = new CopyOnWriteArraySet();    
    public Set<ObjHandle<com.bexp.ejb.Task.SDObj> > getRelatedTasks()
        { return relatedTasks; }
    public void setRelatedTasks(Set<ObjHandle<com.bexp.ejb.Task.SDObj> > _arg) throws Exception
        { relatedTasks.clear(); if(_arg!=null) {relatedTasks.addAll(_arg);} }                        
        
//---------------------------------------------------------------------------------------




//---------------------------------------------------------------------------------
    public Long getPlannedDuration() throws Exception
        {
        try{
        return -(getPlannedStart().getTime()-getDeadline().getTime())/millis_in_minute;
        }catch(NullPointerException ex) {return null;}
        }
    public void setPlannedDuration(Long ms) throws Exception
        {
        if(ms<=0) { throw new Exception("Planned Duration should be more than 0 "); }
        try{
        setDeadline((new java.util.Date(getPlannedStart().getTime()+ms*millis_in_minute)));
        }catch(NullPointerException ex) { throw new Exception("Set Planned Start first !"); }
        }
    public Long getActualDuration() throws Exception
        {
        try{
        return -(getActualStart().getTime()-getActualFinish().getTime())/millis_in_minute;
        }catch(NullPointerException ex) {return null;}
        }
    public void setActualDuration(Long ms) throws Exception
        {
        if(ms<=0) { throw new Exception("Actual Duration should be more than 0 "); }
        try{
        setActualFinish((new java.util.Date(getActualStart().getTime()+ms*millis_in_minute)));
        }catch(NullPointerException ex) { throw new Exception("Set Actual Start first !"); }
        }


    public void save() throws Exception
    {




     super.save();
    }
}