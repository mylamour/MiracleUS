package com.bexp.ejb.BE.BEType;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.IObj
{
    public java.lang.String getProcessType();
    public void setProcessType(java.lang.String locProcessType) throws Exception;


 








//---------------------------------------------------------------------------------
}