package com.bexp.ejb.BE;
import com.bexp.ejb.*;
import java.util.*;

public interface ISDObjLocalHome
    extends com.bexp.ejb.WorkflowObject.ISDObjLocalHome
{

//---------------------------------------------------------------------------------
}
