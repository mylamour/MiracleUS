package com.bexp.ejb.BE.BEType;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.BE.BEType.SDObjCMPBase")
@Table(name = "BEType")
public class SDObjCMPBase
    extends com.bexp.ejb.ObjCMPBean
    implements ISDObj,java.io.Serializable
{
   
	protected java.lang.String ProcessType;
	public java.lang.String getProcessType() {
	 return ProcessType;  	 
	 }
	public void setProcessType(java.lang.String locProcessType) throws Exception { 
	ProcessType=locProcessType;
	}	


 








//---------------------------------------------------------------------------------
}

