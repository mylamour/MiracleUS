package com.bexp.ejb.BE;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.WorkflowObject.ISDObj
{
    public java.util.Date getActualStart();
    public void setActualStart(java.util.Date locActualStart) throws Exception;

    public java.util.Date getPlannedStart();
    public void setPlannedStart(java.util.Date locPlannedStart) throws Exception;

    public java.util.Date getActualFinish();
    public void setActualFinish(java.util.Date locActualFinish) throws Exception;

    public java.util.Date getDeadline();
    public void setDeadline(java.util.Date locDeadline) throws Exception;


 
	public Set<ObjHandle<com.bexp.ejb.Person.SDObj> > getDeadlineRecipients();
	public void setDeadlineRecipients(Set<ObjHandle<com.bexp.ejb.Person.SDObj> > _arg) throws Exception;




    public ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> getCaller() throws Exception;
    public void setCaller(ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.CI.SDObj> getRelatedCI() throws Exception;
    public void setRelatedCI(ObjHandle<com.bexp.ejb.CI.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.Person.SDObj> getAssignedTo() throws Exception;
    public void setAssignedTo(ObjHandle<com.bexp.ejb.Person.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.OrgUnit.Organization.SDObj> getAffectedOrganization() throws Exception;
    public void setAffectedOrganization(ObjHandle<com.bexp.ejb.OrgUnit.Organization.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.DecisionNode.SDObj> getRelatedDecisionTree() throws Exception;
    public void setRelatedDecisionTree(ObjHandle<com.bexp.ejb.DecisionNode.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.BE.BEType.SDObj> getBEType() throws Exception;
    public void setBEType(ObjHandle<com.bexp.ejb.BE.BEType.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.Process.SDObj> getProcedure() throws Exception;
    public void setProcedure(ObjHandle<com.bexp.ejb.Process.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.TypicalTask.SDObj> getTypicalTask() throws Exception;
    public void setTypicalTask(ObjHandle<com.bexp.ejb.TypicalTask.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.Service.SDObj> getService() throws Exception;
    public void setService(ObjHandle<com.bexp.ejb.Service.SDObj> handle) throws Exception;



    public Set<ObjHandle<com.bexp.ejb.Task.SDObj> > getRelatedTasks();
	public void setRelatedTasks(Set<ObjHandle<com.bexp.ejb.Task.SDObj> > _arg) throws Exception;




//---------------------------------------------------------------------------------
}