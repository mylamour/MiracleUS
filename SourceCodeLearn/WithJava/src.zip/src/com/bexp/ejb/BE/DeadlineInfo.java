package com.bexp.ejb.BE;

import com.bexp.ejb.ObjCMPBean;
public class DeadlineInfo
extends com.bexp.ejb.TimerInfo
implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;    
    
    public DeadlineInfo(Object pk)
        { super(pk,SDObjCMPBase.class); }
    
    public void act(ObjCMPBean cmp, javax.ejb.Timer timer)
        {
        ((SDObjCMPBase)cmp).onDeadline(timer);
        }
}