package com.bexp.ejb.BE.BEType;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.Obj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.BE.BEType.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.BE.BEType";
    
	protected java.lang.String ProcessType;
	public java.lang.String getProcessType() {
	 return ProcessType;  	 
	 }
	public void setProcessType(java.lang.String locProcessType) throws Exception { 
	ProcessType=locProcessType;
	}	


//---------------------------------------------------------------------------------------









//---------------------------------------------------------------------------------


    public void save() throws Exception
    {

     super.save();
    }
}