package com.bexp.ejb.BE;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.BE.SDObjCMPBase")
@Table(name = "BE")
public class SDObjCMPBase
    extends com.bexp.ejb.WorkflowObject.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   
	protected java.util.Date ActualStart;
	public java.util.Date getActualStart() {
	 return ActualStart;  	 
	 }
	public void setActualStart(java.util.Date locActualStart) throws Exception { 
	ActualStart=locActualStart;
	}	

	protected java.util.Date PlannedStart;
	public java.util.Date getPlannedStart() {
	 return PlannedStart;  	 
	 }
	public void setPlannedStart(java.util.Date locPlannedStart) throws Exception { 
	PlannedStart=locPlannedStart;
	}	

	protected java.util.Date ActualFinish;
	public java.util.Date getActualFinish() {
	 return ActualFinish;  	 
	 }
	public void setActualFinish(java.util.Date locActualFinish) throws Exception { 
	ActualFinish=locActualFinish;
	}	


protected TimerHandle deadline_handle;
protected java.util.Date frozen_deadline;

protected static java.util.concurrent.locks.Lock lock = new java.util.concurrent.locks.ReentrantLock();

    @Transient
    public java.util.Date getDeadline()
        {
        lock.lock();
        System.out.println("========== getDeadLine() reached ================");


        TimerHandle th = null;
        java.util.Date result = null;
        try
        {
         th = this.getDeadLineTimerHandle();
        } catch(Exception ex)
            {
            System.out.println(ex);
            System.out.println(ex.getCause());
            ex.printStackTrace();
            }
        if(th!=null)
	    {
            try
            {
            result = th.getTimer().getNextTimeout();
            } catch(Exception ex)
        	{
            System.out.println(ex.getMessage());
            ex.printStackTrace();
            } finally{  }
	    } else
	    { result = getFrozenDeadline(); }
	    
        lock.unlock();
        return result;
        }
    public void setDeadline(java.util.Date deadline) throws Exception
        {

        if(deadline!=null)
        if(deadline.after(new java.util.Date()))
            {
            TimerHandle th = this.getDeadLineTimerHandle();
            if(th!=null) { th.getTimer().cancel(); }
            setFrozenDeadline(deadline);


            TimerInfo tinfo = new DeadlineInfo(this.getPK());
                
            javax.ejb.Timer timer = //timerService.createTimer(deadline,tInfo);
                this.getLocalHome().createTimer(deadline,tinfo);
            th = timer.getHandle();
            this.setDeadLineTimerHandle(th);
            }

        }

public java.util.Date getFrozenDeadline()
    { return frozen_deadline; }
public void setFrozenDeadline(java.util.Date deadline)
    { frozen_deadline = deadline; }


@org.hibernate.annotations.Type(type="serializable")
public TimerHandle getDeadLineTimerHandle()
    { return deadline_handle; }
public void setDeadLineTimerHandle(TimerHandle dead_line)
    { deadline_handle = dead_line; }


@Transient
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)

    public void onDeadline(javax.ejb.Timer timer)
        {
        System.out.println("##############################################");
        System.out.println(
                "################### Deadline in "
                +EntityCMPBeanClass
                +". Hashcode:"+(new Integer(this.getPK().hashCode())).toString()
                        );
        System.out.println("##############################################");
        this.setFrozenDeadline(timer.getNextTimeout());
        this.setDeadLineTimerHandle(null);
        getEntityManager().merge(this);

    	try
    	    {
    	    System.out.println("~~~~ Sending message about deadline expiration.");
    	    com.bexp.ejb.IObjHome<com.bexp.ejb.Message.SDObj>
    		    msgHome = ObjSession.getSession().getHome(com.bexp.ejb.Message.SDObj.class);
            com.bexp.ejb.Message.ISDObjLocalHome msg_local_home =
                (com.bexp.ejb.Message.ISDObjLocalHome) msgHome;
            com.bexp.ejb.Person.SDObjCMPBase assigneeCMP =  this.getAssignedToCMP();
            if(assigneeCMP!=null)
                {
                Object _recipientPK= assigneeCMP.getPK();
                System.out.println("~~~~ Sending message to ASSIGNEE");
                com.bexp.ejb.Message.SDObj
                    assignee_msg = (com.bexp.ejb.Message.SDObj) msg_local_home.CREATEOBJ();
        	    assignee_msg.setRecipientPK(_recipientPK);
    	    
        	    assignee_msg.setDescription("deadline notification");
                
                List tmpll = msg_local_home.queryByDescriptionCMPs("deadline-assignee-message-template");
                if(tmpll.size()>0)
                    {
                    com.bexp.ejb.Message.SDObjCMPBase owner_templ
                        = (com.bexp.ejb.Message.SDObjCMPBase) tmpll.get(0);
                    assignee_msg.setMsgBody(owner_templ.getMsgBody());
                    }
                else
                    {
                    assignee_msg.setMsgBody("Deadline on object assigned to you with description '"+
                            this.getDescription()+"' expired.");
                    }
                msgHome.save(assignee_msg);
                }
                if(
                   (assigneeCMP==null)
                   ||
                   ((assigneeCMP!=null)&&(getOwnerCMP().getPK().equals(assigneeCMP.getPK())))
                   )
    		    {
                System.out.println("~~~~ Sending message to OWNER ");
                Object _recipientPK= this.getOwnerPK();
                com.bexp.ejb.Message.SDObj
                    owner_msg = (com.bexp.ejb.Message.SDObj) msg_local_home.CREATEOBJ();
                List tmpll = msg_local_home.queryByDescriptionCMPs("deadline-owner-message-template");
                if(tmpll.size()>0)
                    {
                    com.bexp.ejb.Message.SDObjCMPBase owner_templ
                        = (com.bexp.ejb.Message.SDObjCMPBase) tmpll.get(0);
                    owner_msg.setMsgBody(owner_templ.getMsgBody());
                    }
                else
                    {
                    owner_msg.setMsgBody("Deadline on object owned by you with description '"+
                            this.getDescription()+"' expired.");
                    }
    	        owner_msg.setRecipientPK(this.getOwnerPK());
    	        owner_msg.setDescription("deadline notification");

                msgHome.save(owner_msg);
    		    }
            
                {
                String msg_body = "Deadline on object subscribed to you with description '"+
                    this.getDescription()+"' expired."; 
                List tmpll = msg_local_home.queryByDescriptionCMPs("deadline-subscriber-message-template");
                
                if(tmpll.size()>0)
                    {
                    com.bexp.ejb.Message.SDObjCMPBase templ
                        = (com.bexp.ejb.Message.SDObjCMPBase) tmpll.get(0);
                    msg_body = templ.getMsgBody();
                    }

                for(com.bexp.ejb.Person.SDObjCMPBase cmp : getDeadlineRecipientsCMPs())
                    {
                    com.bexp.ejb.Message.SDObj
                        msg = msgHome.createObj();
                    msg.setRecipientPK(cmp.getPK());
                    
                    msg.setDescription("deadline notification");
                    msg.setMsgBody(msg_body);
                    msgHome.save(msg);
                    }
                }
	    
    	    }catch(Throwable th) { th.printStackTrace(); }
        }    
 
@Transient
public Set<ObjHandle<com.bexp.ejb.Person.SDObj> > getDeadlineRecipients()
 {
        return Obj.ObjsToHandles(this.getDeadlineRecipientsCMPs(),
            com.bexp.ejb.Person.SDObj.class, false);
        }
public void setDeadlineRecipients(Set<ObjHandle<com.bexp.ejb.Person.SDObj> > _arg) throws Exception
{
        setManyToMany(this.getDeadlineRecipientsCMPs(),
                _arg, com.bexp.ejb.Person.SDObjCMPBase.class, false);        
        }        

    java.util.Set<com.bexp.ejb.Person.SDObjCMPBase> deadlineRecipientsCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "BE_DeadlineRecipients",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.Person.SDObjCMPBase> getDeadlineRecipientsCMPs()
        { return deadlineRecipientsCMPs; }
    public void setDeadlineRecipientsCMPs(Set<com.bexp.ejb.Person.SDObjCMPBase> cmps)
        { deadlineRecipientsCMPs = cmps; }
//------------------------------------------------------------------------------



    @Transient
    public ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> getCaller() throws Exception
        {
        ObjCMPBean cmp = getCallerCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj>(cmp,com.bexp.ejb.OrgUnit.Employee.SDObj.class);
        }
    public void setCaller(ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setCallerCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.OrgUnit.Employee.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.OrgUnit.Employee.SDObjCMPBase callerCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.OrgUnit.Employee.SDObjCMPBase getCallerCMP()
        { return callerCMP; }
    public void setCallerCMP(com.bexp.ejb.OrgUnit.Employee.SDObjCMPBase cicmp)
        { callerCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.CI.SDObj> getRelatedCI() throws Exception
        {
        ObjCMPBean cmp = getRelatedCICMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.CI.SDObj>(cmp,com.bexp.ejb.CI.SDObj.class);
        }
    public void setRelatedCI(ObjHandle<com.bexp.ejb.CI.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setRelatedCICMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.CI.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.CI.SDObjCMPBase relatedCICMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.CI.SDObjCMPBase getRelatedCICMP()
        { return relatedCICMP; }
    public void setRelatedCICMP(com.bexp.ejb.CI.SDObjCMPBase cicmp)
        { relatedCICMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.Person.SDObj> getAssignedTo() throws Exception
        {
        ObjCMPBean cmp = getAssignedToCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Person.SDObj>(cmp,com.bexp.ejb.Person.SDObj.class);
        }
    public void setAssignedTo(ObjHandle<com.bexp.ejb.Person.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setAssignedToCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Person.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.Person.SDObjCMPBase assignedToCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Person.SDObjCMPBase getAssignedToCMP()
        { return assignedToCMP; }
    public void setAssignedToCMP(com.bexp.ejb.Person.SDObjCMPBase cicmp)
        { assignedToCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.OrgUnit.Organization.SDObj> getAffectedOrganization() throws Exception
        {
        ObjCMPBean cmp = getAffectedOrganizationCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.OrgUnit.Organization.SDObj>(cmp,com.bexp.ejb.OrgUnit.Organization.SDObj.class);
        }
    public void setAffectedOrganization(ObjHandle<com.bexp.ejb.OrgUnit.Organization.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setAffectedOrganizationCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.OrgUnit.Organization.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.OrgUnit.Organization.SDObjCMPBase affectedOrganizationCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.OrgUnit.Organization.SDObjCMPBase getAffectedOrganizationCMP()
        { return affectedOrganizationCMP; }
    public void setAffectedOrganizationCMP(com.bexp.ejb.OrgUnit.Organization.SDObjCMPBase cicmp)
        { affectedOrganizationCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.DecisionNode.SDObj> getRelatedDecisionTree() throws Exception
        {
        ObjCMPBean cmp = getRelatedDecisionTreeCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.DecisionNode.SDObj>(cmp,com.bexp.ejb.DecisionNode.SDObj.class);
        }
    public void setRelatedDecisionTree(ObjHandle<com.bexp.ejb.DecisionNode.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setRelatedDecisionTreeCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.DecisionNode.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.DecisionNode.SDObjCMPBase relatedDecisionTreeCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.DecisionNode.SDObjCMPBase getRelatedDecisionTreeCMP()
        { return relatedDecisionTreeCMP; }
    public void setRelatedDecisionTreeCMP(com.bexp.ejb.DecisionNode.SDObjCMPBase cicmp)
        { relatedDecisionTreeCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.BE.BEType.SDObj> getBEType() throws Exception
        {
        ObjCMPBean cmp = getBETypeCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.BE.BEType.SDObj>(cmp,com.bexp.ejb.BE.BEType.SDObj.class);
        }
    public void setBEType(ObjHandle<com.bexp.ejb.BE.BEType.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setBETypeCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.BE.BEType.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.BE.BEType.SDObjCMPBase bETypeCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.BE.BEType.SDObjCMPBase getBETypeCMP()
        { return bETypeCMP; }
    public void setBETypeCMP(com.bexp.ejb.BE.BEType.SDObjCMPBase cicmp)
        { bETypeCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.Process.SDObj> getProcedure() throws Exception
        {
        ObjCMPBean cmp = getProcedureCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Process.SDObj>(cmp,com.bexp.ejb.Process.SDObj.class);
        }
    public void setProcedure(ObjHandle<com.bexp.ejb.Process.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setProcedureCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Process.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.Process.SDObjCMPBase procedureCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Process.SDObjCMPBase getProcedureCMP()
        { return procedureCMP; }
    public void setProcedureCMP(com.bexp.ejb.Process.SDObjCMPBase cicmp)
        { procedureCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.TypicalTask.SDObj> getTypicalTask() throws Exception
        {
        ObjCMPBean cmp = getTypicalTaskCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.TypicalTask.SDObj>(cmp,com.bexp.ejb.TypicalTask.SDObj.class);
        }
    public void setTypicalTask(ObjHandle<com.bexp.ejb.TypicalTask.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setTypicalTaskCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.TypicalTask.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.TypicalTask.SDObjCMPBase typicalTaskCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.TypicalTask.SDObjCMPBase getTypicalTaskCMP()
        { return typicalTaskCMP; }
    public void setTypicalTaskCMP(com.bexp.ejb.TypicalTask.SDObjCMPBase cicmp)
        { typicalTaskCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.Service.SDObj> getService() throws Exception
        {
        ObjCMPBean cmp = getServiceCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Service.SDObj>(cmp,com.bexp.ejb.Service.SDObj.class);
        }
    public void setService(ObjHandle<com.bexp.ejb.Service.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setServiceCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Service.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.Service.SDObjCMPBase serviceCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Service.SDObjCMPBase getServiceCMP()
        { return serviceCMP; }
    public void setServiceCMP(com.bexp.ejb.Service.SDObjCMPBase cicmp)
        { serviceCMP = cicmp; }
//------------------------------------------------------------------------------



    @Transient
public Set<ObjHandle<com.bexp.ejb.Task.SDObj> > getRelatedTasks()
 {
        return Obj.ObjsToHandles(this.getRelatedTasksCMPs(),
            com.bexp.ejb.Task.SDObj.class, false);
        }
public void setRelatedTasks(Set<ObjHandle<com.bexp.ejb.Task.SDObj> > handles) throws Exception
 {
      setOneToMany(this.getRelatedTasksCMPs(),
             handles, com.bexp.ejb.Task.SDObjCMPBase.class,
                new function2<Void,com.bexp.ejb.Task.SDObjCMPBase, SDObjCMPBase>()
                {public Void Op(com.bexp.ejb.Task.SDObjCMPBase owner_cmp,SDObjCMPBase cmp)
                    { owner_cmp.setRelatedBusinessEventCMP(cmp); return null; }}
             ,false);
 }
    
        java.util.Set<com.bexp.ejb.Task.SDObjCMPBase> relatedTasksCMPs;
    @OneToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH,mappedBy="relatedBusinessEventCMP")
    public Set<com.bexp.ejb.Task.SDObjCMPBase> getRelatedTasksCMPs()
        { return relatedTasksCMPs; }
    public void setRelatedTasksCMPs (Set<com.bexp.ejb.Task.SDObjCMPBase> cmps)
        { relatedTasksCMPs = cmps;}   
//------------------------------------------------------------------------------            



//---------------------------------------------------------------------------------
}

