package com.bexp.ejb.Message;

import com.bexp.ejb.*;
public class MessageEvent
extends ObjHomeEvent<ISDObj>
implements java.io.Serializable
{
    public MessageEvent()
        {}
    
    protected MessageEvent(ISDObj obj, Object _recipientPK, int event_id)
        {
        super(obj, event_id);
        recipientPK = _recipientPK; 
        }
    
        Object recipientPK;
    public Object getRecipientPK()
        { return recipientPK; }
    public void setRecipientPK(Object _pk)
        { recipientPK = _pk; }
}