package com.bexp.ejb.Message;

import javax.persistence.*;
import java.util.*;
import javax.ejb.*;
import com.bexp.ejb.*;

@Remote
public interface ISDObjHome extends com.bexp.ejb.IObjHome
{


//---------------------------------------------------------------------------------
}
