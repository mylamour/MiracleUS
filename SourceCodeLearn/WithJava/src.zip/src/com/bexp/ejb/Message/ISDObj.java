package com.bexp.ejb.Message;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.IObj
{
    public java.lang.String getMsgBody();
    public void setMsgBody(java.lang.String locMsgBody) throws Exception;

    public java.lang.Boolean getIsRead();
    public void setIsRead(java.lang.Boolean locIsRead) throws Exception;


 








//---------------------------------------------------------------------------------
    public Object getRecipientPK();     public void setRecipientPK(Object _pk);
}