package com.bexp.ejb.Message;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.Obj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.Message.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.Message";
    
	protected java.lang.String MsgBody;
	public java.lang.String getMsgBody() {
	 return MsgBody;  	 
	 }
	public void setMsgBody(java.lang.String locMsgBody) throws Exception { 
	MsgBody=locMsgBody;
	}	

	protected java.lang.Boolean IsRead;
	public java.lang.Boolean getIsRead() {
	  if (IsRead == null) return false; 	 
 else return IsRead;
	 }
	public void setIsRead(java.lang.Boolean locIsRead) throws Exception { 
	IsRead=locIsRead;
	}	


//---------------------------------------------------------------------------------------









//---------------------------------------------------------------------------------
	Object recipientPK;
    public Object getRecipientPK()
	{ return recipientPK; }
    public void setRecipientPK(Object _pk)
	{ recipientPK = _pk; }
    
    public com.bexp.ejb.Person.ISDObj getRecipient() throws Exception
        {
        if(recipientPK==null) {return null;}
        else
        return (com.bexp.ejb.Person.ISDObj)
                    ObjSession.getSession().getHome(com.bexp.ejb.Person.SDObj.class)
                        .getObj(recipientPK);
        }
    public void setRecipient(com.bexp.ejb.Person.ISDObj _person) throws Exception
        { recipientPK = (_person!=null)?_person.getPK():null; }


    public void save() throws Exception
    {


     super.save();
    }
}