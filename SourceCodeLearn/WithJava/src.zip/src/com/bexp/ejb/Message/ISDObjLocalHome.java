package com.bexp.ejb.Message;
import com.bexp.ejb.*;
import java.util.*;

public interface ISDObjLocalHome
    extends com.bexp.ejb.IObjLocalHome
{

//---------------------------------------------------------------------------------
	public ObjHomeEvent CREATE_Event(IObj obj, int event_id);
}
