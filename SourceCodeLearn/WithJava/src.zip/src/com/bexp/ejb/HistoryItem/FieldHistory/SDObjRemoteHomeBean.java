package com.bexp.ejb.HistoryItem.FieldHistory;

import java.util.*;
import javax.annotation.*;
import javax.ejb.*;
import javax.persistence.*;
import javax.naming.*;

import org.jboss.annotation.security.SecurityDomain;
import com.bexp.ejb.*;

@Stateless(name="com.bexp.ejb.HistoryItem.FieldHistory.SDObjRemoteHomeBean")
@Remote(ISDObjHome.class)
@Local(ISDObjLocalHome.class)
@SecurityDomain("bexp")
public class SDObjRemoteHomeBean
	extends com.bexp.ejb.ObjHomeBean
    implements ISDObjHome,ISDObjLocalHome
{

//---------------------------------------------------------------------------------
  
//--------------------------------------------------------------------------------------        
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	 public ObjHandle<SDObj>
       createCouple(ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> _obj,String _person) throws Exception{
		 lock.lock();
		 try{
			 return ((ISDObjLocalHome)getLocalHome()).CREATE_COUPLE(_obj,_person);
		 }
		 finally{lock.unlock();}
	   }
	 @TransactionAttribute(TransactionAttributeType.REQUIRED)
	 public ObjHandle<SDObj>
       CREATE_COUPLE(ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> _obj,String _person) throws Exception
       {
       SDObjCMPBase cmp = (SDObjCMPBase)(EntityCMPBeanClass.newInstance());
       ObjHomeBean.getEM()
       .find(com.bexp.ejb.OrgUnit.Employee.SDObjCMPBase.class,_obj.getPK()).getPreviousLoginsCMPs().add(cmp);
       cmp.setDescription(_person);
       cmp.setCreation_time(Calendar.getInstance().getTime());       
       ObjHomeBean.getEM().persist(cmp);
       ObjHomeBean.getEM().flush();       
       return new ObjHandle<SDObj>(cmp.getPK(),false,SDObj.class,true) ;
       }

        
}
