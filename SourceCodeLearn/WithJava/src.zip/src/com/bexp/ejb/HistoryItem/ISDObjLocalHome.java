package com.bexp.ejb.HistoryItem;
import com.bexp.ejb.*;
import java.util.*;

public interface ISDObjLocalHome
    extends com.bexp.ejb.IObjLocalHome
{

//---------------------------------------------------------------------------------
}
