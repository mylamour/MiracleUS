package com.bexp.ejb.HistoryItem;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.Obj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.HistoryItem.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.HistoryItem";
    

//---------------------------------------------------------------------------------------









//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}