package com.bexp.ejb.HistoryItem.FieldHistory;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.Obj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.HistoryItem.FieldHistory.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.HistoryItem.FieldHistory";
    

//---------------------------------------------------------------------------------------





    ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> employee
            = new ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj>(null,false,com.bexp.ejb.OrgUnit.Employee.SDObj.class);
    public ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> getEmployee() throws Exception
        {
        return employee;
        }
    public void setEmployee(ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> handle) throws Exception
        {
        employee.copy(handle);
        employee.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------





//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}