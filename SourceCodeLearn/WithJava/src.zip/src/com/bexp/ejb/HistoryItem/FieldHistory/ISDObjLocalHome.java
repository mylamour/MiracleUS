package com.bexp.ejb.HistoryItem.FieldHistory;
import com.bexp.ejb.*;
import java.util.*;

public interface ISDObjLocalHome
    extends com.bexp.ejb.IObjLocalHome
{

//---------------------------------------------------------------------------------
public ObjHandle<SDObj> CREATE_COUPLE(ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> _obj,String _person) throws Exception;
}
