package com.bexp.ejb;


import java.lang.*;
import java.lang.reflect.*;
import java.util.*;
import javax.ejb.*;
import java.rmi.*;
import javax.jms.*;
import javax.naming.*;

/** @assoc 1 - * HomeEventProxy
  *
  */
public class HomeEventSource
{
/*
    protected javax.jms.Connection connection = null;
    protected ConnectionFactory connectionFactory = null;
    protected javax.jms.Topic topic = null;
    */
    protected TopicConnection connection = null;
    protected TopicConnectionFactory connectionFactory = null;
    protected Topic topic = null;
    
    protected static Map<String,HomeEventSource> srcs= new Hashtable<String,HomeEventSource>();
    /**
     * Suggestions about better solution?
     * */
    public static synchronized HomeEventSource getSingleton(String topic_name)
        {
        HomeEventSource evt_src = srcs.get(topic_name);
        if(evt_src==null)
            {
            evt_src = new HomeEventSource(topic_name, "ConnectionFactory");
            srcs.put(topic_name,evt_src);
            }
        return evt_src;
        }
    
    protected HomeEventSource(String topic_name, String cfactory_name)
        {
        System.out.println("~~~~~~~~~~~~~~~     HomeEventSource::constructor");
            try
            {
            Context namingContext = new InitialContext();
            topic = (Topic) namingContext.lookup("topic/"+topic_name);
            System.out.println("topic:"+((topic==null)?"null":"not null"));
            connectionFactory =
                (TopicConnectionFactory) namingContext.lookup("ConnectionFactory");
            }catch(Exception e)
                {
                System.out.println("HomeEventSource:"+e.toString());
                e.printStackTrace();
                }
        }
    
    public void wakeAll(ObjHomeEvent evt)
        {
	System.out.println("HomeEventSource::wakeAll");
        ObjectMessage message = null;
        TopicSession session = null;
        //MessageProducer publisher = null;
        TopicPublisher publisher = null;
        if(topic!=null)
        {
        try
            {
            connection = connectionFactory.createTopicConnection();
            session = connection.createTopicSession(false,TopicSession.AUTO_ACKNOWLEDGE);
	    connection.start();
//            publisher = session.createProducer(topic);
            publisher = session.createPublisher(topic);
            message = session.createObjectMessage();
            message.setObject(evt);
//            publisher.send(message);
            publisher.publish(message);
	    publisher.close();
	    connection.stop();
	    session.close();
            connection.close();
            }catch(Exception ex)
            {
            System.out.println(ex);
            System.out.println(ex.getCause());
            ex.printStackTrace();
            }
        } else {System.out.println("HomeEventSource: everything is null!");}
        }
}
