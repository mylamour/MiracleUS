package com.bexp.ejb;

import org.JWrapper.*;

//import java.rmi.*;

/** @assoc 1 - * IObj */
public interface IObjHome<Obj_t extends Obj>
{
    public Obj_t getObj(Object PK) throws Exception;
    
    public Obj[] getObjs(java.util.List PKs) throws Exception;
    
    public com.bexp.ejb.Access.SDObj getAccessObj() throws Exception;
    
    public Obj_t createObj() throws Exception;
    
    public void save(Obj obj) throws Exception;
//    public void copy(IObj from, IObj to) throws RemoteException;
    public void delete(Object PK) throws Exception;
    public ObjHandle<Obj_t>[] getAllObj() throws Exception;
    public ObjHandle<Obj_t>[] getAllTrash() throws Exception;
    
    public boolean isCreateAllowed() throws Exception;
    public boolean isViewAllowed() throws Exception;
    
    public <T> T query(function0<T> delegate) throws Exception;
    
    public void runGC() throws Exception;
    
//    public javax.ejb.Timer createTimer(java.util.Date exp, java.io.Serializable info) throws Exception;

}
