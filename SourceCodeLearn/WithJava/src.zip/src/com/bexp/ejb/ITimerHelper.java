package com.bexp.ejb;

import javax.persistence.EntityManagerFactory;

public interface ITimerHelper
    {
    public void timeout(javax.ejb.Timer timer);
    public javax.ejb.Timer createTimer(java.util.Date exp, java.io.Serializable info) throws Exception;
    }
