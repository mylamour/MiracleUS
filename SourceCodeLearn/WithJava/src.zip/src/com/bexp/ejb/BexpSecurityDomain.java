package com.bexp.ejb;

import org.jboss.security.*;

import java.security.acl.*;
import java.security.*;
//import javax.security.*;
import javax.security.auth.login.*;
import javax.security.auth.*;
import javax.ejb.*;
import javax.naming.*;
import javax.persistence.*;

import java.util.*;

import static com.bexp.ejb.ObjHomeBean.*;

public class BexpSecurityDomain
    extends org.jboss.security.auth.spi.UsersRolesLoginModule
{
    protected String getUsersPassword()
    {
    String password = null;//super.getUsersPassword();
//    if(password==null) 
        try
        {
        //!!!!!!!!!!!!
	//bexp_init();
        String username = getUsername();
        /*
        if(username==null)
            { return new String(""); }// OK? It is important for timeouts
          */  
        /*
        com.bexp.ejb.Person.ISDObjLocalHome home = (com.bexp.ejb.Person.ISDObjLocalHome) 
            ObjSession.getSession().getLocalHome(com.bexp.ejb.Person.SDObj.class);
        com.bexp.ejb.Person.SDObj person = home.getPersonByUsername(username);
        password = person.getPassword();
        */
        com.bexp.ejb.ISecurityDomainHelper helper = (com.bexp.ejb.ISecurityDomainHelper) 
            (new InitialContext()).lookup("com.bexp.ejb.SecurityDomainHelper/local");        
        EntityManagerFactory emf = helper.getEMF();
            //Persistence.createEntityManagerFactory("bexp_sd_db");
        EntityManager em
            = emf.createEntityManager();
        try
            {
            //em.getTransaction().begin();//4.0.4-
            System.out.println("BSDH: "+username);//testing
            com.bexp.ejb.Person.ISDObj person = (com.bexp.ejb.Person.ISDObj) 
                em.createQuery(
                    "SELECT DISTINCT p FROM com.bexp.ejb.Person.SDObjCMPBase p "+
                    "WHERE p.username='"+username+"'"
                    ).getSingleResult();
            password = person.getPassword();
            //em.flush();
            } finally { em.close();}
        /*
        */
        } catch(Throwable ex)
    	    {
    	    password = super.getUsersPassword();
            System.out.println("@@@@@@@@@@@@@@@@@@@@    "+ex);
    	    //ex.printStackTrace();
    	    //return null;
    	    }
    return password;
    }
    
    protected Group[] getRoleSets() throws LoginException
    {
    String username = getUsername();
    Vector<Group> result = new Vector<Group>();
    try
        {
        Group[] old_res = super.getRoleSets();
        for(Group g : old_res) { result.add(g); }
        } catch(LoginException ex)
        {
        //!!!!!!!!!!!!!!
        }
    result.add(new SimpleGroup("bexp_guests"));
    return result.toArray(new Group[0]);
    }
    
    /*
    protected void bexp_init()
    {
    try
    {
    com.bexp.ejb.Person.ISDObjLocalHome home = (com.bexp.ejb.Person.ISDObjLocalHome) 
        ObjSession.getSession().getLocalHome(com.bexp.ejb.Person.SDObj.class);
    if(home.getAllObj().length == 0)
        {
        System.out.println("Creating default users...");
	EntityManager
	    em = emf.createEntityManager();
        em.getTransaction().begin();
        com.bexp.ejb.Person.SDObjCMPBean
            guest = (com.bexp.ejb.Person.SDObjCMPBean)(com.bexp.ejb.Person.SDObjCMPBean.class.newInstance()),
            root  = (com.bexp.ejb.Person.SDObjCMPBean)(com.bexp.ejb.Person.SDObjCMPBean.class.newInstance());

        guest.setUsername("guest");
        guest.setPassword("guest");
        guest.setFullName("Guest");
        guest.setDescription("guest");

        root.setUsername("root");
        root.setPassword("admin");
        root.setFullName("Sysadmin Sysadminovich");
        root.setDescription("sysadmin");
        root.setCreatorCMP(root);
        guest.setCreatorCMP(root);

        em.persist(guest);
        em.persist(root);
	
        em.flush();
	em.close();
	}
    } catch(Exception ex) { ex.printStackTrace(); }
    
    }
    */
}
