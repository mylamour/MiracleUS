package com.bexp.ejb;

import java.util.*;
import java.util.concurrent.*;
//import java.util.concurrent.locks.*;

import javax.ejb.*;
import javax.naming.*;
import java.sql.*;
import java.rmi.*;
import javax.rmi.PortableRemoteObject;
import javax.jms.*;

import com.bexp.ASSERT;
import org.JWrapper.*;

public class HomeEventProxy extends Observable
    implements MessageListener, Runnable
{
    public TopicConnection topic_connection;
    public TopicSession topic_session;
    
    protected HomeEventProxy(String entity_name)
        {
        //System.out.println("TCF CL: "+this.getClass().getClassLoader());//testing
            topic_connection=null;
            topic_session = null;
            try
            {
            TopicConnectionFactory tcf = null;
            try
                {
                //System.out.println(TopicConnectionFactory.class.getName());// to fetch it
                Object ref =
                    ObjSession.getSession().ctx.lookup("ConnectionFactory");
                //System.out.println("================="+ObjSession.getSession().ctx.getClass().getClassLoader());//testing
                tcf = (TopicConnectionFactory) ref;
                System.out.println("TCF:"+((tcf==null)?"null":"not null"));
                }catch(Exception ex)
                    {
                    //System.out.println(ObjSession.getSession().getHostName()+"\n");
                    System.out.println("HomeEventProxy:TCF lookup :\n");
                    ex.printStackTrace();//testing
                    throw ex;
                    }
            topic_connection = tcf.createTopicConnection();
            topic_session = topic_connection.createTopicSession(false,
                Session.AUTO_ACKNOWLEDGE);
            Topic topic = null;
            try
                {
                topic = (Topic)
                    ObjSession.getSession().ctx.lookup("topic/"+entity_name+"Topic");
                }catch(Exception ex)
                    {
                    System.out.println("HomeEventProxy: Topic lookup :\n");
                    throw ex;
                    }
                System.out.println("!!!!!!!!!! topic:"+((topic==null)?"null":"not null"));
            TopicSubscriber tsub =
                topic_session.createSubscriber(topic);
            tsub.setMessageListener(this);
            topic_connection.start();
            }catch(Exception ex)
                {
                System.out.println("HomeEventProxy :\n"+ex);
                ex.printStackTrace();
                }
        }
    public void disconnect()
        {
            try
            {
            topic_connection.close();
            }catch(Exception e)
            {System.out.println("HomeEventProxy:"+e.toString());}
        }
    
    public BlockingQueue<ObjHomeEvent> events
        = new LinkedBlockingQueue<ObjHomeEvent>();
    
    public void onMessage(Message msg)
        {
        System.out.println("HomeEventProxy::<onMessage>");
            try
            {
            ObjHomeEvent evt = (ObjHomeEvent) ((ObjectMessage)msg).getObject();
            System.out.print("Altered obj with id:");
            System.out.println(evt.getObjectPK().hashCode());
            Thread.sleep(1000);//sleep for 1sec to prevent problems on high-performant networks
            events.put(evt);
            //this.notifyAll();
            }catch(Exception ex)
                {
                System.out.println("HomeEventProxy :\n"+ex);
                ex.printStackTrace();
                }
        System.out.println("HomeEventProxy::</onMessage>");
        }

        protected Signal1<ObjHomeEvent> recv_signal = new Signal1<ObjHomeEvent>();
    public Signal1<ObjHomeEvent> getRecvSignal()
        { return recv_signal; }

    
    public void broadcast(ObjHomeEvent evt)
        {
        System.out.println("HomeEventProxy::<broadcast>");
        /*
        System.out.println("HomeEventProxy: waiting for lock ...");
        lock.lock();
        System.out.println("HomeEventProxy: lock seized.");
        try
            {
            */
        ASSERT.setWaitingState(true);
        //---for compatibility with older code
        this.setChanged();
        this.notifyObservers(evt);
        //---
        try
        { recv_signal.Op(evt); }
            catch(Exception ex)
            {
            System.out.println("HomeEventProxy :\n"+ex);
            ex.printStackTrace();
            }
        ASSERT.setWaitingState(false);
            /*
            }
        catch (Exception ex)
            { ex.printStackTrace(); }
        finally
            {
            lock.unlock();
            System.out.println("HomeEventProxy: lock freed.");
            }
            */
        System.out.println("HomeEventProxy::</broadcast>");
        }
    
    //protected Lock lock = new ReentrantLock();
    //protected Condition locked = lock.newCondition();
    
    //public Lock getLock() { return lock; }
    
    public void run()
        {
        Thread.currentThread().setContextClassLoader(this.getClass().getClassLoader());
        while(true)
        try
            {
            //locked.await();
            ObjHomeEvent evt = events.take();
            //zThread.sleep(1000);//------VERY-VERY-BAD(but works)!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            broadcast(evt);
            } catch (Exception ex)
            { ex.printStackTrace(); }
        }
    
    @Deprecated
    public void addObserver(Observer o)
        { super.addObserver(o); }

}
