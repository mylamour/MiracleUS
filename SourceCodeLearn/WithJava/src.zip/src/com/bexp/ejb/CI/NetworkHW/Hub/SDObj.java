package com.bexp.ejb.CI.NetworkHW.Hub;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.CI.SDObj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.CI.NetworkHW.Hub.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.CI.NetworkHW.Hub";
    

//---------------------------------------------------------------------------------------

LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.NetCard.SDObj,SDObjCMPBase> relatedNetworkCards;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.NetCard.SDObj,SDObjCMPBase> getRelatedNetworkCards()
        {
        if(relatedNetworkCards==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.NetCard.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.NetCard.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedNetworkCardsCMPs(),
                    com.bexp.ejb.CI.NetworkHW.NetCard.SDObj.class, false);
            }
        }
		relatedNetworkCards = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.NetCard.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.NetworkHW.NetCard.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedNetworkCards;     
        }
    public void setRelatedNetworkCards(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.NetCard.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedNetworkCards.copy(lca); }        
//---------------------------------------------------------------------------------------








//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}