package com.bexp.ejb.CI;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.SDObjCMPBase")
@Table(name = "CI")
public class SDObjCMPBase
    extends com.bexp.ejb.ObjCMPBean
    implements ISDObj,java.io.Serializable
{
   
	protected java.lang.String ShortName;
	public java.lang.String getShortName() {
	 return ShortName;  	 
	 }
	public void setShortName(java.lang.String locShortName) throws Exception { 
	ShortName=locShortName;
	}	

	protected java.util.Date InstallTime;
	public java.util.Date getInstallTime() {
	 return InstallTime;  	 
	 }
	public void setInstallTime(java.util.Date locInstallTime) throws Exception { 
	InstallTime=locInstallTime;
	}	

	protected java.util.Date OrderTime;
	public java.util.Date getOrderTime() {
	 return OrderTime;  	 
	 }
	public void setOrderTime(java.util.Date locOrderTime) throws Exception { 
	OrderTime=locOrderTime;
	}	

	protected com.bexp.ejb.CI.Status Status;
	public com.bexp.ejb.CI.Status getStatus() {
	 return Status;  	 
	 }
	public void setStatus(com.bexp.ejb.CI.Status locStatus) throws Exception { 
	Status=locStatus;
	}	


 
@Transient
public Set<ObjHandle<com.bexp.ejb.SLA.SDObj> > getSLAs()
 {
        return Obj.ObjsToHandles(this.getSLAsCMPs(),
            com.bexp.ejb.SLA.SDObj.class, false);
        }
public void setSLAs(Set<ObjHandle<com.bexp.ejb.SLA.SDObj> > _arg) throws Exception
{
        setManyToMany(this.getSLAsCMPs(),
                _arg, com.bexp.ejb.SLA.SDObjCMPBase.class, false);        
        }        

    java.util.Set<com.bexp.ejb.SLA.SDObjCMPBase> sLAsCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "CI_SLAs",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.SLA.SDObjCMPBase> getSLAsCMPs()
        { return sLAsCMPs; }
    public void setSLAsCMPs(Set<com.bexp.ejb.SLA.SDObjCMPBase> cmps)
        { sLAsCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.Service.SDObj,SDObjCMPBase> getServices()
 {
        return null;
        }
public void setServices(LazyCollectionAccessAdapter<com.bexp.ejb.Service.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getServicesCMPs(),
                (Set)lca.get(), com.bexp.ejb.Service.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.Service.SDObjCMPBase> servicesCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "ci_service",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.Service.SDObjCMPBase> getServicesCMPs()
        { return servicesCMPs; }
    public void setServicesCMPs(Set<com.bexp.ejb.Service.SDObjCMPBase> cmps)
        { servicesCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.OrgUnit.SDObj,SDObjCMPBase> getSuppliers()
 {
        return null;
        }
public void setSuppliers(LazyCollectionAccessAdapter<com.bexp.ejb.OrgUnit.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getSuppliersCMPs(),
                (Set)lca.get(), com.bexp.ejb.OrgUnit.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.OrgUnit.SDObjCMPBase> suppliersCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "ci_suppliers",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.OrgUnit.SDObjCMPBase> getSuppliersCMPs()
        { return suppliersCMPs; }
    public void setSuppliersCMPs(Set<com.bexp.ejb.OrgUnit.SDObjCMPBase> cmps)
        { suppliersCMPs = cmps; }
//------------------------------------------------------------------------------


 @Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.OrgUnit.SDObj,SDObjCMPBase> getOrgUnits()
 {
        return null;
        }
public void setOrgUnits(LazyCollectionAccessAdapter<com.bexp.ejb.OrgUnit.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getOrgUnitsCMPs(),
                (Set)lca.get(), com.bexp.ejb.OrgUnit.SDObjCMPBase.class,
                false);
        }        

      java.util.Set<com.bexp.ejb.OrgUnit.SDObjCMPBase> orgUnitsCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "OrgUnit_CIs",
    joinColumns = {@JoinColumn(name = "ID2")},
        inverseJoinColumns = {@JoinColumn(name = "ID1")})
    public Set<com.bexp.ejb.OrgUnit.SDObjCMPBase> getOrgUnitsCMPs()
        { return orgUnitsCMPs; }
    public void setOrgUnitsCMPs(Set<com.bexp.ejb.OrgUnit.SDObjCMPBase> cmps)
        { orgUnitsCMPs = cmps; }

//------------------------------------------------------------------------------


    @Transient
    public ObjHandle<com.bexp.ejb.Location.Address.SDObj> getAddress() throws Exception
        {
        ObjCMPBean cmp = getAddressCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Location.Address.SDObj>(cmp,com.bexp.ejb.Location.Address.SDObj.class);
        }
    public void setAddress(ObjHandle<com.bexp.ejb.Location.Address.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setAddressCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Location.Address.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.Location.Address.SDObjCMPBase addressCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Location.Address.SDObjCMPBase getAddressCMP()
        { return addressCMP; }
    public void setAddressCMP(com.bexp.ejb.Location.Address.SDObjCMPBase cicmp)
        { addressCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> getResponsible() throws Exception
        {
        ObjCMPBean cmp = getResponsibleCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj>(cmp,com.bexp.ejb.OrgUnit.Employee.SDObj.class);
        }
    public void setResponsible(ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setResponsibleCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.OrgUnit.Employee.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.OrgUnit.Employee.SDObjCMPBase responsibleCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.OrgUnit.Employee.SDObjCMPBase getResponsibleCMP()
        { return responsibleCMP; }
    public void setResponsibleCMP(com.bexp.ejb.OrgUnit.Employee.SDObjCMPBase cicmp)
        { responsibleCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.OrgUnit.SDObj> getManufacturer() throws Exception
        {
        ObjCMPBean cmp = getManufacturerCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.OrgUnit.SDObj>(cmp,com.bexp.ejb.OrgUnit.SDObj.class);
        }
    public void setManufacturer(ObjHandle<com.bexp.ejb.OrgUnit.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setManufacturerCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.OrgUnit.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.OrgUnit.SDObjCMPBase manufacturerCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.OrgUnit.SDObjCMPBase getManufacturerCMP()
        { return manufacturerCMP; }
    public void setManufacturerCMP(com.bexp.ejb.OrgUnit.SDObjCMPBase cicmp)
        { manufacturerCMP = cicmp; }
//------------------------------------------------------------------------------



    @Transient
public Set<ObjHandle<com.bexp.ejb.BE.SDObj> > getBusinessEvents()
 {
        return Obj.ObjsToHandles(this.getBusinessEventsCMPs(),
            com.bexp.ejb.BE.SDObj.class, false);
        }
public void setBusinessEvents(Set<ObjHandle<com.bexp.ejb.BE.SDObj> > handles) throws Exception
 {
      setOneToMany(this.getBusinessEventsCMPs(),
             handles, com.bexp.ejb.BE.SDObjCMPBase.class,
                new function2<Void,com.bexp.ejb.BE.SDObjCMPBase, SDObjCMPBase>()
                {public Void Op(com.bexp.ejb.BE.SDObjCMPBase owner_cmp,SDObjCMPBase cmp)
                    { owner_cmp.setRelatedCICMP(cmp); return null; }}
             ,false);
 }
    
        java.util.Set<com.bexp.ejb.BE.SDObjCMPBase> businessEventsCMPs;
    @OneToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH,mappedBy="relatedCICMP")
    public Set<com.bexp.ejb.BE.SDObjCMPBase> getBusinessEventsCMPs()
        { return businessEventsCMPs; }
    public void setBusinessEventsCMPs (Set<com.bexp.ejb.BE.SDObjCMPBase> cmps)
        { businessEventsCMPs = cmps;}   
//------------------------------------------------------------------------------            
    @Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.Task.SDObj,SDObjCMPBase> getTasks()
 {
        return null;
        }
    public void setTasks(LazyCollectionAccessAdapter<com.bexp.ejb.Task.SDObj,SDObjCMPBase> lca) throws Exception
        {
      setOneToMany(this.getTasksCMPs(),
             (Set)lca.get(), com.bexp.ejb.Task.SDObjCMPBase.class,
                new function2<Void,com.bexp.ejb.Task.SDObjCMPBase, SDObjCMPBase>()
                {public Void Op(com.bexp.ejb.Task.SDObjCMPBase owner_cmp,SDObjCMPBase cmp)
                    { owner_cmp.setRelatedCICMP(cmp); return null; }}
             ,false);                 
        }        
    
        java.util.Set<com.bexp.ejb.Task.SDObjCMPBase> tasksCMPs;
    @OneToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH,mappedBy="relatedCICMP")
    public Set<com.bexp.ejb.Task.SDObjCMPBase> getTasksCMPs()
        { return tasksCMPs; }
    public void setTasksCMPs (Set<com.bexp.ejb.Task.SDObjCMPBase> cmps)
        { tasksCMPs = cmps;}   
//------------------------------------------------------------------------------            
    @Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.Workorder.SDObj,SDObjCMPBase> getWOs()
 {
        return null;
        }
    public void setWOs(LazyCollectionAccessAdapter<com.bexp.ejb.Workorder.SDObj,SDObjCMPBase> lca) throws Exception
        {
      setOneToMany(this.getWOsCMPs(),
             (Set)lca.get(), com.bexp.ejb.Workorder.SDObjCMPBase.class,
                new function2<Void,com.bexp.ejb.Workorder.SDObjCMPBase, SDObjCMPBase>()
                {public Void Op(com.bexp.ejb.Workorder.SDObjCMPBase owner_cmp,SDObjCMPBase cmp)
                    { owner_cmp.setRelatedCICMP(cmp); return null; }}
             ,false);                 
        }        
    
        java.util.Set<com.bexp.ejb.Workorder.SDObjCMPBase> wOsCMPs;
    @OneToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH,mappedBy="relatedCICMP")
    public Set<com.bexp.ejb.Workorder.SDObjCMPBase> getWOsCMPs()
        { return wOsCMPs; }
    public void setWOsCMPs (Set<com.bexp.ejb.Workorder.SDObjCMPBase> cmps)
        { wOsCMPs = cmps;}   
//------------------------------------------------------------------------------            



//---------------------------------------------------------------------------------
    @PrePersist
    public void pre_persist() throws Exception
        {
        super.pre_persist();
        this.setShortName("CI_"+this.getPK().toString());
        }
}

