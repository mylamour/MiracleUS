package com.bexp.ejb.CI.NetworkHW.NetCard;
import com.bexp.ejb.*;
import java.util.*;

public interface ISDObjLocalHome
    extends com.bexp.ejb.CI.ISDObjLocalHome
{

//---------------------------------------------------------------------------------
}
