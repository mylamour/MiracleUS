package com.bexp.ejb.CI.HW.UPS;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.CI.ISDObj
{
    public java.lang.String getSerialNumber();
    public void setSerialNumber(java.lang.String locSerialNumber) throws Exception;

    public java.lang.String getCost();
    public void setCost(java.lang.String locCost) throws Exception;


 
	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> getRelatedPC();
	public void setRelatedPC(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> lca) throws Exception;









//---------------------------------------------------------------------------------
}