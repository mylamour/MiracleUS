package com.bexp.ejb.CI.Networks.IPAddress;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.Networks.IPAddress.SDObjCMPBase")
@Table(name = "IPAddress")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   
	protected java.lang.String Mask;
	public java.lang.String getMask() {
	 return Mask;  	 
	 }
	public void setMask(java.lang.String locMask) throws Exception { 
	Mask=locMask;
	}	


 
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.Networks.IPNetwork.SDObj,SDObjCMPBase> getRelatedIPNetwork()
 {
        return null;
        }
public void setRelatedIPNetwork(LazyCollectionAccessAdapter<com.bexp.ejb.CI.Networks.IPNetwork.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedIPNetworkCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.Networks.IPNetwork.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.Networks.IPNetwork.SDObjCMPBase> relatedIPNetworkCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "IPAddress_RelatedIPNetwork",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.Networks.IPNetwork.SDObjCMPBase> getRelatedIPNetworkCMPs()
        { return relatedIPNetworkCMPs; }
    public void setRelatedIPNetworkCMPs(Set<com.bexp.ejb.CI.Networks.IPNetwork.SDObjCMPBase> cmps)
        { relatedIPNetworkCMPs = cmps; }
//------------------------------------------------------------------------------








//---------------------------------------------------------------------------------
}

