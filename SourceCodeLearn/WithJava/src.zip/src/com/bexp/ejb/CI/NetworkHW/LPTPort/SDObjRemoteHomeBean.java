package com.bexp.ejb.CI.NetworkHW.LPTPort;

import java.util.*;
import javax.annotation.*;
import javax.ejb.*;
import javax.persistence.*;
import javax.naming.*;

import org.jboss.annotation.security.SecurityDomain;
import com.bexp.ejb.*;

@Stateless(name="com.bexp.ejb.CI.NetworkHW.LPTPort.SDObjRemoteHomeBean")
@Remote(ISDObjHome.class)
@Local(ISDObjLocalHome.class)
@SecurityDomain("bexp")
public class SDObjRemoteHomeBean
	extends com.bexp.ejb.CI.SDObjRemoteHomeBean
    implements ISDObjHome,ISDObjLocalHome
{

//---------------------------------------------------------------------------------
  
//--------------------------------------------------------------------------------------        

        
}
