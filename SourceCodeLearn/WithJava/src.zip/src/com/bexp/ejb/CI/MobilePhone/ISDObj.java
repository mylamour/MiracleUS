package com.bexp.ejb.CI.MobilePhone;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.CI.ISDObj
{

 



    public ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> getEmployee() throws Exception;
    public void setEmployee(ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> handle) throws Exception;






//---------------------------------------------------------------------------------
}