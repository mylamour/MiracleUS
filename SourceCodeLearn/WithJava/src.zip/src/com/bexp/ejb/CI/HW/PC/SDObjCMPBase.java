package com.bexp.ejb.CI.HW.PC;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.HW.PC.SDObjCMPBase")
@Table(name = "PC")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   
	protected java.lang.String SerialNumber;
	public java.lang.String getSerialNumber() {
	 return SerialNumber;  	 
	 }
	public void setSerialNumber(java.lang.String locSerialNumber) throws Exception { 
	SerialNumber=locSerialNumber;
	}	

	protected java.lang.String Cost;
	public java.lang.String getCost() {
	 return Cost;  	 
	 }
	public void setCost(java.lang.String locCost) throws Exception { 
	Cost=locCost;
	}	


 
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj,SDObjCMPBase> getEthernetPort()
 {
        return null;
        }
public void setEthernetPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getEthernetPortCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObjCMPBase> ethernetPortCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_EthernetPort",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObjCMPBase> getEthernetPortCMPs()
        { return ethernetPortCMPs; }
    public void setEthernetPortCMPs(Set<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObjCMPBase> cmps)
        { ethernetPortCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj,SDObjCMPBase> getComPort()
 {
        return null;
        }
public void setComPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getComPortCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.ComPort.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.NetworkHW.ComPort.SDObjCMPBase> comPortCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_ComPort",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.NetworkHW.ComPort.SDObjCMPBase> getComPortCMPs()
        { return comPortCMPs; }
    public void setComPortCMPs(Set<com.bexp.ejb.CI.NetworkHW.ComPort.SDObjCMPBase> cmps)
        { comPortCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Mouse.SDObj,SDObjCMPBase> getMouse()
 {
        return null;
        }
public void setMouse(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Mouse.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getMouseCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.HW.Mouse.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.HW.Mouse.SDObjCMPBase> mouseCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_Mouse",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.HW.Mouse.SDObjCMPBase> getMouseCMPs()
        { return mouseCMPs; }
    public void setMouseCMPs(Set<com.bexp.ejb.CI.HW.Mouse.SDObjCMPBase> cmps)
        { mouseCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Monitor.SDObj,SDObjCMPBase> getMonitor()
 {
        return null;
        }
public void setMonitor(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Monitor.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getMonitorCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.HW.Monitor.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.HW.Monitor.SDObjCMPBase> monitorCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_Monitor",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.HW.Monitor.SDObjCMPBase> getMonitorCMPs()
        { return monitorCMPs; }
    public void setMonitorCMPs(Set<com.bexp.ejb.CI.HW.Monitor.SDObjCMPBase> cmps)
        { monitorCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.OfficeHW.Printer.SDObj,SDObjCMPBase> getPrinter()
 {
        return null;
        }
public void setPrinter(LazyCollectionAccessAdapter<com.bexp.ejb.CI.OfficeHW.Printer.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getPrinterCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.OfficeHW.Printer.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.OfficeHW.Printer.SDObjCMPBase> printerCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_Printer",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.OfficeHW.Printer.SDObjCMPBase> getPrinterCMPs()
        { return printerCMPs; }
    public void setPrinterCMPs(Set<com.bexp.ejb.CI.OfficeHW.Printer.SDObjCMPBase> cmps)
        { printerCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.MotherBoard.SDObj,SDObjCMPBase> getMotherBoard()
 {
        return null;
        }
public void setMotherBoard(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.MotherBoard.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getMotherBoardCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.HW.MotherBoard.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.HW.MotherBoard.SDObjCMPBase> motherBoardCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_MotherBoard",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.HW.MotherBoard.SDObjCMPBase> getMotherBoardCMPs()
        { return motherBoardCMPs; }
    public void setMotherBoardCMPs(Set<com.bexp.ejb.CI.HW.MotherBoard.SDObjCMPBase> cmps)
        { motherBoardCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> getLANer()
 {
        return null;
        }
public void setLANer(LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getLANerCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.LAN.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.LAN.SDObjCMPBase> lANerCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_LANer",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.LAN.SDObjCMPBase> getLANerCMPs()
        { return lANerCMPs; }
    public void setLANerCMPs(Set<com.bexp.ejb.CI.LAN.SDObjCMPBase> cmps)
        { lANerCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.VideoCard.SDObj,SDObjCMPBase> getVideoCard()
 {
        return null;
        }
public void setVideoCard(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.VideoCard.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getVideoCardCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.HW.VideoCard.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.HW.VideoCard.SDObjCMPBase> videoCardCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_VideoCard",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.HW.VideoCard.SDObjCMPBase> getVideoCardCMPs()
        { return videoCardCMPs; }
    public void setVideoCardCMPs(Set<com.bexp.ejb.CI.HW.VideoCard.SDObjCMPBase> cmps)
        { videoCardCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.NetCard.SDObj,SDObjCMPBase> getNetworkCard()
 {
        return null;
        }
public void setNetworkCard(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.NetCard.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getNetworkCardCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.NetCard.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.NetworkHW.NetCard.SDObjCMPBase> networkCardCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_NetworkCard",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.NetworkHW.NetCard.SDObjCMPBase> getNetworkCardCMPs()
        { return networkCardCMPs; }
    public void setNetworkCardCMPs(Set<com.bexp.ejb.CI.NetworkHW.NetCard.SDObjCMPBase> cmps)
        { networkCardCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OfficeSW.SDObj,SDObjCMPBase> getOfficeSW()
 {
        return null;
        }
public void setOfficeSW(LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OfficeSW.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getOfficeSWCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.SW.OfficeSW.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.SW.OfficeSW.SDObjCMPBase> officeSWCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_OfficeSW",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.SW.OfficeSW.SDObjCMPBase> getOfficeSWCMPs()
        { return officeSWCMPs; }
    public void setOfficeSWCMPs(Set<com.bexp.ejb.CI.SW.OfficeSW.SDObjCMPBase> cmps)
        { officeSWCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.ServicePack.SDObj,SDObjCMPBase> getServicePack()
 {
        return null;
        }
public void setServicePack(LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.ServicePack.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getServicePackCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.SW.ServicePack.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.SW.ServicePack.SDObjCMPBase> servicePackCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_ServicePack",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.SW.ServicePack.SDObjCMPBase> getServicePackCMPs()
        { return servicePackCMPs; }
    public void setServicePackCMPs(Set<com.bexp.ejb.CI.SW.ServicePack.SDObjCMPBase> cmps)
        { servicePackCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.CDWriter.SDObj,SDObjCMPBase> getCDWriter()
 {
        return null;
        }
public void setCDWriter(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.CDWriter.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getCDWriterCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.HW.CDWriter.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.HW.CDWriter.SDObjCMPBase> cDWriterCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "cdwriter_pc",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.HW.CDWriter.SDObjCMPBase> getCDWriterCMPs()
        { return cDWriterCMPs; }
    public void setCDWriterCMPs(Set<com.bexp.ejb.CI.HW.CDWriter.SDObjCMPBase> cmps)
        { cDWriterCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OS.SDObj,SDObjCMPBase> getOS()
 {
        return null;
        }
public void setOS(LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OS.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getOSCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.SW.OS.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.SW.OS.SDObjCMPBase> oSCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_OS",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.SW.OS.SDObjCMPBase> getOSCMPs()
        { return oSCMPs; }
    public void setOSCMPs(Set<com.bexp.ejb.CI.SW.OS.SDObjCMPBase> cmps)
        { oSCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.HDD.SDObj,SDObjCMPBase> getHDDs()
 {
        return null;
        }
public void setHDDs(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.HDD.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getHDDsCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.HW.HDD.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.HW.HDD.SDObjCMPBase> hDDsCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_HDDs",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.HW.HDD.SDObjCMPBase> getHDDsCMPs()
        { return hDDsCMPs; }
    public void setHDDsCMPs(Set<com.bexp.ejb.CI.HW.HDD.SDObjCMPBase> cmps)
        { hDDsCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Keyboard.SDObj,SDObjCMPBase> getKeyboards()
 {
        return null;
        }
public void setKeyboards(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Keyboard.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getKeyboardsCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.HW.Keyboard.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.HW.Keyboard.SDObjCMPBase> keyboardsCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_Keyboards",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.HW.Keyboard.SDObjCMPBase> getKeyboardsCMPs()
        { return keyboardsCMPs; }
    public void setKeyboardsCMPs(Set<com.bexp.ejb.CI.HW.Keyboard.SDObjCMPBase> cmps)
        { keyboardsCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> getLPTPort()
 {
        return null;
        }
public void setLPTPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getLPTPortCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.LPTPort.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObjCMPBase> lPTPortCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_LPTPort",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObjCMPBase> getLPTPortCMPs()
        { return lPTPortCMPs; }
    public void setLPTPortCMPs(Set<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObjCMPBase> cmps)
        { lPTPortCMPs = cmps; }
//------------------------------------------------------------------------------








//---------------------------------------------------------------------------------
}

