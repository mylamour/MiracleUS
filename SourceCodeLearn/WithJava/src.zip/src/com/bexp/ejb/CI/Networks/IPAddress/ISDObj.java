package com.bexp.ejb.CI.Networks.IPAddress;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.CI.ISDObj
{
    public java.lang.String getMask();
    public void setMask(java.lang.String locMask) throws Exception;


 
	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.Networks.IPNetwork.SDObj,SDObjCMPBase> getRelatedIPNetwork();
	public void setRelatedIPNetwork(LazyCollectionAccessAdapter<com.bexp.ejb.CI.Networks.IPNetwork.SDObj,SDObjCMPBase> lca) throws Exception;









//---------------------------------------------------------------------------------
}