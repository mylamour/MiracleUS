package com.bexp.ejb.CI.HW.DigitalPhotoCamera;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.CI.ISDObj
{
    public java.lang.String getSerialNumber();
    public void setSerialNumber(java.lang.String locSerialNumber) throws Exception;

    public java.lang.String getCost();
    public void setCost(java.lang.String locCost) throws Exception;


 








//---------------------------------------------------------------------------------
}