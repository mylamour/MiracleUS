package com.bexp.ejb.CI.OfficeHW.Projector;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.CI.SDObj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.CI.OfficeHW.Projector.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.CI.OfficeHW.Projector";
    

//---------------------------------------------------------------------------------------









//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}