package com.bexp.ejb.CI.Networks.IPNetwork;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.Networks.IPNetwork.SDObjCMPBase")
@Table(name = "IPNetwork")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   

 


 @Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.Networks.IPAddress.SDObj,SDObjCMPBase> getRelatedIPAddress()
 {
        return null;
        }
public void setRelatedIPAddress(LazyCollectionAccessAdapter<com.bexp.ejb.CI.Networks.IPAddress.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedIPAddressCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.Networks.IPAddress.SDObjCMPBase.class,
                false);
        }        

      java.util.Set<com.bexp.ejb.CI.Networks.IPAddress.SDObjCMPBase> relatedIPAddressCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "IPAddress_RelatedIPNetwork",
    joinColumns = {@JoinColumn(name = "ID2")},
        inverseJoinColumns = {@JoinColumn(name = "ID1")})
    public Set<com.bexp.ejb.CI.Networks.IPAddress.SDObjCMPBase> getRelatedIPAddressCMPs()
        { return relatedIPAddressCMPs; }
    public void setRelatedIPAddressCMPs(Set<com.bexp.ejb.CI.Networks.IPAddress.SDObjCMPBase> cmps)
        { relatedIPAddressCMPs = cmps; }

//------------------------------------------------------------------------------

 @Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> getRelatedLAN()
 {
        return null;
        }
public void setRelatedLAN(LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedLANCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.LAN.SDObjCMPBase.class,
                false);
        }        

      java.util.Set<com.bexp.ejb.CI.LAN.SDObjCMPBase> relatedLANCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "LAN_RelatedIPNetwork",
    joinColumns = {@JoinColumn(name = "ID2")},
        inverseJoinColumns = {@JoinColumn(name = "ID1")})
    public Set<com.bexp.ejb.CI.LAN.SDObjCMPBase> getRelatedLANCMPs()
        { return relatedLANCMPs; }
    public void setRelatedLANCMPs(Set<com.bexp.ejb.CI.LAN.SDObjCMPBase> cmps)
        { relatedLANCMPs = cmps; }

//------------------------------------------------------------------------------







//---------------------------------------------------------------------------------
}

