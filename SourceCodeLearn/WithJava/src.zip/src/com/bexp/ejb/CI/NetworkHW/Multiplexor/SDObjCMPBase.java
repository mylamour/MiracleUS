package com.bexp.ejb.CI.NetworkHW.Multiplexor;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.NetworkHW.Multiplexor.SDObjCMPBase")
@Table(name = "Multiplexor")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   

 
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Cable.SDObj,SDObjCMPBase> getRelatedCable()
 {
        return null;
        }
public void setRelatedCable(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Cable.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedCableCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.Cable.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.NetworkHW.Cable.SDObjCMPBase> relatedCableCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "cable_multiplexor",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.NetworkHW.Cable.SDObjCMPBase> getRelatedCableCMPs()
        { return relatedCableCMPs; }
    public void setRelatedCableCMPs(Set<com.bexp.ejb.CI.NetworkHW.Cable.SDObjCMPBase> cmps)
        { relatedCableCMPs = cmps; }
//------------------------------------------------------------------------------








//---------------------------------------------------------------------------------
}

