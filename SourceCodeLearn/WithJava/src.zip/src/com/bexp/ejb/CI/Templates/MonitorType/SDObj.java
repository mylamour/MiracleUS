package com.bexp.ejb.CI.Templates.MonitorType;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.CI.SDObj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.CI.Templates.MonitorType.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.CI.Templates.MonitorType";
    

//---------------------------------------------------------------------------------------

LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> relatedPC;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> getRelatedPC()
        {
        if(relatedPC==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.HW.PC.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.HW.PC.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedPCCMPs(),
                    com.bexp.ejb.CI.HW.PC.SDObj.class, false);
            }
        }
		relatedPC = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.HW.PC.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedPC;     
        }
    public void setRelatedPC(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedPC.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Monitor.SDObj,SDObjCMPBase> relatedMonitor;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Monitor.SDObj,SDObjCMPBase> getRelatedMonitor()
        {
        if(relatedMonitor==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.HW.Monitor.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.HW.Monitor.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedMonitorCMPs(),
                    com.bexp.ejb.CI.HW.Monitor.SDObj.class, false);
            }
        }
		relatedMonitor = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Monitor.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.HW.Monitor.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedMonitor;     
        }
    public void setRelatedMonitor(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Monitor.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedMonitor.copy(lca); }        
//---------------------------------------------------------------------------------------








//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}