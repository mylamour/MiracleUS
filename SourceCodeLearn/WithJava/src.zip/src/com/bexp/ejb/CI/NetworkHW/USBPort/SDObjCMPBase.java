package com.bexp.ejb.CI.NetworkHW.USBPort;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.NetworkHW.USBPort.SDObjCMPBase")
@Table(name = "USBPort")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   

 
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Router.SDObj,SDObjCMPBase> getRelatedRouter()
 {
        return null;
        }
public void setRelatedRouter(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Router.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedRouterCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.Router.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.NetworkHW.Router.SDObjCMPBase> relatedRouterCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "USBPort_RelatedRouter",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.NetworkHW.Router.SDObjCMPBase> getRelatedRouterCMPs()
        { return relatedRouterCMPs; }
    public void setRelatedRouterCMPs(Set<com.bexp.ejb.CI.NetworkHW.Router.SDObjCMPBase> cmps)
        { relatedRouterCMPs = cmps; }
//------------------------------------------------------------------------------








//---------------------------------------------------------------------------------
}

