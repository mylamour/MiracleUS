package com.bexp.ejb.CI.NetworkHW.Router;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.CI.SDObj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.CI.NetworkHW.Router.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.CI.NetworkHW.Router";
    

//---------------------------------------------------------------------------------------


LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.USBPort.SDObj,SDObjCMPBase> uSBPort;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.USBPort.SDObj,SDObjCMPBase> getUSBPort()
        {
        if(uSBPort==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.USBPort.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.USBPort.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getUSBPortCMPs(),
                    com.bexp.ejb.CI.NetworkHW.USBPort.SDObj.class, false);
            }
        }
	uSBPort = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.USBPort.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.NetworkHW.USBPort.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  uSBPort;
        }
    public void setUSBPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.USBPort.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) uSBPort.copy(lca); }        
        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj,SDObjCMPBase> serialPort;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj,SDObjCMPBase> getSerialPort()
        {
        if(serialPort==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getSerialPortCMPs(),
                    com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj.class, false);
            }
        }
	serialPort = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  serialPort;
        }
    public void setSerialPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) serialPort.copy(lca); }        
        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj,SDObjCMPBase> ethernetPort;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj,SDObjCMPBase> getEthernetPort()
        {
        if(ethernetPort==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getEthernetPortCMPs(),
                    com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj.class, false);
            }
        }
	ethernetPort = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  ethernetPort;
        }
    public void setEthernetPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) ethernetPort.copy(lca); }        
        
//---------------------------------------------------------------------------------------







//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}