package com.bexp.ejb.CI.OfficePhone;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.CI.SDObj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.CI.OfficePhone.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.CI.OfficePhone";
    

//---------------------------------------------------------------------------------------

    Set<ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> > employees = new CopyOnWriteArraySet();    
    public Set<ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> > getEmployees()
        { return employees; }
    public void setEmployees(Set<ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> > _arg) throws Exception
        { employees.clear(); if(_arg!=null) {employees.addAll(_arg);} }        
//---------------------------------------------------------------------------------------








//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}