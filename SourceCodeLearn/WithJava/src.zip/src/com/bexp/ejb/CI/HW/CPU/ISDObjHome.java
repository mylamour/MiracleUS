package com.bexp.ejb.CI.HW.CPU;

import javax.persistence.*;
import java.util.*;
import javax.ejb.*;
import com.bexp.ejb.*;

@Remote
public interface ISDObjHome extends com.bexp.ejb.CI.ISDObjHome
{


//---------------------------------------------------------------------------------
}
