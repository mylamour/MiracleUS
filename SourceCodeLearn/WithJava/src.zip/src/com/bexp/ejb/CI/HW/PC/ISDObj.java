package com.bexp.ejb.CI.HW.PC;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.CI.ISDObj
{
    public java.lang.String getSerialNumber();
    public void setSerialNumber(java.lang.String locSerialNumber) throws Exception;

    public java.lang.String getCost();
    public void setCost(java.lang.String locCost) throws Exception;


 
	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj,SDObjCMPBase> getEthernetPort();
	public void setEthernetPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj,SDObjCMPBase> getComPort();
	public void setComPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Mouse.SDObj,SDObjCMPBase> getMouse();
	public void setMouse(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Mouse.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Monitor.SDObj,SDObjCMPBase> getMonitor();
	public void setMonitor(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Monitor.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.OfficeHW.Printer.SDObj,SDObjCMPBase> getPrinter();
	public void setPrinter(LazyCollectionAccessAdapter<com.bexp.ejb.CI.OfficeHW.Printer.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.MotherBoard.SDObj,SDObjCMPBase> getMotherBoard();
	public void setMotherBoard(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.MotherBoard.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> getLANer();
	public void setLANer(LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.VideoCard.SDObj,SDObjCMPBase> getVideoCard();
	public void setVideoCard(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.VideoCard.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.NetCard.SDObj,SDObjCMPBase> getNetworkCard();
	public void setNetworkCard(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.NetCard.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OfficeSW.SDObj,SDObjCMPBase> getOfficeSW();
	public void setOfficeSW(LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OfficeSW.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.ServicePack.SDObj,SDObjCMPBase> getServicePack();
	public void setServicePack(LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.ServicePack.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.CDWriter.SDObj,SDObjCMPBase> getCDWriter();
	public void setCDWriter(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.CDWriter.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OS.SDObj,SDObjCMPBase> getOS();
	public void setOS(LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OS.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.HDD.SDObj,SDObjCMPBase> getHDDs();
	public void setHDDs(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.HDD.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Keyboard.SDObj,SDObjCMPBase> getKeyboards();
	public void setKeyboards(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Keyboard.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> getLPTPort();
	public void setLPTPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> lca) throws Exception;









//---------------------------------------------------------------------------------
}