package com.bexp.ejb.CI.HW.CPU;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.CI.SDObj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.CI.HW.CPU.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.CI.HW.CPU";
    
	protected java.lang.String SerialNumber;
	public java.lang.String getSerialNumber() {
	 return SerialNumber;  	 
	 }
	public void setSerialNumber(java.lang.String locSerialNumber) throws Exception { 
	SerialNumber=locSerialNumber;
	}	

	protected java.lang.String Cost;
	public java.lang.String getCost() {
	 return Cost;  	 
	 }
	public void setCost(java.lang.String locCost) throws Exception { 
	Cost=locCost;
	}	


//---------------------------------------------------------------------------------------

LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.MotherBoard.SDObj,SDObjCMPBase> relatedMotherBoard;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.MotherBoard.SDObj,SDObjCMPBase> getRelatedMotherBoard()
        {
        if(relatedMotherBoard==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.HW.MotherBoard.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.HW.MotherBoard.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedMotherBoardCMPs(),
                    com.bexp.ejb.CI.HW.MotherBoard.SDObj.class, false);
            }
        }
		relatedMotherBoard = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.MotherBoard.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.HW.MotherBoard.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedMotherBoard;     
        }
    public void setRelatedMotherBoard(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.MotherBoard.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedMotherBoard.copy(lca); }        
//---------------------------------------------------------------------------------------








//---------------------------------------------------------------------------------


    public void save() throws Exception
    {


     super.save();
    }
}