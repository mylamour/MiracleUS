package com.bexp.ejb.CI.NetworkHW.Switch;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.CI.SDObj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.CI.NetworkHW.Switch.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.CI.NetworkHW.Switch";
    

//---------------------------------------------------------------------------------------


LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Cable.SDObj,SDObjCMPBase> relatedCable;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Cable.SDObj,SDObjCMPBase> getRelatedCable()
        {
        if(relatedCable==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.Cable.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.Cable.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedCableCMPs(),
                    com.bexp.ejb.CI.NetworkHW.Cable.SDObj.class, false);
            }
        }
	relatedCable = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Cable.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.NetworkHW.Cable.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedCable;
        }
    public void setRelatedCable(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Cable.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedCable.copy(lca); }        
        
//---------------------------------------------------------------------------------------







//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}