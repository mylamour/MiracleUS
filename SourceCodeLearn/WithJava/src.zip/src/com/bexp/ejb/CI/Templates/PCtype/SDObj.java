package com.bexp.ejb.CI.Templates.PCtype;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.CI.SDObj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.CI.Templates.PCtype.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.CI.Templates.PCtype";
    

//---------------------------------------------------------------------------------------

LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OfficeSW.SDObj,SDObjCMPBase> relatedOfficeSW;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OfficeSW.SDObj,SDObjCMPBase> getRelatedOfficeSW()
        {
        if(relatedOfficeSW==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.SW.OfficeSW.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.SW.OfficeSW.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedOfficeSWCMPs(),
                    com.bexp.ejb.CI.SW.OfficeSW.SDObj.class, false);
            }
        }
		relatedOfficeSW = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OfficeSW.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.SW.OfficeSW.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedOfficeSW;     
        }
    public void setRelatedOfficeSW(LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OfficeSW.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedOfficeSW.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> relatedPC;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> getRelatedPC()
        {
        if(relatedPC==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.HW.PC.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.HW.PC.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedPCCMPs(),
                    com.bexp.ejb.CI.HW.PC.SDObj.class, false);
            }
        }
		relatedPC = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.HW.PC.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedPC;     
        }
    public void setRelatedPC(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedPC.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> lPTPort;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> getLPTPort()
        {
        if(lPTPort==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getLPTPortCMPs(),
                    com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj.class, false);
            }
        }
		lPTPort = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  lPTPort;     
        }
    public void setLPTPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) lPTPort.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj,SDObjCMPBase> comPort;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj,SDObjCMPBase> getComPort()
        {
        if(comPort==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getComPortCMPs(),
                    com.bexp.ejb.CI.NetworkHW.ComPort.SDObj.class, false);
            }
        }
		comPort = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.NetworkHW.ComPort.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  comPort;     
        }
    public void setComPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) comPort.copy(lca); }        
//---------------------------------------------------------------------------------------

LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OS.SDObj,SDObjCMPBase> relatedOS;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OS.SDObj,SDObjCMPBase> getRelatedOS()
        {
        if(relatedOS==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.SW.OS.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.SW.OS.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedOSCMPs(),
                    com.bexp.ejb.CI.SW.OS.SDObj.class, false);
            }
        }
	relatedOS = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OS.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.SW.OS.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedOS;
        }
    public void setRelatedOS(LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OS.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedOS.copy(lca); }        
        
//---------------------------------------------------------------------------------------







//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}