package com.bexp.ejb.CI;
import com.bexp.ejb.*;
import java.util.*;

public interface ISDObjLocalHome
    extends com.bexp.ejb.IObjLocalHome
{

	public boolean check_ShortName_2_unique_local(Object PK , java.lang.String ShortName)  throws Exception;

//---------------------------------------------------------------------------------
}
