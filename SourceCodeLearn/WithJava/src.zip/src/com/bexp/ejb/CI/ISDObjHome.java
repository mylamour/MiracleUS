package com.bexp.ejb.CI;

import javax.persistence.*;
import java.util.*;
import javax.ejb.*;
import com.bexp.ejb.*;

@Remote
public interface ISDObjHome extends com.bexp.ejb.IObjHome
{

	public boolean check_ShortName_2_unique(Object PK , java.lang.String ShortName)  throws Exception;


//---------------------------------------------------------------------------------
}
