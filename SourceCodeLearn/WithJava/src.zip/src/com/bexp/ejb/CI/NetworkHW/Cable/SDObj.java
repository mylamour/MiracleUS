package com.bexp.ejb.CI.NetworkHW.Cable;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.CI.SDObj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.CI.NetworkHW.Cable.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.CI.NetworkHW.Cable";
    

//---------------------------------------------------------------------------------------

LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj,SDObjCMPBase> relatedSerialPort;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj,SDObjCMPBase> getRelatedSerialPort()
        {
        if(relatedSerialPort==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedSerialPortCMPs(),
                    com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj.class, false);
            }
        }
		relatedSerialPort = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedSerialPort;     
        }
    public void setRelatedSerialPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedSerialPort.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Switch.SDObj,SDObjCMPBase> relatedSwitch;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Switch.SDObj,SDObjCMPBase> getRelatedSwitch()
        {
        if(relatedSwitch==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.Switch.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.Switch.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedSwitchCMPs(),
                    com.bexp.ejb.CI.NetworkHW.Switch.SDObj.class, false);
            }
        }
		relatedSwitch = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Switch.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.NetworkHW.Switch.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedSwitch;     
        }
    public void setRelatedSwitch(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Switch.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedSwitch.copy(lca); }        
//---------------------------------------------------------------------------------------

LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> relatedLAN;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> getRelatedLAN()
        {
        if(relatedLAN==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.LAN.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.LAN.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedLANCMPs(),
                    com.bexp.ejb.CI.LAN.SDObj.class, false);
            }
        }
	relatedLAN = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.LAN.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedLAN;
        }
    public void setRelatedLAN(LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedLAN.copy(lca); }        
        
//---------------------------------------------------------------------------------------







//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}