package com.bexp.ejb.CI;

import java.util.*;
import javax.annotation.*;
import javax.ejb.*;
import javax.persistence.*;
import javax.naming.*;

import org.jboss.annotation.security.SecurityDomain;
import com.bexp.ejb.*;

@Stateless(name="com.bexp.ejb.CI.SDObjRemoteHomeBean")
@Remote(ISDObjHome.class)
@Local(ISDObjLocalHome.class)
@SecurityDomain("bexp")
public class SDObjRemoteHomeBean
	extends com.bexp.ejb.ObjHomeBean
    implements ISDObjHome,ISDObjLocalHome
{

//---------------------------------------------------------------------------------
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public boolean check_ShortName_2_unique(Object PK , java.lang.String ShortName)  throws Exception{
		lock.lock();
		try{
			return ((ISDObjLocalHome)getLocalHome()).check_ShortName_2_unique_local(PK , ShortName) ;			
		}
		finally{lock.unlock();}
	}
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public boolean check_ShortName_2_unique_local(Object PK , java.lang.String ShortName)  throws Exception
        {
		if (ShortName==null) return true;
        List result = 
            ObjHomeBean.getEM()
            .createQuery("FROM "+EntityCMPBeanClass.getName()+" ci WHERE 1=1 and ci.shortName='"+ShortName+"'  and ci.id<>"+PK)
            .getResultList();
        if (result.size()>0) return false;
        else return true;        
        }	
        
        
  
//--------------------------------------------------------------------------------------        

        
}
