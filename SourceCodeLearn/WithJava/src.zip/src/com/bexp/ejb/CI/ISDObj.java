package com.bexp.ejb.CI;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.IObj
{
    public java.lang.String getShortName();
    public void setShortName(java.lang.String locShortName) throws Exception;

    public java.util.Date getInstallTime();
    public void setInstallTime(java.util.Date locInstallTime) throws Exception;

    public java.util.Date getOrderTime();
    public void setOrderTime(java.util.Date locOrderTime) throws Exception;

    public com.bexp.ejb.CI.Status getStatus();
    public void setStatus(com.bexp.ejb.CI.Status locStatus) throws Exception;


 
	public Set<ObjHandle<com.bexp.ejb.SLA.SDObj> > getSLAs();
	public void setSLAs(Set<ObjHandle<com.bexp.ejb.SLA.SDObj> > _arg) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.Service.SDObj,SDObjCMPBase> getServices();
	public void setServices(LazyCollectionAccessAdapter<com.bexp.ejb.Service.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.OrgUnit.SDObj,SDObjCMPBase> getSuppliers();
	public void setSuppliers(LazyCollectionAccessAdapter<com.bexp.ejb.OrgUnit.SDObj,SDObjCMPBase> lca) throws Exception;


	public LazyCollectionAccessAdapter<com.bexp.ejb.OrgUnit.SDObj,SDObjCMPBase> getOrgUnits();
	public void setOrgUnits(LazyCollectionAccessAdapter<com.bexp.ejb.OrgUnit.SDObj,SDObjCMPBase> lca) throws Exception;



    public ObjHandle<com.bexp.ejb.Location.Address.SDObj> getAddress() throws Exception;
    public void setAddress(ObjHandle<com.bexp.ejb.Location.Address.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> getResponsible() throws Exception;
    public void setResponsible(ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.OrgUnit.SDObj> getManufacturer() throws Exception;
    public void setManufacturer(ObjHandle<com.bexp.ejb.OrgUnit.SDObj> handle) throws Exception;



    public Set<ObjHandle<com.bexp.ejb.BE.SDObj> > getBusinessEvents();
	public void setBusinessEvents(Set<ObjHandle<com.bexp.ejb.BE.SDObj> > _arg) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.Task.SDObj,SDObjCMPBase> getTasks();
	public void setTasks(LazyCollectionAccessAdapter<com.bexp.ejb.Task.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.Workorder.SDObj,SDObjCMPBase> getWOs();
	public void setWOs(LazyCollectionAccessAdapter<com.bexp.ejb.Workorder.SDObj,SDObjCMPBase> lca) throws Exception;




//---------------------------------------------------------------------------------
}