package com.bexp.ejb.CI.HW.LCDpanel;
import com.bexp.ejb.*;
import java.util.*;

public interface ISDObjLocalHome
    extends com.bexp.ejb.CI.ISDObjLocalHome
{

//---------------------------------------------------------------------------------
}
