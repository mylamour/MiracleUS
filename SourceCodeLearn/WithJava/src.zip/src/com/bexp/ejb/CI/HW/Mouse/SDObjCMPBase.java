package com.bexp.ejb.CI.HW.Mouse;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.HW.Mouse.SDObjCMPBase")
@Table(name = "Mouse")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   
	protected java.lang.String SerialNumber;
	public java.lang.String getSerialNumber() {
	 return SerialNumber;  	 
	 }
	public void setSerialNumber(java.lang.String locSerialNumber) throws Exception { 
	SerialNumber=locSerialNumber;
	}	

	protected java.lang.String Cost;
	public java.lang.String getCost() {
	 return Cost;  	 
	 }
	public void setCost(java.lang.String locCost) throws Exception { 
	Cost=locCost;
	}	


 


 @Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> getRelatedPC()
 {
        return null;
        }
public void setRelatedPC(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedPCCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.HW.PC.SDObjCMPBase.class,
                false);
        }        

      java.util.Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> relatedPCCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_Mouse",
    joinColumns = {@JoinColumn(name = "ID2")},
        inverseJoinColumns = {@JoinColumn(name = "ID1")})
    public Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> getRelatedPCCMPs()
        { return relatedPCCMPs; }
    public void setRelatedPCCMPs(Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> cmps)
        { relatedPCCMPs = cmps; }

//------------------------------------------------------------------------------







//---------------------------------------------------------------------------------
}

