package com.bexp.ejb.CI.NetworkHW.LPTPort;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.CI.ISDObj
{

 
	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.OfficeHW.Printer.SDObj,SDObjCMPBase> getPrinter();
	public void setPrinter(LazyCollectionAccessAdapter<com.bexp.ejb.CI.OfficeHW.Printer.SDObj,SDObjCMPBase> lca) throws Exception;


	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> getPC();
	public void setPC(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> lca) throws Exception;








//---------------------------------------------------------------------------------
}