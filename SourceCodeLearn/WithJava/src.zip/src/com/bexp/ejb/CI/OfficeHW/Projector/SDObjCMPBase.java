package com.bexp.ejb.CI.OfficeHW.Projector;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.OfficeHW.Projector.SDObjCMPBase")
@Table(name = "Projector")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   

 








//---------------------------------------------------------------------------------
}

