package com.bexp.ejb.CI.Templates.PCtype;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.Templates.PCtype.SDObjCMPBase")
@Table(name = "PCtype")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   

 
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OfficeSW.SDObj,SDObjCMPBase> getRelatedOfficeSW()
 {
        return null;
        }
public void setRelatedOfficeSW(LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OfficeSW.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedOfficeSWCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.SW.OfficeSW.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.SW.OfficeSW.SDObjCMPBase> relatedOfficeSWCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PCtype_RelatedOfficeSW",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.SW.OfficeSW.SDObjCMPBase> getRelatedOfficeSWCMPs()
        { return relatedOfficeSWCMPs; }
    public void setRelatedOfficeSWCMPs(Set<com.bexp.ejb.CI.SW.OfficeSW.SDObjCMPBase> cmps)
        { relatedOfficeSWCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> getRelatedPC()
 {
        return null;
        }
public void setRelatedPC(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedPCCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.HW.PC.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> relatedPCCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PCtype_RelatedPC",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> getRelatedPCCMPs()
        { return relatedPCCMPs; }
    public void setRelatedPCCMPs(Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> cmps)
        { relatedPCCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> getLPTPort()
 {
        return null;
        }
public void setLPTPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getLPTPortCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.LPTPort.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObjCMPBase> lPTPortCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PCtype_LPTPort",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObjCMPBase> getLPTPortCMPs()
        { return lPTPortCMPs; }
    public void setLPTPortCMPs(Set<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObjCMPBase> cmps)
        { lPTPortCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj,SDObjCMPBase> getComPort()
 {
        return null;
        }
public void setComPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getComPortCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.ComPort.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.NetworkHW.ComPort.SDObjCMPBase> comPortCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PCtype_ComPort",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.NetworkHW.ComPort.SDObjCMPBase> getComPortCMPs()
        { return comPortCMPs; }
    public void setComPortCMPs(Set<com.bexp.ejb.CI.NetworkHW.ComPort.SDObjCMPBase> cmps)
        { comPortCMPs = cmps; }
//------------------------------------------------------------------------------


 @Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OS.SDObj,SDObjCMPBase> getRelatedOS()
 {
        return null;
        }
public void setRelatedOS(LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OS.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedOSCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.SW.OS.SDObjCMPBase.class,
                false);
        }        

      java.util.Set<com.bexp.ejb.CI.SW.OS.SDObjCMPBase> relatedOSCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "OS_PCtype",
    joinColumns = {@JoinColumn(name = "ID2")},
        inverseJoinColumns = {@JoinColumn(name = "ID1")})
    public Set<com.bexp.ejb.CI.SW.OS.SDObjCMPBase> getRelatedOSCMPs()
        { return relatedOSCMPs; }
    public void setRelatedOSCMPs(Set<com.bexp.ejb.CI.SW.OS.SDObjCMPBase> cmps)
        { relatedOSCMPs = cmps; }

//------------------------------------------------------------------------------







//---------------------------------------------------------------------------------
}

