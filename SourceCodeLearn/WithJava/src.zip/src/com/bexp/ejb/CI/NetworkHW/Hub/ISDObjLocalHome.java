package com.bexp.ejb.CI.NetworkHW.Hub;
import com.bexp.ejb.*;
import java.util.*;

public interface ISDObjLocalHome
    extends com.bexp.ejb.CI.ISDObjLocalHome
{

//---------------------------------------------------------------------------------
}
