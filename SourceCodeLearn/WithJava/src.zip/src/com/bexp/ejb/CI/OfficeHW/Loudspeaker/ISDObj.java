package com.bexp.ejb.CI.OfficeHW.Loudspeaker;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.CI.ISDObj
{

 








//---------------------------------------------------------------------------------
}