package com.bexp.ejb.CI.Templates.PCtype;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.CI.ISDObj
{

 
	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OfficeSW.SDObj,SDObjCMPBase> getRelatedOfficeSW();
	public void setRelatedOfficeSW(LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OfficeSW.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> getRelatedPC();
	public void setRelatedPC(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> getLPTPort();
	public void setLPTPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj,SDObjCMPBase> getComPort();
	public void setComPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj,SDObjCMPBase> lca) throws Exception;


	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OS.SDObj,SDObjCMPBase> getRelatedOS();
	public void setRelatedOS(LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OS.SDObj,SDObjCMPBase> lca) throws Exception;








//---------------------------------------------------------------------------------
}