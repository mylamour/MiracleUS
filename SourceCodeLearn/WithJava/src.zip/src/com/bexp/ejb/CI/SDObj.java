package com.bexp.ejb.CI;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.Obj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.CI.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.CI";
    
	protected java.lang.String ShortName;
	public java.lang.String getShortName() {
	 return ShortName;  	 
	 }
	public void setShortName(java.lang.String locShortName) throws Exception { 
	ShortName=locShortName;
	}	

	protected java.util.Date InstallTime;
	public java.util.Date getInstallTime() {
	 return InstallTime;  	 
	 }
	public void setInstallTime(java.util.Date locInstallTime) throws Exception { 
	InstallTime=locInstallTime;
	}	

	protected java.util.Date OrderTime;
	public java.util.Date getOrderTime() {
	 return OrderTime;  	 
	 }
	public void setOrderTime(java.util.Date locOrderTime) throws Exception { 
	OrderTime=locOrderTime;
	}	

	protected com.bexp.ejb.CI.Status Status;
	public com.bexp.ejb.CI.Status getStatus() {
	 return Status;  	 
	 }
	public void setStatus(com.bexp.ejb.CI.Status locStatus) throws Exception { 
	Status=locStatus;
	}	


//---------------------------------------------------------------------------------------

    Set<ObjHandle<com.bexp.ejb.SLA.SDObj> > sLAs = new CopyOnWriteArraySet();    
    public Set<ObjHandle<com.bexp.ejb.SLA.SDObj> > getSLAs()
        { return sLAs; }
    public void setSLAs(Set<ObjHandle<com.bexp.ejb.SLA.SDObj> > _arg) throws Exception
        { sLAs.clear(); if(_arg!=null) {sLAs.addAll(_arg);} }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.Service.SDObj,SDObjCMPBase> services;
public LazyCollectionAccessAdapter<com.bexp.ejb.Service.SDObj,SDObjCMPBase> getServices()
        {
        if(services==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.Service.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.Service.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getServicesCMPs(),
                    com.bexp.ejb.Service.SDObj.class, false);
            }
        }
		services = new LazyCollectionAccessAdapter<com.bexp.ejb.Service.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.Service.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  services;     
        }
    public void setServices(LazyCollectionAccessAdapter<com.bexp.ejb.Service.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) services.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.OrgUnit.SDObj,SDObjCMPBase> suppliers;
public LazyCollectionAccessAdapter<com.bexp.ejb.OrgUnit.SDObj,SDObjCMPBase> getSuppliers()
        {
        if(suppliers==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.OrgUnit.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.OrgUnit.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getSuppliersCMPs(),
                    com.bexp.ejb.OrgUnit.SDObj.class, false);
            }
        }
		suppliers = new LazyCollectionAccessAdapter<com.bexp.ejb.OrgUnit.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.OrgUnit.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  suppliers;     
        }
    public void setSuppliers(LazyCollectionAccessAdapter<com.bexp.ejb.OrgUnit.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) suppliers.copy(lca); }        
//---------------------------------------------------------------------------------------

LazyCollectionAccessAdapter<com.bexp.ejb.OrgUnit.SDObj,SDObjCMPBase> orgUnits;
public LazyCollectionAccessAdapter<com.bexp.ejb.OrgUnit.SDObj,SDObjCMPBase> getOrgUnits()
        {
        if(orgUnits==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.OrgUnit.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.OrgUnit.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getOrgUnitsCMPs(),
                    com.bexp.ejb.OrgUnit.SDObj.class, false);
            }
        }
	orgUnits = new LazyCollectionAccessAdapter<com.bexp.ejb.OrgUnit.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.OrgUnit.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  orgUnits;
        }
    public void setOrgUnits(LazyCollectionAccessAdapter<com.bexp.ejb.OrgUnit.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) orgUnits.copy(lca); }        
        
//---------------------------------------------------------------------------------------



    ObjHandle<com.bexp.ejb.Location.Address.SDObj> address
            = new ObjHandle<com.bexp.ejb.Location.Address.SDObj>(null,false,com.bexp.ejb.Location.Address.SDObj.class);
    public ObjHandle<com.bexp.ejb.Location.Address.SDObj> getAddress() throws Exception
        {
        return address;
        }
    public void setAddress(ObjHandle<com.bexp.ejb.Location.Address.SDObj> handle) throws Exception
        {
        address.copy(handle);
        address.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> responsible
            = new ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj>(null,false,com.bexp.ejb.OrgUnit.Employee.SDObj.class);
    public ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> getResponsible() throws Exception
        {
        return responsible;
        }
    public void setResponsible(ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> handle) throws Exception
        {
        responsible.copy(handle);
        responsible.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.OrgUnit.SDObj> manufacturer
            = new ObjHandle<com.bexp.ejb.OrgUnit.SDObj>(null,false,com.bexp.ejb.OrgUnit.SDObj.class);
    public ObjHandle<com.bexp.ejb.OrgUnit.SDObj> getManufacturer() throws Exception
        {
        return manufacturer;
        }
    public void setManufacturer(ObjHandle<com.bexp.ejb.OrgUnit.SDObj> handle) throws Exception
        {
        manufacturer.copy(handle);
        manufacturer.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    Set<ObjHandle<com.bexp.ejb.BE.SDObj> > businessEvents = new CopyOnWriteArraySet();    
    public Set<ObjHandle<com.bexp.ejb.BE.SDObj> > getBusinessEvents()
        { return businessEvents; }
    public void setBusinessEvents(Set<ObjHandle<com.bexp.ejb.BE.SDObj> > _arg) throws Exception
        { businessEvents.clear(); if(_arg!=null) {businessEvents.addAll(_arg);} }                        
        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.Task.SDObj,SDObjCMPBase> tasks;
public LazyCollectionAccessAdapter<com.bexp.ejb.Task.SDObj,SDObjCMPBase> getTasks()
        {
        if(tasks==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.Task.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.Task.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getTasksCMPs(),
                    com.bexp.ejb.Task.SDObj.class, false);
            }
        }
		tasks = new LazyCollectionAccessAdapter<com.bexp.ejb.Task.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.Task.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  tasks;
        }
    public void setTasks(LazyCollectionAccessAdapter<com.bexp.ejb.Task.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) tasks.copy(lca); }        
        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.Workorder.SDObj,SDObjCMPBase> wOs;
public LazyCollectionAccessAdapter<com.bexp.ejb.Workorder.SDObj,SDObjCMPBase> getWOs()
        {
        if(wOs==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.Workorder.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.Workorder.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getWOsCMPs(),
                    com.bexp.ejb.Workorder.SDObj.class, false);
            }
        }
		wOs = new LazyCollectionAccessAdapter<com.bexp.ejb.Workorder.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.Workorder.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  wOs;
        }
    public void setWOs(LazyCollectionAccessAdapter<com.bexp.ejb.Workorder.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) wOs.copy(lca); }        
        
//---------------------------------------------------------------------------------------




//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
    	if (!((ISDObjHome)ObjSession.getSession().getHome(SDObjCMPBase.class)).check_ShortName_2_unique(this.getPK() , this.getShortName()) ){
    		throw new com.bexp.BEXPException(com.bexp.SDApp.translate("Short Name not unique"));}




     super.save();
    }
}