package com.bexp.ejb.CI.HW.PDA;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.CI.SDObj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.CI.HW.PDA.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.CI.HW.PDA";
    
	protected java.lang.String SerialNumber;
	public java.lang.String getSerialNumber() {
	 return SerialNumber;  	 
	 }
	public void setSerialNumber(java.lang.String locSerialNumber) throws Exception { 
	SerialNumber=locSerialNumber;
	}	

	protected java.lang.String Cost;
	public java.lang.String getCost() {
	 return Cost;  	 
	 }
	public void setCost(java.lang.String locCost) throws Exception { 
	Cost=locCost;
	}	


//---------------------------------------------------------------------------------------

LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> relatedPC;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> getRelatedPC()
        {
        if(relatedPC==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.HW.PC.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.HW.PC.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedPCCMPs(),
                    com.bexp.ejb.CI.HW.PC.SDObj.class, false);
            }
        }
		relatedPC = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.HW.PC.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedPC;     
        }
    public void setRelatedPC(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedPC.copy(lca); }        
//---------------------------------------------------------------------------------------








//---------------------------------------------------------------------------------


    public void save() throws Exception
    {


     super.save();
    }
}