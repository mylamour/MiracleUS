package com.bexp.ejb.CI.OfficeHW.Scaner;

import java.util.*;
import javax.annotation.*;
import javax.ejb.*;
import javax.persistence.*;
import javax.naming.*;

import org.jboss.annotation.security.SecurityDomain;
import com.bexp.ejb.*;

@Stateless(name="com.bexp.ejb.CI.OfficeHW.Scaner.SDObjRemoteHomeBean")
@Remote(ISDObjHome.class)
@Local(ISDObjLocalHome.class)
@SecurityDomain("bexp")
public class SDObjRemoteHomeBean
	extends com.bexp.ejb.CI.SDObjRemoteHomeBean
    implements ISDObjHome,ISDObjLocalHome
{

//---------------------------------------------------------------------------------
  
//--------------------------------------------------------------------------------------        

        
}
