package com.bexp.ejb.CI.SW.Application;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.CI.ISDObj
{

 

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Server.SDObj,SDObjCMPBase> getRelatedServer();
	public void setRelatedServer(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Server.SDObj,SDObjCMPBase> lca) throws Exception;








//---------------------------------------------------------------------------------
}