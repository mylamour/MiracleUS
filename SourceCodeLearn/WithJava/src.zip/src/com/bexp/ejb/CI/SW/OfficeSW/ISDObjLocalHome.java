package com.bexp.ejb.CI.SW.OfficeSW;
import com.bexp.ejb.*;
import java.util.*;

public interface ISDObjLocalHome
    extends com.bexp.ejb.CI.ISDObjLocalHome
{

//---------------------------------------------------------------------------------
}
