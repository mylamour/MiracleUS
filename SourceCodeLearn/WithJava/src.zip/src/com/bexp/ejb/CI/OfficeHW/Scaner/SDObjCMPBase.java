package com.bexp.ejb.CI.OfficeHW.Scaner;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.OfficeHW.Scaner.SDObjCMPBase")
@Table(name = "Scaner")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   

 
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> getRelatedLPTPort()
 {
        return null;
        }
public void setRelatedLPTPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedLPTPortCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.LPTPort.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObjCMPBase> relatedLPTPortCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "Scaner_RelatedLPTPort",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObjCMPBase> getRelatedLPTPortCMPs()
        { return relatedLPTPortCMPs; }
    public void setRelatedLPTPortCMPs(Set<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObjCMPBase> cmps)
        { relatedLPTPortCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> getRelatedPC()
 {
        return null;
        }
public void setRelatedPC(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedPCCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.HW.PC.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> relatedPCCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "Scaner_RelatedPC",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> getRelatedPCCMPs()
        { return relatedPCCMPs; }
    public void setRelatedPCCMPs(Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> cmps)
        { relatedPCCMPs = cmps; }
//------------------------------------------------------------------------------








//---------------------------------------------------------------------------------
}

