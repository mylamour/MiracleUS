package com.bexp.ejb.CI.Networks.IPNetwork;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.CI.ISDObj
{

 

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.Networks.IPAddress.SDObj,SDObjCMPBase> getRelatedIPAddress();
	public void setRelatedIPAddress(LazyCollectionAccessAdapter<com.bexp.ejb.CI.Networks.IPAddress.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> getRelatedLAN();
	public void setRelatedLAN(LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> lca) throws Exception;








//---------------------------------------------------------------------------------
}