package com.bexp.ejb.CI.OfficePhone;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.CI.ISDObj
{

 
	public Set<ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> > getEmployees();
	public void setEmployees(Set<ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> > _arg) throws Exception;









//---------------------------------------------------------------------------------
}