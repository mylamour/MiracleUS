package com.bexp.ejb.CI.Templates.HDDtype;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.CI.SDObj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.CI.Templates.HDDtype.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.CI.Templates.HDDtype";
    

//---------------------------------------------------------------------------------------

LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> relatedPC;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> getRelatedPC()
        {
        if(relatedPC==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.HW.PC.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.HW.PC.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedPCCMPs(),
                    com.bexp.ejb.CI.HW.PC.SDObj.class, false);
            }
        }
		relatedPC = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.HW.PC.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedPC;     
        }
    public void setRelatedPC(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedPC.copy(lca); }        
//---------------------------------------------------------------------------------------

LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.HDD.SDObj,SDObjCMPBase> relatedHDD;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.HDD.SDObj,SDObjCMPBase> getRelatedHDD()
        {
        if(relatedHDD==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.HW.HDD.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.HW.HDD.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedHDDCMPs(),
                    com.bexp.ejb.CI.HW.HDD.SDObj.class, false);
            }
        }
	relatedHDD = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.HDD.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.HW.HDD.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedHDD;
        }
    public void setRelatedHDD(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.HDD.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedHDD.copy(lca); }        
        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.Templates.PCtype.SDObj,SDObjCMPBase> relatedPCtype;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.Templates.PCtype.SDObj,SDObjCMPBase> getRelatedPCtype()
        {
        if(relatedPCtype==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.Templates.PCtype.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.Templates.PCtype.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedPCtypeCMPs(),
                    com.bexp.ejb.CI.Templates.PCtype.SDObj.class, false);
            }
        }
	relatedPCtype = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.Templates.PCtype.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.Templates.PCtype.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedPCtype;
        }
    public void setRelatedPCtype(LazyCollectionAccessAdapter<com.bexp.ejb.CI.Templates.PCtype.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedPCtype.copy(lca); }        
        
//---------------------------------------------------------------------------------------







//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}