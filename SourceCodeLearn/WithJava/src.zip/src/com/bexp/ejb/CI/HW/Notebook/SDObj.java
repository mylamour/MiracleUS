package com.bexp.ejb.CI.HW.Notebook;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.CI.SDObj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.CI.HW.Notebook.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.CI.HW.Notebook";
    
	protected java.lang.String SerialNumber;
	public java.lang.String getSerialNumber() {
	 return SerialNumber;  	 
	 }
	public void setSerialNumber(java.lang.String locSerialNumber) throws Exception { 
	SerialNumber=locSerialNumber;
	}	

	protected java.lang.String Cost;
	public java.lang.String getCost() {
	 return Cost;  	 
	 }
	public void setCost(java.lang.String locCost) throws Exception { 
	Cost=locCost;
	}	


//---------------------------------------------------------------------------------------









//---------------------------------------------------------------------------------


    public void save() throws Exception
    {


     super.save();
    }
}