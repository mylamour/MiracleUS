package com.bexp.ejb.CI.Templates.MonitorType;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.Templates.MonitorType.SDObjCMPBase")
@Table(name = "MonitorType")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   

 
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> getRelatedPC()
 {
        return null;
        }
public void setRelatedPC(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedPCCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.HW.PC.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> relatedPCCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "MonitorType_RelatedPC",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> getRelatedPCCMPs()
        { return relatedPCCMPs; }
    public void setRelatedPCCMPs(Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> cmps)
        { relatedPCCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Monitor.SDObj,SDObjCMPBase> getRelatedMonitor()
 {
        return null;
        }
public void setRelatedMonitor(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Monitor.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedMonitorCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.HW.Monitor.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.HW.Monitor.SDObjCMPBase> relatedMonitorCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "MonitorType_RelatedMonitor",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.HW.Monitor.SDObjCMPBase> getRelatedMonitorCMPs()
        { return relatedMonitorCMPs; }
    public void setRelatedMonitorCMPs(Set<com.bexp.ejb.CI.HW.Monitor.SDObjCMPBase> cmps)
        { relatedMonitorCMPs = cmps; }
//------------------------------------------------------------------------------








//---------------------------------------------------------------------------------
}

