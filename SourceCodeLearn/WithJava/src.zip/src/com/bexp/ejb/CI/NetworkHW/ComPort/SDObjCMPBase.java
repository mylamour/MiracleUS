package com.bexp.ejb.CI.NetworkHW.ComPort;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.NetworkHW.ComPort.SDObjCMPBase")
@Table(name = "ComPort")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   

 


 @Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> getPC()
 {
        return null;
        }
public void setPC(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getPCCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.HW.PC.SDObjCMPBase.class,
                false);
        }        

      java.util.Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> pCCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_ComPort",
    joinColumns = {@JoinColumn(name = "ID2")},
        inverseJoinColumns = {@JoinColumn(name = "ID1")})
    public Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> getPCCMPs()
        { return pCCMPs; }
    public void setPCCMPs(Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> cmps)
        { pCCMPs = cmps; }

//------------------------------------------------------------------------------







//---------------------------------------------------------------------------------
}

