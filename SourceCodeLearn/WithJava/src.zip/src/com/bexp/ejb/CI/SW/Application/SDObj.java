package com.bexp.ejb.CI.SW.Application;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.CI.SDObj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.CI.SW.Application.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.CI.SW.Application";
    

//---------------------------------------------------------------------------------------


LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Server.SDObj,SDObjCMPBase> relatedServer;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Server.SDObj,SDObjCMPBase> getRelatedServer()
        {
        if(relatedServer==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.HW.Server.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.HW.Server.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedServerCMPs(),
                    com.bexp.ejb.CI.HW.Server.SDObj.class, false);
            }
        }
	relatedServer = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Server.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.HW.Server.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedServer;
        }
    public void setRelatedServer(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Server.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedServer.copy(lca); }        
        
//---------------------------------------------------------------------------------------







//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}