package com.bexp.ejb.CI.HW.PC;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.CI.SDObj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.CI.HW.PC.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.CI.HW.PC";
    
	protected java.lang.String SerialNumber;
	public java.lang.String getSerialNumber() {
	 return SerialNumber;  	 
	 }
	public void setSerialNumber(java.lang.String locSerialNumber) throws Exception { 
	SerialNumber=locSerialNumber;
	}	

	protected java.lang.String Cost;
	public java.lang.String getCost() {
	 return Cost;  	 
	 }
	public void setCost(java.lang.String locCost) throws Exception { 
	Cost=locCost;
	}	


//---------------------------------------------------------------------------------------

LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj,SDObjCMPBase> ethernetPort;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj,SDObjCMPBase> getEthernetPort()
        {
        if(ethernetPort==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getEthernetPortCMPs(),
                    com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj.class, false);
            }
        }
		ethernetPort = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  ethernetPort;     
        }
    public void setEthernetPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) ethernetPort.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj,SDObjCMPBase> comPort;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj,SDObjCMPBase> getComPort()
        {
        if(comPort==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getComPortCMPs(),
                    com.bexp.ejb.CI.NetworkHW.ComPort.SDObj.class, false);
            }
        }
		comPort = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.NetworkHW.ComPort.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  comPort;     
        }
    public void setComPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.ComPort.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) comPort.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Mouse.SDObj,SDObjCMPBase> mouse;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Mouse.SDObj,SDObjCMPBase> getMouse()
        {
        if(mouse==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.HW.Mouse.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.HW.Mouse.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getMouseCMPs(),
                    com.bexp.ejb.CI.HW.Mouse.SDObj.class, false);
            }
        }
		mouse = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Mouse.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.HW.Mouse.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  mouse;     
        }
    public void setMouse(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Mouse.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) mouse.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Monitor.SDObj,SDObjCMPBase> monitor;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Monitor.SDObj,SDObjCMPBase> getMonitor()
        {
        if(monitor==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.HW.Monitor.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.HW.Monitor.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getMonitorCMPs(),
                    com.bexp.ejb.CI.HW.Monitor.SDObj.class, false);
            }
        }
		monitor = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Monitor.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.HW.Monitor.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  monitor;     
        }
    public void setMonitor(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Monitor.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) monitor.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.OfficeHW.Printer.SDObj,SDObjCMPBase> printer;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.OfficeHW.Printer.SDObj,SDObjCMPBase> getPrinter()
        {
        if(printer==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.OfficeHW.Printer.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.OfficeHW.Printer.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getPrinterCMPs(),
                    com.bexp.ejb.CI.OfficeHW.Printer.SDObj.class, false);
            }
        }
		printer = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.OfficeHW.Printer.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.OfficeHW.Printer.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  printer;     
        }
    public void setPrinter(LazyCollectionAccessAdapter<com.bexp.ejb.CI.OfficeHW.Printer.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) printer.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.MotherBoard.SDObj,SDObjCMPBase> motherBoard;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.MotherBoard.SDObj,SDObjCMPBase> getMotherBoard()
        {
        if(motherBoard==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.HW.MotherBoard.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.HW.MotherBoard.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getMotherBoardCMPs(),
                    com.bexp.ejb.CI.HW.MotherBoard.SDObj.class, false);
            }
        }
		motherBoard = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.MotherBoard.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.HW.MotherBoard.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  motherBoard;     
        }
    public void setMotherBoard(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.MotherBoard.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) motherBoard.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> lANer;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> getLANer()
        {
        if(lANer==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.LAN.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.LAN.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getLANerCMPs(),
                    com.bexp.ejb.CI.LAN.SDObj.class, false);
            }
        }
		lANer = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.LAN.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  lANer;     
        }
    public void setLANer(LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) lANer.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.VideoCard.SDObj,SDObjCMPBase> videoCard;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.VideoCard.SDObj,SDObjCMPBase> getVideoCard()
        {
        if(videoCard==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.HW.VideoCard.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.HW.VideoCard.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getVideoCardCMPs(),
                    com.bexp.ejb.CI.HW.VideoCard.SDObj.class, false);
            }
        }
		videoCard = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.VideoCard.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.HW.VideoCard.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  videoCard;     
        }
    public void setVideoCard(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.VideoCard.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) videoCard.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.NetCard.SDObj,SDObjCMPBase> networkCard;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.NetCard.SDObj,SDObjCMPBase> getNetworkCard()
        {
        if(networkCard==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.NetCard.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.NetCard.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getNetworkCardCMPs(),
                    com.bexp.ejb.CI.NetworkHW.NetCard.SDObj.class, false);
            }
        }
		networkCard = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.NetCard.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.NetworkHW.NetCard.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  networkCard;     
        }
    public void setNetworkCard(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.NetCard.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) networkCard.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OfficeSW.SDObj,SDObjCMPBase> officeSW;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OfficeSW.SDObj,SDObjCMPBase> getOfficeSW()
        {
        if(officeSW==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.SW.OfficeSW.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.SW.OfficeSW.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getOfficeSWCMPs(),
                    com.bexp.ejb.CI.SW.OfficeSW.SDObj.class, false);
            }
        }
		officeSW = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OfficeSW.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.SW.OfficeSW.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  officeSW;     
        }
    public void setOfficeSW(LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OfficeSW.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) officeSW.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.ServicePack.SDObj,SDObjCMPBase> servicePack;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.ServicePack.SDObj,SDObjCMPBase> getServicePack()
        {
        if(servicePack==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.SW.ServicePack.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.SW.ServicePack.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getServicePackCMPs(),
                    com.bexp.ejb.CI.SW.ServicePack.SDObj.class, false);
            }
        }
		servicePack = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.ServicePack.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.SW.ServicePack.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  servicePack;     
        }
    public void setServicePack(LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.ServicePack.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) servicePack.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.CDWriter.SDObj,SDObjCMPBase> cDWriter;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.CDWriter.SDObj,SDObjCMPBase> getCDWriter()
        {
        if(cDWriter==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.HW.CDWriter.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.HW.CDWriter.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getCDWriterCMPs(),
                    com.bexp.ejb.CI.HW.CDWriter.SDObj.class, false);
            }
        }
		cDWriter = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.CDWriter.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.HW.CDWriter.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  cDWriter;     
        }
    public void setCDWriter(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.CDWriter.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) cDWriter.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OS.SDObj,SDObjCMPBase> oS;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OS.SDObj,SDObjCMPBase> getOS()
        {
        if(oS==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.SW.OS.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.SW.OS.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getOSCMPs(),
                    com.bexp.ejb.CI.SW.OS.SDObj.class, false);
            }
        }
		oS = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OS.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.SW.OS.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  oS;     
        }
    public void setOS(LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OS.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) oS.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.HDD.SDObj,SDObjCMPBase> hDDs;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.HDD.SDObj,SDObjCMPBase> getHDDs()
        {
        if(hDDs==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.HW.HDD.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.HW.HDD.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getHDDsCMPs(),
                    com.bexp.ejb.CI.HW.HDD.SDObj.class, false);
            }
        }
		hDDs = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.HDD.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.HW.HDD.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  hDDs;     
        }
    public void setHDDs(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.HDD.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) hDDs.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Keyboard.SDObj,SDObjCMPBase> keyboards;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Keyboard.SDObj,SDObjCMPBase> getKeyboards()
        {
        if(keyboards==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.HW.Keyboard.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.HW.Keyboard.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getKeyboardsCMPs(),
                    com.bexp.ejb.CI.HW.Keyboard.SDObj.class, false);
            }
        }
		keyboards = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Keyboard.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.HW.Keyboard.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  keyboards;     
        }
    public void setKeyboards(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Keyboard.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) keyboards.copy(lca); }        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> lPTPort;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> getLPTPort()
        {
        if(lPTPort==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getLPTPortCMPs(),
                    com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj.class, false);
            }
        }
		lPTPort = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  lPTPort;     
        }
    public void setLPTPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) lPTPort.copy(lca); }        
//---------------------------------------------------------------------------------------








//---------------------------------------------------------------------------------


    public void save() throws Exception
    {


     super.save();
    }
}