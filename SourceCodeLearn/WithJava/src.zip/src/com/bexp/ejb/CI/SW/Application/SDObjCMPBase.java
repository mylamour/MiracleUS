package com.bexp.ejb.CI.SW.Application;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.SW.Application.SDObjCMPBase")
@Table(name = "Application")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   

 


 @Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Server.SDObj,SDObjCMPBase> getRelatedServer()
 {
        return null;
        }
public void setRelatedServer(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Server.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedServerCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.HW.Server.SDObjCMPBase.class,
                false);
        }        

      java.util.Set<com.bexp.ejb.CI.HW.Server.SDObjCMPBase> relatedServerCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "application_server",
    joinColumns = {@JoinColumn(name = "ID2")},
        inverseJoinColumns = {@JoinColumn(name = "ID1")})
    public Set<com.bexp.ejb.CI.HW.Server.SDObjCMPBase> getRelatedServerCMPs()
        { return relatedServerCMPs; }
    public void setRelatedServerCMPs(Set<com.bexp.ejb.CI.HW.Server.SDObjCMPBase> cmps)
        { relatedServerCMPs = cmps; }

//------------------------------------------------------------------------------







//---------------------------------------------------------------------------------
}

