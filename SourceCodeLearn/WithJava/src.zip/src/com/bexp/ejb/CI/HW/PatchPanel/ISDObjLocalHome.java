package com.bexp.ejb.CI.HW.PatchPanel;
import com.bexp.ejb.*;
import java.util.*;

public interface ISDObjLocalHome
    extends com.bexp.ejb.CI.ISDObjLocalHome
{

//---------------------------------------------------------------------------------
}
