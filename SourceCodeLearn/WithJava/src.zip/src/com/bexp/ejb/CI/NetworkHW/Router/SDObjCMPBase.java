package com.bexp.ejb.CI.NetworkHW.Router;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.NetworkHW.Router.SDObjCMPBase")
@Table(name = "Router")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   

 


 @Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.USBPort.SDObj,SDObjCMPBase> getUSBPort()
 {
        return null;
        }
public void setUSBPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.USBPort.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getUSBPortCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.USBPort.SDObjCMPBase.class,
                false);
        }        

      java.util.Set<com.bexp.ejb.CI.NetworkHW.USBPort.SDObjCMPBase> uSBPortCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "USBPort_RelatedRouter",
    joinColumns = {@JoinColumn(name = "ID2")},
        inverseJoinColumns = {@JoinColumn(name = "ID1")})
    public Set<com.bexp.ejb.CI.NetworkHW.USBPort.SDObjCMPBase> getUSBPortCMPs()
        { return uSBPortCMPs; }
    public void setUSBPortCMPs(Set<com.bexp.ejb.CI.NetworkHW.USBPort.SDObjCMPBase> cmps)
        { uSBPortCMPs = cmps; }

//------------------------------------------------------------------------------

 @Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj,SDObjCMPBase> getSerialPort()
 {
        return null;
        }
public void setSerialPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getSerialPortCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.SerialPort.SDObjCMPBase.class,
                false);
        }        

      java.util.Set<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObjCMPBase> serialPortCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "SerialPort_RelatedRouter",
    joinColumns = {@JoinColumn(name = "ID2")},
        inverseJoinColumns = {@JoinColumn(name = "ID1")})
    public Set<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObjCMPBase> getSerialPortCMPs()
        { return serialPortCMPs; }
    public void setSerialPortCMPs(Set<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObjCMPBase> cmps)
        { serialPortCMPs = cmps; }

//------------------------------------------------------------------------------

 @Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj,SDObjCMPBase> getEthernetPort()
 {
        return null;
        }
public void setEthernetPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getEthernetPortCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObjCMPBase.class,
                false);
        }        

      java.util.Set<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObjCMPBase> ethernetPortCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "EthernetPort_Router",
    joinColumns = {@JoinColumn(name = "ID2")},
        inverseJoinColumns = {@JoinColumn(name = "ID1")})
    public Set<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObjCMPBase> getEthernetPortCMPs()
        { return ethernetPortCMPs; }
    public void setEthernetPortCMPs(Set<com.bexp.ejb.CI.NetworkHW.EthernetPort.SDObjCMPBase> cmps)
        { ethernetPortCMPs = cmps; }

//------------------------------------------------------------------------------







//---------------------------------------------------------------------------------
}

