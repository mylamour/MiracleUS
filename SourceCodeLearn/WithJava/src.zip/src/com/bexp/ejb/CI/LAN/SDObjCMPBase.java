package com.bexp.ejb.CI.LAN;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.LAN.SDObjCMPBase")
@Table(name = "LAN")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   

 
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.Networks.IPNetwork.SDObj,SDObjCMPBase> getRelatedIPNetwork()
 {
        return null;
        }
public void setRelatedIPNetwork(LazyCollectionAccessAdapter<com.bexp.ejb.CI.Networks.IPNetwork.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedIPNetworkCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.Networks.IPNetwork.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.Networks.IPNetwork.SDObjCMPBase> relatedIPNetworkCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "LAN_RelatedIPNetwork",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.Networks.IPNetwork.SDObjCMPBase> getRelatedIPNetworkCMPs()
        { return relatedIPNetworkCMPs; }
    public void setRelatedIPNetworkCMPs(Set<com.bexp.ejb.CI.Networks.IPNetwork.SDObjCMPBase> cmps)
        { relatedIPNetworkCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Router.SDObj,SDObjCMPBase> getRelatedRouter()
 {
        return null;
        }
public void setRelatedRouter(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Router.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedRouterCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.Router.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.NetworkHW.Router.SDObjCMPBase> relatedRouterCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "LAN_RelatedRouter",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.NetworkHW.Router.SDObjCMPBase> getRelatedRouterCMPs()
        { return relatedRouterCMPs; }
    public void setRelatedRouterCMPs(Set<com.bexp.ejb.CI.NetworkHW.Router.SDObjCMPBase> cmps)
        { relatedRouterCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Cable.SDObj,SDObjCMPBase> getRelatedCable()
 {
        return null;
        }
public void setRelatedCable(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Cable.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedCableCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.Cable.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.NetworkHW.Cable.SDObjCMPBase> relatedCableCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "cable_lan",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.NetworkHW.Cable.SDObjCMPBase> getRelatedCableCMPs()
        { return relatedCableCMPs; }
    public void setRelatedCableCMPs(Set<com.bexp.ejb.CI.NetworkHW.Cable.SDObjCMPBase> cmps)
        { relatedCableCMPs = cmps; }
//------------------------------------------------------------------------------


 @Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> getRelatedPC()
 {
        return null;
        }
public void setRelatedPC(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedPCCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.HW.PC.SDObjCMPBase.class,
                false);
        }        

      java.util.Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> relatedPCCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_LANer",
    joinColumns = {@JoinColumn(name = "ID2")},
        inverseJoinColumns = {@JoinColumn(name = "ID1")})
    public Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> getRelatedPCCMPs()
        { return relatedPCCMPs; }
    public void setRelatedPCCMPs(Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> cmps)
        { relatedPCCMPs = cmps; }

//------------------------------------------------------------------------------







//---------------------------------------------------------------------------------
}

