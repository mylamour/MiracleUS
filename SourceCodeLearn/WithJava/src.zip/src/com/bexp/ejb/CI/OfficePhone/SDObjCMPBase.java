package com.bexp.ejb.CI.OfficePhone;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.OfficePhone.SDObjCMPBase")
@Table(name = "OfficePhone")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   

 
@Transient
public Set<ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> > getEmployees()
 {
        return Obj.ObjsToHandles(this.getEmployeesCMPs(),
            com.bexp.ejb.OrgUnit.Employee.SDObj.class, false);
        }
public void setEmployees(Set<ObjHandle<com.bexp.ejb.OrgUnit.Employee.SDObj> > _arg) throws Exception
{
        setManyToMany(this.getEmployeesCMPs(),
                _arg, com.bexp.ejb.OrgUnit.Employee.SDObjCMPBase.class, false);        
        }        

    java.util.Set<com.bexp.ejb.OrgUnit.Employee.SDObjCMPBase> employeesCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "OfficePhone_Employees",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.OrgUnit.Employee.SDObjCMPBase> getEmployeesCMPs()
        { return employeesCMPs; }
    public void setEmployeesCMPs(Set<com.bexp.ejb.OrgUnit.Employee.SDObjCMPBase> cmps)
        { employeesCMPs = cmps; }
//------------------------------------------------------------------------------








//---------------------------------------------------------------------------------
}

