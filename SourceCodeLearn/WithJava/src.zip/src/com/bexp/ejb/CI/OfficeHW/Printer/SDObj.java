package com.bexp.ejb.CI.OfficeHW.Printer;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.CI.SDObj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.CI.OfficeHW.Printer.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.CI.OfficeHW.Printer";
    

//---------------------------------------------------------------------------------------


LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> relatedLPTPort;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> getRelatedLPTPort()
        {
        if(relatedLPTPort==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedLPTPortCMPs(),
                    com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj.class, false);
            }
        }
	relatedLPTPort = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedLPTPort;
        }
    public void setRelatedLPTPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.LPTPort.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedLPTPort.copy(lca); }        
        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> relatedPC;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> getRelatedPC()
        {
        if(relatedPC==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.HW.PC.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.HW.PC.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedPCCMPs(),
                    com.bexp.ejb.CI.HW.PC.SDObj.class, false);
            }
        }
	relatedPC = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.HW.PC.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedPC;
        }
    public void setRelatedPC(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedPC.copy(lca); }        
        
//---------------------------------------------------------------------------------------







//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}