package com.bexp.ejb.CI.SW.OS;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.SW.OS.SDObjCMPBase")
@Table(name = "OS")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   
	protected java.lang.String Cost;
	public java.lang.String getCost() {
	 return Cost;  	 
	 }
	public void setCost(java.lang.String locCost) throws Exception { 
	Cost=locCost;
	}	


 
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.Templates.PCtype.SDObj,SDObjCMPBase> getRelatedPCtype()
 {
        return null;
        }
public void setRelatedPCtype(LazyCollectionAccessAdapter<com.bexp.ejb.CI.Templates.PCtype.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedPCtypeCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.Templates.PCtype.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.Templates.PCtype.SDObjCMPBase> relatedPCtypeCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "OS_PCtype",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.Templates.PCtype.SDObjCMPBase> getRelatedPCtypeCMPs()
        { return relatedPCtypeCMPs; }
    public void setRelatedPCtypeCMPs(Set<com.bexp.ejb.CI.Templates.PCtype.SDObjCMPBase> cmps)
        { relatedPCtypeCMPs = cmps; }
//------------------------------------------------------------------------------


 @Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Server.SDObj,SDObjCMPBase> getRelatedServer()
 {
        return null;
        }
public void setRelatedServer(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.Server.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedServerCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.HW.Server.SDObjCMPBase.class,
                false);
        }        

      java.util.Set<com.bexp.ejb.CI.HW.Server.SDObjCMPBase> relatedServerCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "Server_RelatedOS",
    joinColumns = {@JoinColumn(name = "ID2")},
        inverseJoinColumns = {@JoinColumn(name = "ID1")})
    public Set<com.bexp.ejb.CI.HW.Server.SDObjCMPBase> getRelatedServerCMPs()
        { return relatedServerCMPs; }
    public void setRelatedServerCMPs(Set<com.bexp.ejb.CI.HW.Server.SDObjCMPBase> cmps)
        { relatedServerCMPs = cmps; }

//------------------------------------------------------------------------------

 @Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> getRelatedPC()
 {
        return null;
        }
public void setRelatedPC(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.PC.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedPCCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.HW.PC.SDObjCMPBase.class,
                false);
        }        

      java.util.Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> relatedPCCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "PC_OS",
    joinColumns = {@JoinColumn(name = "ID2")},
        inverseJoinColumns = {@JoinColumn(name = "ID1")})
    public Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> getRelatedPCCMPs()
        { return relatedPCCMPs; }
    public void setRelatedPCCMPs(Set<com.bexp.ejb.CI.HW.PC.SDObjCMPBase> cmps)
        { relatedPCCMPs = cmps; }

//------------------------------------------------------------------------------







//---------------------------------------------------------------------------------
}

