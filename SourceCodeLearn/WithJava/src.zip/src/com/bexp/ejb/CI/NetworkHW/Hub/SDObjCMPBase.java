package com.bexp.ejb.CI.NetworkHW.Hub;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.NetworkHW.Hub.SDObjCMPBase")
@Table(name = "Hub")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   

 
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.NetCard.SDObj,SDObjCMPBase> getRelatedNetworkCards()
 {
        return null;
        }
public void setRelatedNetworkCards(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.NetCard.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedNetworkCardsCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.NetCard.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.NetworkHW.NetCard.SDObjCMPBase> relatedNetworkCardsCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "Hub_RelatedNetworkCards",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.NetworkHW.NetCard.SDObjCMPBase> getRelatedNetworkCardsCMPs()
        { return relatedNetworkCardsCMPs; }
    public void setRelatedNetworkCardsCMPs(Set<com.bexp.ejb.CI.NetworkHW.NetCard.SDObjCMPBase> cmps)
        { relatedNetworkCardsCMPs = cmps; }
//------------------------------------------------------------------------------








//---------------------------------------------------------------------------------
}

