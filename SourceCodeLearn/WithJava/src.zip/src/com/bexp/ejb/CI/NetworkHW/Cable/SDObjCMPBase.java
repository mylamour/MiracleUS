package com.bexp.ejb.CI.NetworkHW.Cable;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.NetworkHW.Cable.SDObjCMPBase")
@Table(name = "Cable")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   

 
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj,SDObjCMPBase> getRelatedSerialPort()
 {
        return null;
        }
public void setRelatedSerialPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedSerialPortCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.SerialPort.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObjCMPBase> relatedSerialPortCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "Cable_RelatedSerialPort",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObjCMPBase> getRelatedSerialPortCMPs()
        { return relatedSerialPortCMPs; }
    public void setRelatedSerialPortCMPs(Set<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObjCMPBase> cmps)
        { relatedSerialPortCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Switch.SDObj,SDObjCMPBase> getRelatedSwitch()
 {
        return null;
        }
public void setRelatedSwitch(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Switch.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedSwitchCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.Switch.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.NetworkHW.Switch.SDObjCMPBase> relatedSwitchCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "Cable_RelatedSwitch",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.NetworkHW.Switch.SDObjCMPBase> getRelatedSwitchCMPs()
        { return relatedSwitchCMPs; }
    public void setRelatedSwitchCMPs(Set<com.bexp.ejb.CI.NetworkHW.Switch.SDObjCMPBase> cmps)
        { relatedSwitchCMPs = cmps; }
//------------------------------------------------------------------------------


 @Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> getRelatedLAN()
 {
        return null;
        }
public void setRelatedLAN(LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedLANCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.LAN.SDObjCMPBase.class,
                false);
        }        

      java.util.Set<com.bexp.ejb.CI.LAN.SDObjCMPBase> relatedLANCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "cable_lan",
    joinColumns = {@JoinColumn(name = "ID2")},
        inverseJoinColumns = {@JoinColumn(name = "ID1")})
    public Set<com.bexp.ejb.CI.LAN.SDObjCMPBase> getRelatedLANCMPs()
        { return relatedLANCMPs; }
    public void setRelatedLANCMPs(Set<com.bexp.ejb.CI.LAN.SDObjCMPBase> cmps)
        { relatedLANCMPs = cmps; }

//------------------------------------------------------------------------------







//---------------------------------------------------------------------------------
}

