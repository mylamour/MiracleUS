package com.bexp.ejb.CI.NetworkHW.SerialPort;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.NetworkHW.SerialPort.SDObjCMPBase")
@Table(name = "SerialPort")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   

 
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Router.SDObj,SDObjCMPBase> getRelatedRouter()
 {
        return null;
        }
public void setRelatedRouter(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Router.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedRouterCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.Router.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.NetworkHW.Router.SDObjCMPBase> relatedRouterCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "SerialPort_RelatedRouter",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.NetworkHW.Router.SDObjCMPBase> getRelatedRouterCMPs()
        { return relatedRouterCMPs; }
    public void setRelatedRouterCMPs(Set<com.bexp.ejb.CI.NetworkHW.Router.SDObjCMPBase> cmps)
        { relatedRouterCMPs = cmps; }
//------------------------------------------------------------------------------


 @Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Cable.SDObj,SDObjCMPBase> getRelatedCable()
 {
        return null;
        }
public void setRelatedCable(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Cable.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedCableCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.NetworkHW.Cable.SDObjCMPBase.class,
                false);
        }        

      java.util.Set<com.bexp.ejb.CI.NetworkHW.Cable.SDObjCMPBase> relatedCableCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "Cable_RelatedSerialPort",
    joinColumns = {@JoinColumn(name = "ID2")},
        inverseJoinColumns = {@JoinColumn(name = "ID1")})
    public Set<com.bexp.ejb.CI.NetworkHW.Cable.SDObjCMPBase> getRelatedCableCMPs()
        { return relatedCableCMPs; }
    public void setRelatedCableCMPs(Set<com.bexp.ejb.CI.NetworkHW.Cable.SDObjCMPBase> cmps)
        { relatedCableCMPs = cmps; }

//------------------------------------------------------------------------------







//---------------------------------------------------------------------------------
}

