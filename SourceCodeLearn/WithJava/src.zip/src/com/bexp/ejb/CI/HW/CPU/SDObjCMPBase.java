package com.bexp.ejb.CI.HW.CPU;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.HW.CPU.SDObjCMPBase")
@Table(name = "CPU")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   
	protected java.lang.String SerialNumber;
	public java.lang.String getSerialNumber() {
	 return SerialNumber;  	 
	 }
	public void setSerialNumber(java.lang.String locSerialNumber) throws Exception { 
	SerialNumber=locSerialNumber;
	}	

	protected java.lang.String Cost;
	public java.lang.String getCost() {
	 return Cost;  	 
	 }
	public void setCost(java.lang.String locCost) throws Exception { 
	Cost=locCost;
	}	


 
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.MotherBoard.SDObj,SDObjCMPBase> getRelatedMotherBoard()
 {
        return null;
        }
public void setRelatedMotherBoard(LazyCollectionAccessAdapter<com.bexp.ejb.CI.HW.MotherBoard.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedMotherBoardCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.HW.MotherBoard.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.HW.MotherBoard.SDObjCMPBase> relatedMotherBoardCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "CPU_RelatedMotherBoard",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.HW.MotherBoard.SDObjCMPBase> getRelatedMotherBoardCMPs()
        { return relatedMotherBoardCMPs; }
    public void setRelatedMotherBoardCMPs(Set<com.bexp.ejb.CI.HW.MotherBoard.SDObjCMPBase> cmps)
        { relatedMotherBoardCMPs = cmps; }
//------------------------------------------------------------------------------








//---------------------------------------------------------------------------------
}

