package com.bexp.ejb.CI.NetworkHW.Cable;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.CI.ISDObj
{

 
	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj,SDObjCMPBase> getRelatedSerialPort();
	public void setRelatedSerialPort(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.SerialPort.SDObj,SDObjCMPBase> lca) throws Exception;

	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Switch.SDObj,SDObjCMPBase> getRelatedSwitch();
	public void setRelatedSwitch(LazyCollectionAccessAdapter<com.bexp.ejb.CI.NetworkHW.Switch.SDObj,SDObjCMPBase> lca) throws Exception;


	public LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> getRelatedLAN();
	public void setRelatedLAN(LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> lca) throws Exception;








//---------------------------------------------------------------------------------
}