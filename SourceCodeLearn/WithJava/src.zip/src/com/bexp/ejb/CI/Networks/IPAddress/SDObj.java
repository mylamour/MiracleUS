package com.bexp.ejb.CI.Networks.IPAddress;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.CI.SDObj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.CI.Networks.IPAddress.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.CI.Networks.IPAddress";
    
	protected java.lang.String Mask;
	public java.lang.String getMask() {
	 return Mask;  	 
	 }
	public void setMask(java.lang.String locMask) throws Exception { 
	Mask=locMask;
	}	


//---------------------------------------------------------------------------------------

LazyCollectionAccessAdapter<com.bexp.ejb.CI.Networks.IPNetwork.SDObj,SDObjCMPBase> relatedIPNetwork;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.Networks.IPNetwork.SDObj,SDObjCMPBase> getRelatedIPNetwork()
        {
        if(relatedIPNetwork==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.Networks.IPNetwork.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.Networks.IPNetwork.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedIPNetworkCMPs(),
                    com.bexp.ejb.CI.Networks.IPNetwork.SDObj.class, false);
            }
        }
		relatedIPNetwork = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.Networks.IPNetwork.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.Networks.IPNetwork.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedIPNetwork;     
        }
    public void setRelatedIPNetwork(LazyCollectionAccessAdapter<com.bexp.ejb.CI.Networks.IPNetwork.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedIPNetwork.copy(lca); }        
//---------------------------------------------------------------------------------------








//---------------------------------------------------------------------------------


    public void save() throws Exception
    {

     super.save();
    }
}