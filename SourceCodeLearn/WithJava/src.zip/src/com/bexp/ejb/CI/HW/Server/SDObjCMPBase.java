package com.bexp.ejb.CI.HW.Server;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.CI.HW.Server.SDObjCMPBase")
@Table(name = "Server")
public class SDObjCMPBase
    extends com.bexp.ejb.CI.SDObjCMPBase
    implements ISDObj,java.io.Serializable
{
   
	protected java.lang.String SerialNumber;
	public java.lang.String getSerialNumber() {
	 return SerialNumber;  	 
	 }
	public void setSerialNumber(java.lang.String locSerialNumber) throws Exception { 
	SerialNumber=locSerialNumber;
	}	

	protected java.lang.String Cost;
	public java.lang.String getCost() {
	 return Cost;  	 
	 }
	public void setCost(java.lang.String locCost) throws Exception { 
	Cost=locCost;
	}	


 
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.Application.SDObj,SDObjCMPBase> getRelatedApplication()
 {
        return null;
        }
public void setRelatedApplication(LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.Application.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedApplicationCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.SW.Application.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.SW.Application.SDObjCMPBase> relatedApplicationCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "application_server",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.SW.Application.SDObjCMPBase> getRelatedApplicationCMPs()
        { return relatedApplicationCMPs; }
    public void setRelatedApplicationCMPs(Set<com.bexp.ejb.CI.SW.Application.SDObjCMPBase> cmps)
        { relatedApplicationCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OS.SDObj,SDObjCMPBase> getRelatedOS()
 {
        return null;
        }
public void setRelatedOS(LazyCollectionAccessAdapter<com.bexp.ejb.CI.SW.OS.SDObj,SDObjCMPBase> lca) throws Exception
        {
        if(lca.isInitialized()) setManyToMany(this.getRelatedOSCMPs(),
                (Set)lca.get(), com.bexp.ejb.CI.SW.OS.SDObjCMPBase.class,
                false);
        }        

    java.util.Set<com.bexp.ejb.CI.SW.OS.SDObjCMPBase> relatedOSCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "Server_RelatedOS",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.CI.SW.OS.SDObjCMPBase> getRelatedOSCMPs()
        { return relatedOSCMPs; }
    public void setRelatedOSCMPs(Set<com.bexp.ejb.CI.SW.OS.SDObjCMPBase> cmps)
        { relatedOSCMPs = cmps; }
//------------------------------------------------------------------------------








//---------------------------------------------------------------------------------
}

