package com.bexp.ejb.CI.Networks.IPNetwork;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.CI.SDObj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.CI.Networks.IPNetwork.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.CI.Networks.IPNetwork";
    

//---------------------------------------------------------------------------------------


LazyCollectionAccessAdapter<com.bexp.ejb.CI.Networks.IPAddress.SDObj,SDObjCMPBase> relatedIPAddress;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.Networks.IPAddress.SDObj,SDObjCMPBase> getRelatedIPAddress()
        {
        if(relatedIPAddress==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.Networks.IPAddress.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.Networks.IPAddress.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedIPAddressCMPs(),
                    com.bexp.ejb.CI.Networks.IPAddress.SDObj.class, false);
            }
        }
	relatedIPAddress = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.Networks.IPAddress.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.Networks.IPAddress.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedIPAddress;
        }
    public void setRelatedIPAddress(LazyCollectionAccessAdapter<com.bexp.ejb.CI.Networks.IPAddress.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedIPAddress.copy(lca); }        
        
//---------------------------------------------------------------------------------------
LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> relatedLAN;
public LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> getRelatedLAN()
        {
        if(relatedLAN==null)
        {
        class getter_t
        implements
        function1<Collection<ObjHandle<com.bexp.ejb.CI.LAN.SDObj>>, SDObjCMPBase>,
        Serializable
        {
        public getter_t() {}
        public Collection<ObjHandle<com.bexp.ejb.CI.LAN.SDObj>>
            Op(SDObjCMPBase arg) throws Exception
            {
            return Obj.ObjsToHandles(arg.getRelatedLANCMPs(),
                    com.bexp.ejb.CI.LAN.SDObj.class, false);
            }
        }
	relatedLAN = new LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase>
            (this.getPK(),com.bexp.ejb.CI.LAN.SDObj.class,SDObjCMPBase.class,new getter_t(),new CopyOnWriteArraySet());
        }
      return  relatedLAN;
        }
    public void setRelatedLAN(LazyCollectionAccessAdapter<com.bexp.ejb.CI.LAN.SDObj,SDObjCMPBase> lca) throws Exception
        {  if(lca!=null) relatedLAN.copy(lca); }        
        
//---------------------------------------------------------------------------------------







//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}