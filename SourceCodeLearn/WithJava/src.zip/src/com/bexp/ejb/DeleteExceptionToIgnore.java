package com.bexp.ejb;

public class DeleteExceptionToIgnore extends Exception
{
protected DeleteExceptionToIgnore()
	{super();}
}
