package com.bexp.ejb.Access;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.IObj
{


 
	public Set<ObjHandle<com.bexp.ejb.Person.SDObj> > getAllowedToViewPersons();
	public void setAllowedToViewPersons(Set<ObjHandle<com.bexp.ejb.Person.SDObj> > _arg) throws Exception;

	public Set<ObjHandle<com.bexp.ejb.UserGroup.SDObj> > getAllowedToViewGroups();
	public void setAllowedToViewGroups(Set<ObjHandle<com.bexp.ejb.UserGroup.SDObj> > _arg) throws Exception;

	public Set<ObjHandle<com.bexp.ejb.UserGroup.SDObj> > getAllowedGroups();
	public void setAllowedGroups(Set<ObjHandle<com.bexp.ejb.UserGroup.SDObj> > _arg) throws Exception;

	public Set<ObjHandle<com.bexp.ejb.Person.SDObj> > getAllowedPersons();
	public void setAllowedPersons(Set<ObjHandle<com.bexp.ejb.Person.SDObj> > _arg) throws Exception;









//---------------------------------------------------------------------------------
}