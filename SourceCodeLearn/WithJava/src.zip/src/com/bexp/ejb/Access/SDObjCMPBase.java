package com.bexp.ejb.Access;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.Access.SDObjCMPBase")
@Table(name = "Access")
public class SDObjCMPBase
    extends com.bexp.ejb.ObjCMPBean
    implements ISDObj,java.io.Serializable
{
   
	protected java.lang.String EntityNameInternal;
	public java.lang.String getEntityNameInternal() {
	 return EntityNameInternal;  	 
	 }
	public void setEntityNameInternal(java.lang.String locEntityNameInternal) throws Exception { 
	EntityNameInternal=locEntityNameInternal;
	}	


 
@Transient
public Set<ObjHandle<com.bexp.ejb.Person.SDObj> > getAllowedToViewPersons()
 {
        return Obj.ObjsToHandles(this.getAllowedToViewPersonsCMPs(),
            com.bexp.ejb.Person.SDObj.class, false);
        }
public void setAllowedToViewPersons(Set<ObjHandle<com.bexp.ejb.Person.SDObj> > _arg) throws Exception
{
        setManyToMany(this.getAllowedToViewPersonsCMPs(),
                _arg, com.bexp.ejb.Person.SDObjCMPBase.class, false);        
        }        

    java.util.Set<com.bexp.ejb.Person.SDObjCMPBase> allowedToViewPersonsCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "access_view_person",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.Person.SDObjCMPBase> getAllowedToViewPersonsCMPs()
        { return allowedToViewPersonsCMPs; }
    public void setAllowedToViewPersonsCMPs(Set<com.bexp.ejb.Person.SDObjCMPBase> cmps)
        { allowedToViewPersonsCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public Set<ObjHandle<com.bexp.ejb.UserGroup.SDObj> > getAllowedToViewGroups()
 {
        return Obj.ObjsToHandles(this.getAllowedToViewGroupsCMPs(),
            com.bexp.ejb.UserGroup.SDObj.class, false);
        }
public void setAllowedToViewGroups(Set<ObjHandle<com.bexp.ejb.UserGroup.SDObj> > _arg) throws Exception
{
        setManyToMany(this.getAllowedToViewGroupsCMPs(),
                _arg, com.bexp.ejb.UserGroup.SDObjCMPBase.class, false);        
        }        

    java.util.Set<com.bexp.ejb.UserGroup.SDObjCMPBase> allowedToViewGroupsCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "access_view_group",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.UserGroup.SDObjCMPBase> getAllowedToViewGroupsCMPs()
        { return allowedToViewGroupsCMPs; }
    public void setAllowedToViewGroupsCMPs(Set<com.bexp.ejb.UserGroup.SDObjCMPBase> cmps)
        { allowedToViewGroupsCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public Set<ObjHandle<com.bexp.ejb.UserGroup.SDObj> > getAllowedGroups()
 {
        return Obj.ObjsToHandles(this.getAllowedGroupsCMPs(),
            com.bexp.ejb.UserGroup.SDObj.class, false);
        }
public void setAllowedGroups(Set<ObjHandle<com.bexp.ejb.UserGroup.SDObj> > _arg) throws Exception
{
        setManyToMany(this.getAllowedGroupsCMPs(),
                _arg, com.bexp.ejb.UserGroup.SDObjCMPBase.class, false);        
        }        

    java.util.Set<com.bexp.ejb.UserGroup.SDObjCMPBase> allowedGroupsCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "access_create_group",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.UserGroup.SDObjCMPBase> getAllowedGroupsCMPs()
        { return allowedGroupsCMPs; }
    public void setAllowedGroupsCMPs(Set<com.bexp.ejb.UserGroup.SDObjCMPBase> cmps)
        { allowedGroupsCMPs = cmps; }
//------------------------------------------------------------------------------
@Transient
public Set<ObjHandle<com.bexp.ejb.Person.SDObj> > getAllowedPersons()
 {
        return Obj.ObjsToHandles(this.getAllowedPersonsCMPs(),
            com.bexp.ejb.Person.SDObj.class, false);
        }
public void setAllowedPersons(Set<ObjHandle<com.bexp.ejb.Person.SDObj> > _arg) throws Exception
{
        setManyToMany(this.getAllowedPersonsCMPs(),
                _arg, com.bexp.ejb.Person.SDObjCMPBase.class, false);        
        }        

    java.util.Set<com.bexp.ejb.Person.SDObjCMPBase> allowedPersonsCMPs;
    @ManyToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    @JoinTable(name = "access_create_person",
    joinColumns = {@JoinColumn(name = "ID1")},
        inverseJoinColumns = {@JoinColumn(name = "ID2")})
    public Set<com.bexp.ejb.Person.SDObjCMPBase> getAllowedPersonsCMPs()
        { return allowedPersonsCMPs; }
    public void setAllowedPersonsCMPs(Set<com.bexp.ejb.Person.SDObjCMPBase> cmps)
        { allowedPersonsCMPs = cmps; }
//------------------------------------------------------------------------------








//---------------------------------------------------------------------------------
    @PrePersist
    public void pre_persist() throws Exception
        {
    	this.setIsRemoved(false);
        }
    @Transient
    public String getDescription() throws Exception
        { return getEntityNameInternal(); }
    public void setDescription(String _name) throws Exception
        { }
}

