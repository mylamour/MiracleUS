package com.bexp.ejb.Access;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.Obj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.Access.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.Access";
    

//---------------------------------------------------------------------------------------

    Set<ObjHandle<com.bexp.ejb.Person.SDObj> > allowedToViewPersons = new CopyOnWriteArraySet();    
    public Set<ObjHandle<com.bexp.ejb.Person.SDObj> > getAllowedToViewPersons()
        { return allowedToViewPersons; }
    public void setAllowedToViewPersons(Set<ObjHandle<com.bexp.ejb.Person.SDObj> > _arg) throws Exception
        { allowedToViewPersons.clear(); if(_arg!=null) {allowedToViewPersons.addAll(_arg);} }        
//---------------------------------------------------------------------------------------
    Set<ObjHandle<com.bexp.ejb.UserGroup.SDObj> > allowedToViewGroups = new CopyOnWriteArraySet();    
    public Set<ObjHandle<com.bexp.ejb.UserGroup.SDObj> > getAllowedToViewGroups()
        { return allowedToViewGroups; }
    public void setAllowedToViewGroups(Set<ObjHandle<com.bexp.ejb.UserGroup.SDObj> > _arg) throws Exception
        { allowedToViewGroups.clear(); if(_arg!=null) {allowedToViewGroups.addAll(_arg);} }        
//---------------------------------------------------------------------------------------
    Set<ObjHandle<com.bexp.ejb.UserGroup.SDObj> > allowedGroups = new CopyOnWriteArraySet();    
    public Set<ObjHandle<com.bexp.ejb.UserGroup.SDObj> > getAllowedGroups()
        { return allowedGroups; }
    public void setAllowedGroups(Set<ObjHandle<com.bexp.ejb.UserGroup.SDObj> > _arg) throws Exception
        { allowedGroups.clear(); if(_arg!=null) {allowedGroups.addAll(_arg);} }        
//---------------------------------------------------------------------------------------
    Set<ObjHandle<com.bexp.ejb.Person.SDObj> > allowedPersons = new CopyOnWriteArraySet();    
    public Set<ObjHandle<com.bexp.ejb.Person.SDObj> > getAllowedPersons()
        { return allowedPersons; }
    public void setAllowedPersons(Set<ObjHandle<com.bexp.ejb.Person.SDObj> > _arg) throws Exception
        { allowedPersons.clear(); if(_arg!=null) {allowedPersons.addAll(_arg);} }        
//---------------------------------------------------------------------------------------








//---------------------------------------------------------------------------------


    public void save() throws Exception
    {

     super.save();
    }
}