package com.bexp.ejb;

import javax.persistence.EntityManagerFactory;

public interface ISecurityDomainHelper
    {
    public EntityManagerFactory getEMF();
    public java.security.Principal getPrincipal() throws Exception;
    }
