package com.bexp.ejb.Approval.ApprovalItem;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.Approval.ApprovalItem.SDObjCMPBase")
@Table(name = "ApprovalItem")
public class SDObjCMPBase
    extends com.bexp.ejb.ObjCMPBean
    implements ISDObj,java.io.Serializable
{
   
	protected java.lang.String Comment;
	public java.lang.String getComment() {
	 return Comment;  	 
	 }
	public void setComment(java.lang.String locComment) throws Exception { 
	Comment=locComment;
	}	

	protected com.bexp.ejb.Approval.ApprovalItem.ApprovalItemStatus Approved;
	public com.bexp.ejb.Approval.ApprovalItem.ApprovalItemStatus getApproved() {
	 return Approved;  	 
	 }
	public void setApproved(com.bexp.ejb.Approval.ApprovalItem.ApprovalItemStatus locApproved) throws Exception { 
	Approved=locApproved;
	}	


 



    @Transient
    public ObjHandle<com.bexp.ejb.Person.SDObj> getApprover() throws Exception
        {
        ObjCMPBean cmp = getApproverCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Person.SDObj>(cmp,com.bexp.ejb.Person.SDObj.class);
        }
    public void setApprover(ObjHandle<com.bexp.ejb.Person.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setApproverCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Person.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.Person.SDObjCMPBase approverCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Person.SDObjCMPBase getApproverCMP()
        { return approverCMP; }
    public void setApproverCMP(com.bexp.ejb.Person.SDObjCMPBase cicmp)
        { approverCMP = cicmp; }
//------------------------------------------------------------------------------

    @Transient
    public ObjHandle<com.bexp.ejb.Approval.SDObj> getApproval() throws Exception
        {
        ObjCMPBean cmp = getApprovalCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Approval.SDObj>(cmp,com.bexp.ejb.Approval.SDObj.class);
        }
    public void setApproval(ObjHandle<com.bexp.ejb.Approval.SDObj> handle) throws Exception
        {
        Object pk = handle.getPK();
        this.setApprovalCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Approval.SDObjCMPBase.class,pk) );
        }

        com.bexp.ejb.Approval.SDObjCMPBase approvalCMP;
    @ManyToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Approval.SDObjCMPBase getApprovalCMP()
        { return approvalCMP; }
    public void setApprovalCMP(com.bexp.ejb.Approval.SDObjCMPBase cicmp)
        { approvalCMP = cicmp; }
//------------------------------------------------------------------------------




    @Transient
    public ObjHandle<com.bexp.ejb.Approval.SDObj> getRelatedApproval() throws Exception
        {
        ObjCMPBean cmp = getRelatedApprovalCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Approval.SDObj>(cmp,com.bexp.ejb.Approval.SDObj.class);
        }
    public void setRelatedApproval(ObjHandle<com.bexp.ejb.Approval.SDObj> arg) throws Exception
        {
        Object pk = arg.getPK();
        this.setRelatedApprovalCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Approval.SDObjCMPBase.class,arg.getPK()) );
        }
    
        com.bexp.ejb.Approval.SDObjCMPBase relatedApprovalCMP;
	@OneToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Approval.SDObjCMPBase getRelatedApprovalCMP()
        { return relatedApprovalCMP;}
    public void setRelatedApprovalCMP(com.bexp.ejb.Approval.SDObjCMPBase cmp)
        { relatedApprovalCMP = cmp; }
//------------------------------------------------------------------------------        


//---------------------------------------------------------------------------------
}

