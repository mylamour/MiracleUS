package com.bexp.ejb.Approval.ApprovalItem;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.IObj
{
    public java.lang.String getComment();
    public void setComment(java.lang.String locComment) throws Exception;

    public com.bexp.ejb.Approval.ApprovalItem.ApprovalItemStatus getApproved();
    public void setApproved(com.bexp.ejb.Approval.ApprovalItem.ApprovalItemStatus locApproved) throws Exception;


 



    public ObjHandle<com.bexp.ejb.Person.SDObj> getApprover() throws Exception;
    public void setApprover(ObjHandle<com.bexp.ejb.Person.SDObj> handle) throws Exception;

    public ObjHandle<com.bexp.ejb.Approval.SDObj> getApproval() throws Exception;
    public void setApproval(ObjHandle<com.bexp.ejb.Approval.SDObj> handle) throws Exception;





    public ObjHandle<com.bexp.ejb.Approval.SDObj> getRelatedApproval() throws Exception;
    public void setRelatedApproval(ObjHandle<com.bexp.ejb.Approval.SDObj> handles) throws Exception;


//---------------------------------------------------------------------------------
}