package com.bexp.ejb.Approval.ApprovalItem;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.Obj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.Approval.ApprovalItem.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.Approval.ApprovalItem";
    
	protected java.lang.String Comment;
	public java.lang.String getComment() {
	 return Comment;  	 
	 }
	public void setComment(java.lang.String locComment) throws Exception { 
	Comment=locComment;
	}	

	protected com.bexp.ejb.Approval.ApprovalItem.ApprovalItemStatus Approved;
	public com.bexp.ejb.Approval.ApprovalItem.ApprovalItemStatus getApproved() {
	 return Approved;  	 
	 }
	public void setApproved(com.bexp.ejb.Approval.ApprovalItem.ApprovalItemStatus locApproved) throws Exception { 
	Approved=locApproved;
	}	


//---------------------------------------------------------------------------------------





    ObjHandle<com.bexp.ejb.Person.SDObj> approver
            = new ObjHandle<com.bexp.ejb.Person.SDObj>(null,false,com.bexp.ejb.Person.SDObj.class);
    public ObjHandle<com.bexp.ejb.Person.SDObj> getApprover() throws Exception
        {
        return approver;
        }
    public void setApprover(ObjHandle<com.bexp.ejb.Person.SDObj> handle) throws Exception
        {
        approver.copy(handle);
        approver.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.Approval.SDObj> approval
            = new ObjHandle<com.bexp.ejb.Approval.SDObj>(null,false,com.bexp.ejb.Approval.SDObj.class);
    public ObjHandle<com.bexp.ejb.Approval.SDObj> getApproval() throws Exception
        {
        return approval;
        }
    public void setApproval(ObjHandle<com.bexp.ejb.Approval.SDObj> handle) throws Exception
        {
        approval.copy(handle);
        approval.setIsCachable(true);
        }
//---------------------------------------------------------------------------------------




    ObjHandle<com.bexp.ejb.Approval.SDObj> relatedApproval
        = new ObjHandle<com.bexp.ejb.Approval.SDObj>(null,false,com.bexp.ejb.Approval.SDObj.class);

    public ObjHandle<com.bexp.ejb.Approval.SDObj> getRelatedApproval() throws Exception
        { return relatedApproval; }
    public void setRelatedApproval(ObjHandle<com.bexp.ejb.Approval.SDObj> arg) throws Exception
        { relatedApproval.copy(arg); }
//---------------------------------------------------------------------------------------


//---------------------------------------------------------------------------------


    public void save() throws Exception
    {


     super.save();
    }
}