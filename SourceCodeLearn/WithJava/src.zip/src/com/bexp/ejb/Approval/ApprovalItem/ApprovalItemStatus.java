package com.bexp.ejb.Approval.ApprovalItem;
public enum ApprovalItemStatus {
Undefined,
Yes,
No
}
