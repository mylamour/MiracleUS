package com.bexp.ejb.Approval;

import java.lang.*;
import java.io.*;
import java.util.*;
import com.bexp.ejb.*;
import java.util.concurrent.*;
import org.JWrapper.function1;

public class SDObj extends com.bexp.ejb.Obj
	implements Serializable
		,ISDObj
		,Cloneable
{        
    public SDObj()  { }
     public String ClassName(String str) {
 
	 return "com.bexp.ejb.Approval.SDObj";
 }
    
    protected String package_name = "com.bexp.ejb.Approval";
    

//---------------------------------------------------------------------------------------





    Set<ObjHandle<com.bexp.ejb.Approval.ApprovalItem.SDObj> > approvalItems = new CopyOnWriteArraySet();    
    public Set<ObjHandle<com.bexp.ejb.Approval.ApprovalItem.SDObj> > getApprovalItems()
        { return approvalItems; }
    public void setApprovalItems(Set<ObjHandle<com.bexp.ejb.Approval.ApprovalItem.SDObj> > _arg) throws Exception
        { approvalItems.clear(); if(_arg!=null) {approvalItems.addAll(_arg);} }                        
        
//---------------------------------------------------------------------------------------



    ObjHandle<com.bexp.ejb.Approval.ApprovalItem.SDObj> relatedApprovalItem
        = new ObjHandle<com.bexp.ejb.Approval.ApprovalItem.SDObj>(null,false,com.bexp.ejb.Approval.ApprovalItem.SDObj.class);

    public ObjHandle<com.bexp.ejb.Approval.ApprovalItem.SDObj> getRelatedApprovalItem() throws Exception
        { return relatedApprovalItem; }
    public void setRelatedApprovalItem(ObjHandle<com.bexp.ejb.Approval.ApprovalItem.SDObj> arg) throws Exception
        { relatedApprovalItem.copy(arg); }
//---------------------------------------------------------------------------------------

    ObjHandle<com.bexp.ejb.WorkflowObject.SDObj> workflowObject
        = new ObjHandle<com.bexp.ejb.WorkflowObject.SDObj>(null,false,com.bexp.ejb.WorkflowObject.SDObj.class);

    public ObjHandle<com.bexp.ejb.WorkflowObject.SDObj> getWorkflowObject() throws Exception
        { return workflowObject; }
    public void setWorkflowObject(ObjHandle<com.bexp.ejb.WorkflowObject.SDObj> arg) throws Exception
        { workflowObject.copy(arg); }
//---------------------------------------------------------------------------------------


//---------------------------------------------------------------------------------


    public void save() throws Exception
    {
     super.save();
    }
}