package com.bexp.ejb.Approval;

import java.util.*;
import javax.persistence.*;
import javax.ejb.*;
import javax.naming.*;
import org.JWrapper.*;
import org.jboss.annotation.security.SecurityDomain;

import java.sql.*;
import com.bexp.ejb.*;

import static com.bexp.ejb.ObjHomeBean.*;

@Entity(name="com.bexp.ejb.Approval.SDObjCMPBase")
@Table(name = "Approval")
public class SDObjCMPBase
    extends com.bexp.ejb.ObjCMPBean
    implements ISDObj,java.io.Serializable
{
   

 





    @Transient
public Set<ObjHandle<com.bexp.ejb.Approval.ApprovalItem.SDObj> > getApprovalItems()
 {
        return Obj.ObjsToHandles(this.getApprovalItemsCMPs(),
            com.bexp.ejb.Approval.ApprovalItem.SDObj.class, false);
        }
public void setApprovalItems(Set<ObjHandle<com.bexp.ejb.Approval.ApprovalItem.SDObj> > handles) throws Exception
 {
      setOneToMany(this.getApprovalItemsCMPs(),
             handles, com.bexp.ejb.Approval.ApprovalItem.SDObjCMPBase.class,
                new function2<Void,com.bexp.ejb.Approval.ApprovalItem.SDObjCMPBase, SDObjCMPBase>()
                {public Void Op(com.bexp.ejb.Approval.ApprovalItem.SDObjCMPBase owner_cmp,SDObjCMPBase cmp)
                    { owner_cmp.setApprovalCMP(cmp); return null; }}
             ,false);
 }
    
        java.util.Set<com.bexp.ejb.Approval.ApprovalItem.SDObjCMPBase> approvalItemsCMPs;
    @OneToMany(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH,mappedBy="approvalCMP")
    public Set<com.bexp.ejb.Approval.ApprovalItem.SDObjCMPBase> getApprovalItemsCMPs()
        { return approvalItemsCMPs; }
    public void setApprovalItemsCMPs (Set<com.bexp.ejb.Approval.ApprovalItem.SDObjCMPBase> cmps)
        { approvalItemsCMPs = cmps;}   
//------------------------------------------------------------------------------            

    @Transient
    public ObjHandle<com.bexp.ejb.Approval.ApprovalItem.SDObj> getRelatedApprovalItem() throws Exception
        {
        ObjCMPBean cmp = getRelatedApprovalItemCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.Approval.ApprovalItem.SDObj>(cmp,com.bexp.ejb.Approval.ApprovalItem.SDObj.class);
        }
    public void setRelatedApprovalItem(ObjHandle<com.bexp.ejb.Approval.ApprovalItem.SDObj> arg) throws Exception
        {
        Object pk = arg.getPK();
        this.setRelatedApprovalItemCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.Approval.ApprovalItem.SDObjCMPBase.class,arg.getPK()) );
        }
    
        com.bexp.ejb.Approval.ApprovalItem.SDObjCMPBase relatedApprovalItemCMP;
	@OneToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.Approval.ApprovalItem.SDObjCMPBase getRelatedApprovalItemCMP()
        { return relatedApprovalItemCMP;}
    public void setRelatedApprovalItemCMP(com.bexp.ejb.Approval.ApprovalItem.SDObjCMPBase cmp)
        { relatedApprovalItemCMP = cmp; }
//------------------------------------------------------------------------------        
    @Transient
    public ObjHandle<com.bexp.ejb.WorkflowObject.SDObj> getWorkflowObject() throws Exception
        {
        ObjCMPBean cmp = getWorkflowObjectCMP();
        Object pk = null;
        if(cmp!=null) { pk=cmp.getPK(); }
        return new ObjHandle<com.bexp.ejb.WorkflowObject.SDObj>(cmp,com.bexp.ejb.WorkflowObject.SDObj.class);
        }
    public void setWorkflowObject(ObjHandle<com.bexp.ejb.WorkflowObject.SDObj> arg) throws Exception
        {
        Object pk = arg.getPK();
        this.setWorkflowObjectCMP((pk==null)?(null):
                getEM().find(com.bexp.ejb.WorkflowObject.SDObjCMPBase.class,arg.getPK()) );
        }
    
        com.bexp.ejb.WorkflowObject.SDObjCMPBase workflowObjectCMP;
	@OneToOne(fetch = FetchType.LAZY,cascade=CascadeType.REFRESH)
    public com.bexp.ejb.WorkflowObject.SDObjCMPBase getWorkflowObjectCMP()
        { return workflowObjectCMP;}
    public void setWorkflowObjectCMP(com.bexp.ejb.WorkflowObject.SDObjCMPBase cmp)
        { workflowObjectCMP = cmp; }
//------------------------------------------------------------------------------        


//---------------------------------------------------------------------------------
}

