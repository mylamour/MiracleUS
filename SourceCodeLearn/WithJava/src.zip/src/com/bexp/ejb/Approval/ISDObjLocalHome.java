package com.bexp.ejb.Approval;
import com.bexp.ejb.*;
import java.util.*;

public interface ISDObjLocalHome
    extends com.bexp.ejb.IObjLocalHome
{

//---------------------------------------------------------------------------------
}
