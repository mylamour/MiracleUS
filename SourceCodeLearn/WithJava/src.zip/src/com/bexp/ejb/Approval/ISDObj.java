package com.bexp.ejb.Approval;

import java.lang.*;
import java.util.*;
import com.bexp.ejb.*;

public interface ISDObj extends com.bexp.ejb.IObj
{

 





    public Set<ObjHandle<com.bexp.ejb.Approval.ApprovalItem.SDObj> > getApprovalItems();
	public void setApprovalItems(Set<ObjHandle<com.bexp.ejb.Approval.ApprovalItem.SDObj> > _arg) throws Exception;



    public ObjHandle<com.bexp.ejb.Approval.ApprovalItem.SDObj> getRelatedApprovalItem() throws Exception;
    public void setRelatedApprovalItem(ObjHandle<com.bexp.ejb.Approval.ApprovalItem.SDObj> handles) throws Exception;

    public ObjHandle<com.bexp.ejb.WorkflowObject.SDObj> getWorkflowObject() throws Exception;
    public void setWorkflowObject(ObjHandle<com.bexp.ejb.WorkflowObject.SDObj> handles) throws Exception;


//---------------------------------------------------------------------------------
}