package com.bexp.ejb;

import java.util.Collection;
import java.util.List;

import javax.ejb.*;
import javax.persistence.*;


//import javax.ejb.*;

public interface IObjLocalHome<Obj_t extends Obj>
    extends IObjHome<Obj_t>
{
    public javax.ejb.Timer createTimer(java.util.Date exp, java.io.Serializable info) throws Exception;
    public java.security.Principal getPrincipal() throws Exception;
    public SessionContext getSessionContext() throws Exception;
    public EntityManagerFactory getEMF();
    public EntityManager getJTAEntityManager();
    
    public boolean IS_CREATE_ALLOWED() throws Exception;
    public boolean IS_VIEW_ALLOWED() throws Exception;
    
    public /*void*/ObjCMPBean SAVE(Obj_t sobj) throws Exception;
    public Obj_t CREATEOBJ() throws Exception;
    public void DELETE(Object PK) throws Exception;    
    
    public Obj_t CMP_to_OBJ(ObjCMPBean in) throws Exception;
    public Collection<Obj_t> CMPs_to_OBJs(Collection<ObjCMPBean> from) throws Exception;
    
    public ObjHomeEvent createEvent(IObj obj, int event_id) throws Exception;

    public com.bexp.ejb.Access.SDObjCMPBase getAccessCMP() throws Exception;
    
//    public Class getCMPBaseClass();
    public Class getCMPBeanClass();
//    public Class getCMPTrashClass();
    
    public List queryAll();
    
    public List queryByDescriptionCMPs(String description);
    
    public void timeout(javax.ejb.Timer timer);
    
    public Obj[] GET_OBJs(java.util.List PKs) throws Exception;
    public Obj_t GET_OBJ(Object PK) throws Exception;
    public List queryAllPKs();
    public void post_construct();

}
