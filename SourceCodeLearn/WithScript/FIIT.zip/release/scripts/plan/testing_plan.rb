require 'singleton'
include_class Java::sk.fiit.jim.Settings

class TestingPlan
  include Singleton
  
  def initialize
    @plan = []
    @beamed = false
    @low_skill = Settings.get_string("lowSkillToPerform") || "walk"
  end
  
  def control
    begin
      replan if (@plan.empty? or @plan[0].ended?)
      @plan[0].execute unless @plan.empty?
    rescue
      @plan.clear
    end
  end
  
  def replan
    @plan.clear
    if not @beamed
      @plan << Beam.new
      @beamed = true
    else
      @plan << LowSkillTest.new(@low_skill)
    end 
  end
  
  def reset
    @plan.clear
    @beamed = false
    @low_skill = Settings.get_string("lowSkillToPerform") || "walk"
  end
end

#reset on 2nd load => causing replan
TestingPlan.instance.reset