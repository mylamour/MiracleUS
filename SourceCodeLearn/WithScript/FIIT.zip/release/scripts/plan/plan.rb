require 'singleton'
include_class Java::sk.fiit.jim.agent.models.EnvironmentModel

class Plan
  include Singleton
  
  BEAMABLE = [EnvironmentModel::PlayMode::BEFORE_KICK_OFF, EnvironmentModel::PlayMode::GAME_OVER, EnvironmentModel::PlayMode::GOAL_LEFT,
      EnvironmentModel::PlayMode::GOAL_RIGHT, EnvironmentModel::PlayMode::KICK_OFF_RIGHT]
  
  def Plan.angle_range from, to
    (from/180.0*Math::PI)..(to/180.0*Math::PI)
  end
  
  @@straight_range1 = angle_range(0.0, 30.0)
  @@straight_range2 = angle_range(330.0, 360.0)
  
  def initialize
    @plan = []
    @beamed = false
    @last_playmode = EnvironmentModel::PlayMode::BEFORE_KICK_OFF
  end
  
  def control
    begin
      mode = environment play_mode
      if not @plan.empty? and (mode != @last_playmode or not localized?) 
        current_skill = @plan[0]
        @plan.clear
        @plan << FinishHighSkill.new(current_skill)
      end
      
      replan if (@plan.empty? or @plan[0].ended?)
      @plan[0].execute unless @plan.empty?
    rescue
      @plan.clear
      replan
      @plan[0].execute
    end
    @last_playmode = environment play_mode
  end
  
  def replan
    log "Planning!"
    @plan.clear
    if beamable_play_mode?
      @plan << Beam.new
      @beamed = true
    elsif me.on_ground?
     @plan << GetUp.new
    elsif not localized?
     @plan << Localize.new
    elsif ball_distant? 
     @plan << Walk.new(Proc.new{ball relative position}, Proc.new{ball_distant?})
#    elsif not turned_to_goal?
#     #turn to opponents goal center 
#     @plan << Turn.to_point(Vector3D.cartesian(9, 0, 0)) 
    else
     @plan << Kick.new
    end
  end
  
  def reset
    @plan.clear
    @beamed = false
  end
  
  def beamable_play_mode?
    mode = environment play_mode
    BEAMABLE.each do |pmode|
      return true if pmode === mode
    end
    return false
  end
  
  def localized?
    diff = environment(time) - me.last_time_flag_seen
    #5 seconds allowed for being "blind"
    diff < 5.0
  end
  
  def ball_distant?
    distance = ball relative position
    distance = distance.set_z(0.0)
    not (distance.r < 0.3 and (@@straight_range1.member?(distance.phi) or @@straight_range2.member?(distance.phi))) 
  end
  
  def turned_to_goal?
    Turn.is_towards?(Vector3D.cartesian(9, 0, 0))
  end

  def current_high_skill
    @plan[0]
  end
  
  #------------override Ruby's global logging => log PLANNING instead--------------
  
  def log message = ""
    Log.log LogType::PLANNING, message.to_s
  end

  def debug message = ""
    Log.debug LogType::PLANNING, message.to_s
  end

  def error message = ""
    Log.error LogType::PLANNING, message.to_s
  end
end

#reset on 2nd load => causing replan
Plan.instance.reset