dir = File.expand_path File.dirname(__FILE__)
$LOAD_PATH.unshift File.dirname(__FILE__)
include Java

class Boot
  @@last_time_loaded ||= 0
  
  def Boot.last_time_loaded
    @@last_time_loaded
  end
  
  def Boot.last_time_loaded= value
    @@last_time_loaded = value
  end
end

absolute_path_to_boot = File.expand_path __FILE__

Dir["#{dir}/**/*.rb"].each do |ruby_file|
  next if ruby_file == __FILE__
  next if File.mtime(ruby_file).to_i < Boot.last_time_loaded
  puts "Loading #{ruby_file}"
  load ruby_file
end

Boot.last_time_loaded = Time.now.to_i