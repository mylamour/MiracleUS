include Java
include_class Java::sk.fiit.jim.agent.models.EnvironmentModel
include_class Java::sk.fiit.jim.agent.AgentInfo
include_class Java::sk.fiit.jim.agent.communication.Communication
include_class Java::sk.fiit.jim.Settings

EnvironmentModel.version = EnvironmentModel::Version::VERSION_0_6_3

AgentInfo::team = "JIM"
#player_id set to zero means the server will decide what the number is going to be
AgentInfo::playerId = 0

#home computer
Communication.instance.server_ip = "192.168.1.100"
#Communication.instance.server_ip = "10.62.120.206"
#Ivan
#Communication.instance.server_ip = "192.168.1.3"

Communication.instance.port = 3100

Settings.set_value "ignoreAccelerometer", true
Settings.set_value "kalmanUseFilter", true
Settings.set_value "kalmanDefaultQ", 0.475
Settings.set_value "kalmanDefaultR", 0.375
Settings.set_value "runGcOnPhaseStart", true
Settings.set_value "runGui", true
Settings.set_value "gravityAcceleration", 9.81
#limit on the side of server - can't do very much about it
Settings.set_value "maximumAngularChangePerQuantum", 7.0
Settings.set_value "logToGui", false
Settings.set_value "serverFrictionPerSecond", 0.65