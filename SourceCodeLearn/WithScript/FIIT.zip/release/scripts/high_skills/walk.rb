require 'high_skills/ruby_high_skill.rb'
include_class Java::sk.fiit.jim.math.Angles
include_class Java::java.lang.Math
include_class Java::sk.fiit.jim.agent.moves.ComputedValues
include_class Java::sk.fiit.jim.agent.moves.ComputedValue

class Walk < RubyHighSkill
  
  def Walk.angle_range from, to
    (from/180.0*Math::PI)..(to/180.0*Math::PI)
  end
  
  #320 - 340 degrees - keep last chosen to prevent flapping
  @@right_straight_crossing = angle_range(320.0, 345.0)
  #20 - 40 degrees - keep last chosen to prevent flapping
  @@left_straight_crossing = angle_range(15.0, 40.0)
  #65 - 85 - the same as above
  @@left_strafe_crossing = angle_range(65.0, 85.0)
  #275..295
  @@right_strafe_crossing = angle_range(275.0, 295.0)
  ##same...
  @@left_back_crossing = angle_range(80.0, 100.0)
  @@right_back_crossing = angle_range(260.0, 280.0)
  
  #careful - do not put 330 instead of -30, will cause havoc in Ruby range, as expected (it doesn't know it is dealing with degrees)
  @@straight_range1 = angle_range(0.0, 30.0)
  @@straight_range2 = angle_range(330.0, 360.0)
  @@back_range = angle_range(90.0, 270.0)
  #270 - 330 degrees
  @@right_range = angle_range(270.0, 330.0)
  #30 - 90 degrees
  @@left_range = angle_range(30.0, 90.0)
  #75 - 90 degrees
  @@left_strafe_range = angle_range(75.0, 90.0)
  #270 - 285 degrees
  @@right_strafe_range = angle_range(270.0, 285.0)
  @@strafe_distance = 1.5
  
  
  def initialize target_proc, validity_proc
    super()
    @target = target_proc
    @validity_proc = validity_proc || Proc.new{return true}
  end
  
  def pickLowSkill
    target_position = @target.call if not @target.nil?
    #end execution if Procedure returns nil
    return nil if target_position.nil? or not @validity_proc.call
    
    target_position = target_position.set_z(0.0)
    log "Angle to ball: #{target_position.phi * 180.0 / Math::PI}"
    ComputedValues.reset
    look_to_ball
    
    case
      #keep last skill if you are on the border of multiple skills
      when (@@right_straight_crossing.include?(target_position.phi) and not currentSkill.nil?): lean_right; return get_skill("walk_fine")
      when (@@left_straight_crossing.include?(target_position.phi) and not currentSkill.nil?): lean_left; return get_skill("walk_fine")
      when (@@left_strafe_crossing.include?(target_position.phi) and not currentSkill.nil?): return currentSkill
      when (@@right_strafe_crossing.include?(target_position.phi) and not currentSkill.nil?): return currentSkill
      when (@@left_back_crossing.include?(target_position.phi) and not currentSkill.nil?): return currentSkill
      when (@@right_back_crossing.include?(target_position.phi) and not currentSkill.nil?): return currentSkill
      when straight?(target_position)           : return get_skill("walk_fine")
      when back?(target_position)               : return get_skill("turn_left_big")
      when left_and_close?(target_position)     : log "Strafing"; return get_skill("strafe_left")
      when right_and_close?(target_position)    : log "Strafing"; return get_skill("strafe_right")
      when left_and_distant?(target_position)   : return get_skill("turn_left_big")
      when right_and_distant?(target_position)  : return get_skill("turn_right_big")
    end
  end
  
  def look_to_ball
    #experimental only - fix your view point to ball
    whereIsBall = ball relative position
    targetPhi = Math.toDegrees whereIsBall.phi
    targetPhi = targetPhi > 180.0 ? targetPhi - 360.0 : targetPhi
    
    ComputedValues.set ComputedValue.new("headAngle1"), targetPhi
    
    targetTheta = Math.toDegrees whereIsBall.theta
    targetTheta = targetTheta > 180.0 ? targetTheta - 360.0 : targetTheta
    ComputedValues.set ComputedValue.new("headAngle2"), targetTheta
  end
  
  def close_enough? target_position
    target_position.r < 0.4
  end
  
  def straight? target_position
    @@straight_range1.include?(target_position.phi) or @@straight_range2.include?(target_position.phi) 
  end
  
  def back? target_position
    @@back_range.include?(target_position.phi)
  end
  
  def left_and_close? target_position
    (target_position.r <= @@strafe_distance) and @@left_range.include?(Angles.normalize(target_position.phi))
  end
  
  def right_and_close? target_position
    (target_position.r <= @@strafe_distance) and @@right_range.include?(Angles.normalize(target_position.phi))
  end
  
  def left_and_distant? target_position
    @@left_range.include?(Angles.normalize(target_position.phi))
  end
  
  def right_and_distant? target_position
    @@right_range.include?(Angles.normalize(target_position.phi))
  end
  
  def lean_right
    log "Leaning to right!"
    ComputedValues.set ComputedValue.new("right_walk_lean_rle3"), 53
    ComputedValues.set ComputedValue.new("right_walk_lean_rle5"), 32
  end
  
  def lean_left
    log "Leaning to left!"
    ComputedValues.set ComputedValue.new("left_walk_lean_lle3"), 53
    ComputedValues.set ComputedValue.new("left_walk_lean_lle5"), 32
  end
  
  def checkProgress
    log "Falling => #{currentSkill.name}" if me.on_ground?
    raise "Fallen!" if me.on_ground? and not currentSkill.nil? and not (currentSkill.name == "turn_right_big" or currentSkill.name == "turn_left_big")
  end
  
  def abs number
    Math.abs number
  end
end

#in order not to defer the startup cost
Walk.new nil, nil