class RubyHighSkill < Java::sk.fiit.jim.agent.skills.HighSkill
  
  def pickLowSkill
    raise "Abstract pickLowSkill called"
  end
  
  def checkProgress
    raise "Abstract checkProgress called"
  end
  
  def get_skill skill_name
    log "Chosen skill: #{skill_name}"
    Java::sk.fiit.jim.agent.moves.LowSkills.get skill_name
  end
  
  def current_low_skill
    current_skill.nil? ? "nil" : currentSkill.name
  end
end