require 'high_skills/ruby_high_skill.rb'

class Localize < RubyHighSkill
  
  def initialize
    super
    @turned_already = false  
  end
  
  def pickLowSkill
    return nil if localized?
    unless @run_already then
      @run_already = true
      return get_skill "lookout"
    else
      return get_skill "turn_left"
    end
  end
 
  def checkProgress
    raise "Fallen" if me.on_ground?
  end
  
  def localized?
    diff = environment(time) - me.last_time_flag_seen
    #5 seconds allowed for being "blind"
    diff < 5.0
  end
end