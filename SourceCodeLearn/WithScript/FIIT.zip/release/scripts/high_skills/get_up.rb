require 'high_skills/ruby_high_skill.rb'
include_class Java::sk.fiit.jim.agent.moves.ComputedValues
include_class Java::sk.fiit.jim.agent.moves.ComputedValue

class GetUp < RubyHighSkill
  
  def pickLowSkill
    return nil if not me.on_ground?
    @first_time_run = @first_time_run.nil?
    if @first_time_run
      @first_time_run = false
      ComputedValues.set ComputedValue.new("rollbackArms"), -90.0
      return get_skill("rollback")
    end
    @tries ||= 0
    @tries += 1
    #try the other way around if not succesful for 5 times
    reversed = @tries % 5 == 0
    reversed = false
    
    log "Reversing used skills" if reversed
    
    skill = case
      when (me.lying_on_back? and not reversed) then get_skill("stand_back")
      when (me.lying_on_back? and reversed) then get_skill("stand_front")
      when (me.lying_on_belly? and not reversed) then get_skill("stand_front")
      when (me.lying_on_belly? and reversed) then get_skill("stand_back")  
    end
    return skill
  end
  
  def checkProgress
    #do nothing
  end
end

#in order not to defer the startup cost
GetUp.new