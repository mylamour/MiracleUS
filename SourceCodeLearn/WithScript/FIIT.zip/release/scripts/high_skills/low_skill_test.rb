require 'high_skills/ruby_high_skill.rb'

class LowSkillTest < RubyHighSkill
  
  def initialize skill_name
    super()
    @skill = Java::sk.fiit.jim.agent.moves.LowSkills.get skill_name
  end
  
  def pickLowSkill
#    @counter ||= 0
#    if (@counter == 1)
#      return nil
#    end
#    @counter += 1
    log "About to try skill: #{@skill.name}"
    @skill
  end
  
  def checkProgress
    #do nothing
  end
end

#in order not to defer startup cost
LowSkillTest.new ""