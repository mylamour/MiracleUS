require 'high_skills/ruby_high_skill.rb'

class FinishHighSkill < RubyHighSkill
  def initialize original
    super()
    @original = original
    self.current_skill = original.current_skill
  end
  
  #return no skill - ceases the execution of the original
  def pickLowSkill
    nil
  end
  
  def checkProgress
    @original.checkProgress
  end
end