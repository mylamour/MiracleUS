require 'high_skills/ruby_high_skill.rb'
include_class Java::sk.fiit.jim.math.Angles

class Turn < RubyHighSkill
  
  @@turn_right_range = Math::PI...(Math::PI*2.0)
  @@turn_left_range = 0...Math::PI
  @@in_place_range1 = 0...(Math::PI*0.1)
  @@in_place_range2 = (Math::PI*1.9)...(Math::PI*2.0)
  
  def initialize angle
    super()
    @target_angle = Angles.normalize angle
  end
  
  def Turn.to_point point
    me_flattened = my.position.set_z(0.0)    
    target_vector = point - me_flattened
    target_angle = target_vector.phi
    Turn.new target_angle
  end
  
  def Turn.to_angle angle
    Turn.new angle
  end
  
  def Turn.by_angle angle
    target_angle = my.rotation_z + angle
    Turn.new target_angle
  end
  
  def pickLowSkill
    diff_against_current = Angles.normalize(@target_angle - my.rotation_z)
    log "Angle diff is: #{diff_against_current}"
    
    case diff_against_current
      when @@in_place_range1 : nil
      when @@in_place_range2 : nil
      when @@turn_left_range : get_skill("turn_left")
      when @@turn_right_range : get_skill("turn_right")
    end
  end
  
  def Turn.is_towards? point
    me_flattened = my.position.set_z(0.0)
    target_vector = point - me_flattened
    target_angle = target_vector.phi
    diff_against_current = Angles.normalize(target_angle - my.rotation_z)
    @@in_place_range1.include?(diff_against_current) or @@in_place_range2.include?(diff_against_current)
  end
  
  def checkProgress
    raise "Fallen!" if me.on_ground?
  end
end

#in order not to defer the startup cost
Turn.new 0.0