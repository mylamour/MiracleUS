require 'high_skills/ruby_high_skill.rb'

class Kick < RubyHighSkill
  
  def pickLowSkill
    log "Kicking"
    @kicked ||= false
    return nil if @kicked
    ball_pos = ball relative position
    case ball_pos.phi
      when 0..Math::PI : return get_skill("left_strong_kick")
      else return get_skill("rigth_strong_kick")
     end
  end
  
  def checkProgress
    raise "Fallen" if me.on_ground?
  end
end

#in order not to defer the startup cost
Kick.new