require 'high_skills/ruby_high_skill.rb'

class Beam < RubyHighSkill
  
  def initialize
    super
    @run_already = false  
  end
  
  def pickLowSkill
    unless @run_already then
      ComputedValues.set ComputedValue.new("rollbackArms"), 0.0
      current_skill = get_skill "rollback"
      @run_already = true
      return current_skill
     end
    Java::sk.fiit.jim.agent.communication.Communication.instance.addToMessage "(beam -2.0 2.0 0.0)"
     nil
  end
 
  def checkProgress
    #do nothing
  end
end