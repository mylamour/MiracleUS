robocup
=======

Soccer Robot implementations for the Robocup 3D Simulation League
