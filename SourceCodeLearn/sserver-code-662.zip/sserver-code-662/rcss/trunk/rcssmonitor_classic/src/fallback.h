/* -*- Mode: C -*-
 *Header:
 *File: fallback.h
 *Author: Noda Itsuki
 *Date: 1996/02/14
 *EndHeader:
 */

/*
 *Copyright:

    Copyright (C) 1996-2000 Electrotechnical Laboratory. 
    	Itsuki Noda, Yasuo Kuniyoshi and Hitoshi Matsubara.
    Copyright (C) 2000, 2001 RoboCup Soccer Server Maintainance Group.
    	Patrick Riley, Tom Howard, Daniel Polani, Itsuki Noda,
	Mikhail Prokopenko, Jan Wendler 

    This file is a part of SoccerServer.

    This code is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 *EndCopyright:
 */


#include "../config.h"

#define DEFAULT_STATUS_FONT		"fixed"

#define TEAM_L_COLOR			"Gold"
#define TEAM_R_COLOR			"Red"
#define GOALIE_L_COLOR			"Green"
#define GOALIE_R_COLOR			"Purple"
#define NECK_L_COLOR			"Black"
#define NECK_R_COLOR			"Black"
#define GOALIE_NECK_L_COLOR		"Black"
#define GOALIE_NECK_R_COLOR		"Black"
#define DEFAULT_PLAYER_COLOR_H	"Red"
#define DEFAULT_PLAYER_COLOR_T	"Black"
#define DEFAULT_PLAYER_COLOR_S	"White"
#define DEFAULT_PLAYER_FONT		"fixed"
#define DEFAULT_PLAYER_FONT_POS_X	2
#define DEFAULT_PLAYER_FONT_POS_Y	8

#define DEFAULT_FIELD_COLOR		"forestgreen"

#define DEFAULT_MARK_FILE_NAME	"mark.xbm"
#define DEFAULT_FIELD_MARK_COLOR "#32a032"

#define DEFAULT_BALL_FILE_NAME	"ball.xbm"

#define DEFAULT_PANEL_WIDTH				175

#define DEFAULT_GOAL_LABEL_WIDTH		120
#define DEFAULT_GOAL_LABEL_FONT			"fixed"
#define DEFAULT_GOAL_SCORE_WIDTH		40
#define DEFAULT_GOAL_SCORE_FONT			"fixed"
#define DEFAULT_OFFSIDE_LABEL_WIDTH		120
#define DEFAULT_OFFSIDE_LABEL_FONT		"fixed"

#define DEFAULT_DRAW_COLOR				"white"

#define FALLBACK_RESOURCES {\
				"*background:			gray75",\
				"*margin.borderColor:	steelblue",\
				"*object.background:	forestgreen",\
				"*object.foreground:	white",\
				"*Status_T.background:	ivory2",\
				"*Status_M.background:	ivory2",\
				"*Status.borderColor:	ivory4",\
				"*quit.fromHoriz:		start",\
				"*Status.fromVert:		start",\
				"*margin.fromVert:		Status",\
				"*message.fromVert:		margin",\
				"*log.fromVert:			margin",\
				"*log.fromHoriz:		message",\
				"*foulmenu.Box.hSpace:	0",\
				"*foulmenu.Box.vSpace:	0",\
				"*discardmenu1.Box.hSpace:	0",\
				"*discardmenu1.Box.vSpace:	0",\
				"*discardmenu2.Box.hSpace:	0",\
				"*discardmenu2.Box.vSpace:	0",\
				"*margin.translations: \
					<BtnDown>:		FoulMenuPlace() XtMenuPopup(foulmenu) \
									FoulMenuCheck()",\
				"*foulbox.Command.translations: \
					<EnterWindow>:	highlight()	\\n\
					<LeaveWindow>:	reset()		\\n\
					<BtnUp>:		set() notify() unset()",\
				"*foulmenu.translations: \
					<BtnUp>: 		XtMenuPopdown(foulmenu)",\
				"*foulbox.foulpanel3.translations: \
					<LeaveWindow>:	DiscardMenuPlace1()",\
				"*foulbox.foulpanel4.translations: \
					<LeaveWindow>:	DiscardMenuPlace2()",\
				"*discardmenu1.translations: \
					<LeaveWindow>:	PopdownDiscardMenu1()",\
				"*discardbox1.Command.translations: \
					<EnterWindow>:	highlight() \\n\
					<LeaveWindow>:	reset()		\\n\
					<BtnUp>:		set() notify() unset()",\
				"*discardmenu2.translations: \
					<LeaveWindow>:	PopdownDiscardMenu2()",\
				"*discardbox2.Command.translations: \
					<EnterWindow>:	highlight() \\n\
					<LeaveWindow>:	reset()		\\n\
					<BtnUp>:		set() notify() unset()",\
				NULL }
