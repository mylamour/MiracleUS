/* -*- Mode: C++ -*-
 *Header:
 *File: field.C
 *Author: Noda Itsuki
 *Date: 1996/01/28
 *EndHeader:
 */

/*
 *Copyright:

 Copyright (C) 1996-2000 Electrotechnical Laboratory.
 Itsuki Noda, Yasuo Kuniyoshi and Hitoshi Matsubara.
 Copyright (C) 2000-2007 RoboCup Soccer Server Maintainance Group.
 Patrick Riley, Tom Howard, Daniel Polani, Itsuki Noda,
 Mikhail Prokopenko, Jan Wendler

 This file is a part of SoccerServer.

 This code is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 *EndCopyright:
 */


#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "field.h"

#include "param.h"
#include "fallback.h"
#include "types.h"
#include "utility.h"
#include "netif.h"
#include "object.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>

#ifdef HAVE_NETINET_IN_H
#include <netinet/in.h>
#endif

#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Shell.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/AsciiText.h>

#include "mark.RoboCup.grey.xbm"

#define SMON_CONFIG ".rcssmonitor_classic"

extern Stadium Std;
static void Quit(void);
static void Start(void);
static void Update(void);

Widget foulmenu;	/* for Foul Panel Shell */
static void FoulMenuPlace( Widget w, XButtonEvent* );
static void FoulMenuCheck( void );
static void FoulPanelChosen( Widget w, XtPointer );
pos_t foul_pos;
Widget discardmenu1;	/* for Discard Left Team Player Panel Shell */
Widget discardmenu2;	/* for Discard Right Team Player Panel Shell */
static void DiscardMenuPlace1( Widget w, XEvent* );
static void DiscardPanelChosen1( Widget w, XtPointer );
static void PopdownDiscardMenu1( Widget w );
static void DiscardMenuPlace2( Widget w, XEvent* );
static void DiscardPanelChosen2( Widget w, XtPointer );
static void PopdownDiscardMenu2( Widget w );


static XtActionsRec actions[] = {
    {"FoulMenuPlace", 		(XtActionProc)FoulMenuPlace},
    {"FoulMenuCheck",		(XtActionProc)FoulMenuCheck},
    {"DiscardMenuPlace1",	(XtActionProc)DiscardMenuPlace1},
    {"DiscardMenuPlace2",	(XtActionProc)DiscardMenuPlace2},
    {"PopdownDiscardMenu1",	(XtActionProc)PopdownDiscardMenu1},
    {"PopdownDiscardMenu2",	(XtActionProc)PopdownDiscardMenu2}
};

#ifdef X11R5
static Arg Args[16];
static int Argn;
#endif

/*
 *===================================================================
 *Part: Stadium
 *===================================================================
 */
Stadium::Stadium()
{
    plog = true;
    popup = false;
    playtime = -1;
    length_magnify = LENGTH_MAGNIFY;
    board_rows = BOARD_ROWS;
    std::strcpy( color_l, TEAM_L_COLOR );
    std::strcpy( color_r, TEAM_R_COLOR );
    std::strcpy( goalie_color_l, GOALIE_L_COLOR );
    std::strcpy( goalie_color_r, GOALIE_R_COLOR );
    std::strcpy( neck_color_l, NECK_L_COLOR );
    std::strcpy( neck_color_r, NECK_R_COLOR );
    std::strcpy( goalie_neck_color_l, GOALIE_NECK_L_COLOR );
    std::strcpy( goalie_neck_color_r, GOALIE_NECK_R_COLOR );
    std::strcpy( status_font, DEFAULT_STATUS_FONT);
    std::strcpy( glabel_font, DEFAULT_GOAL_LABEL_FONT );
    glabel_width = DEFAULT_GOAL_LABEL_WIDTH;
    std::strcpy( gscore_font, DEFAULT_GOAL_SCORE_FONT );
    gscore_width = DEFAULT_GOAL_SCORE_WIDTH;
    std::strcpy( olabel_font, DEFAULT_OFFSIDE_LABEL_FONT );
    olabel_width = DEFAULT_OFFSIDE_LABEL_WIDTH;
    //std::strcpy( ball_file, DEFAULT_BALL_FILE_NAME );
    std::strcpy( ball_file, "" );
    psize = InDisplaySize(PLAYER_WIDGET_SIZE );
    std::strcpy( pfont, DEFAULT_PLAYER_FONT );
    pfont_x = DEFAULT_PLAYER_FONT_POS_X;
    pfont_y = DEFAULT_PLAYER_FONT_POS_Y;
    eval_flag = false;
    for ( int i = 0; i < MAX_PLAYER * 2; ++i )
    {
        player_status[i] = false;
    }
    redraw = false;
    stamina_max = 4000;
}

Stadium::~Stadium()
{
    std::cerr << "destruct Stadium" << std::endl;
}

void
Stadium::init( int argc, char *argv[] )
{
    Widget top;
    static String fallback_resources[] = FALLBACK_RESOURCES;

    top = XtAppInitialize( &app_context, "Stadium", NULL, 0,
                           &argc, argv, fallback_resources, NULL, 0 );
    getOption( argc, argv );

    view_dir = VIEW_FOR;
    assign( top );
    XtRealizeWidget( top );
    no_resize( top );
    field.draw();
    field.ball.assign();

    if ( ! port.init() )
	  {
        std::cerr << __FILE__ << ": " << __LINE__ << ": Could not initialize port\n";
        exit( 1 );
	  }
    XtAppAddInput( app_context, port.socketfd,
                   (XtPointer)XtInputReadMask, (XtInputCallbackProc)Update, NULL );
}

void
Stadium::readConf( FILE* fp )
{
    option_t opt[] = {
        {"print_log",	(void *)&plog, V_ONOFF},
        {"host",(void *)&(port.host), V_STRING},
        {"port",(void *)&(port.portnum), V_INT},
        {"version",(void *)&(port.version),	V_INT},
        {"length_magnify",(void *)&(length_magnify), V_DOUBLE},
        {"goal_width", (void *)&(field.gwidth),	V_DOUBLE},
        {"log_line", (void *)&board_rows, V_INT},
        {"team_l_color", (void *)&color_l, V_STRING},
        {"team_r_color", (void *)&color_r, V_STRING},
        {"goalie_l_color", (void *)&goalie_color_l,	V_STRING},
        {"goalie_r_color", (void *)&goalie_color_r,	V_STRING},
        {"neck_l_color", (void *)&neck_color_l, V_STRING},
        {"neck_r_color", (void *)&neck_color_r, V_STRING},
        {"goalie_neck_l_color", (void *)&goalie_neck_color_l, V_STRING},
        {"goalie_neck_r_color", (void *)&goalie_neck_color_r, V_STRING},
        {"status_font", (void *)&status_font, V_STRING},
        {"print_mark", (void *)&(field.pmark), V_ONOFF},
        {"mark_file_name", (void *)&(field.mark_file), V_STRING},
        {"ball_file_name", (void *)&(ball_file), V_STRING},
        {"popup_msg", (void *)&popup,	V_ONOFF},
        {"goal_label_font", (void *)&glabel_font,	V_STRING},
        {"goal_label_width", (void *)&glabel_width,	V_INT},
        {"goal_score_font", (void *)&gscore_font, V_STRING},
        {"goal_score_width", (void *)&gscore_width, V_INT},
        {"offside_label_font", (void *)&olabel_font, V_STRING},
        {"offside_label_width",	(void *)&olabel_width, V_INT},
        {"player_widget_size", (void *)&(psize), V_DOUBLE},
        {"player_widget_font", (void *)&(pfont), V_STRING},
        {"uniform_num_pos_x",	(void *)&(pfont_x), V_INT},
        {"uniform_num_pos_y",	(void *)&(pfont_y), V_INT},
        {"eval", (void *)&(eval_flag), V_ONOFF},
        {"redraw_player",	(void *)&(redraw), V_ONOFF},
        {"\0", NULL, 0}
    };


    char buf[MaxMesg];
    char com[256];
    char onoff[16];

    while ( std::fgets( buf,MaxMesg,fp ) != NULL )
    {
				/* ignore remark line */
        if (buf[0] == '#' || buf[0] == '\n')
            continue;

				/* replace from ':' to ' ' */
        char *r = buf;
        while(*r != NULLCHAR)
        {
            if (*r == ':') *r = ' ';
            r++;
        }

        int n = std::sscanf( buf, "%s", com );
        if ( n < 1 )
        {
            std::cerr << "Illegal line : " << buf;
            continue;
        }

        int p = 0;
        for ( p = 0; opt[p].vptr != NULL; ++p )
        {
            if ( std::strcmp( com, opt[p].optname ) )
                continue;

            /* match */
            switch ( opt[p].vsize ) {
            case V_INT:
                n = std::sscanf( buf, "%s %d", com, (int *)opt[p].vptr );
                break;

            case V_DOUBLE:
                n = std::sscanf( buf, "%s %lf", com, (double *)opt[p].vptr );
                break;

            case V_STRING:
                n = std::sscanf( buf, "%s %s", com, (char *)opt[p].vptr );
                break;

            case V_ONOFF:
                n = std::sscanf( buf, "%s %s", com, onoff );
                *((int *)opt[p].vptr) = ( ! strcmp( onoff, "on")
                                          ? true
                                          : false );
                break;
            }

            if ( n > 2 )
                std::cerr << "Illegal line (" << com << ") " << std::endl;

            break;
        }

        if ( opt[p].vptr == NULL )
            std::cerr << "Illegal line (" << com << ") " << std::endl;
    }
}


void
Stadium::getOption( int argc, char **argv )
{
    option_t opt[] = {
        {"print_log", (void *)&plog, V_ONOFF},
        {"host", (void *)&(port.host), V_STRING},
        {"port", (void *)&(port.portnum), V_INT},
        {"version", (void *)&(port.version), V_INT},
        {"length_magnify", (void *)&(length_magnify), V_DOUBLE},
        {"goal_width", (void *)&(field.gwidth), V_DOUBLE},
        {"log_line", (void *)&board_rows, V_INT},
        {"team_l_color", (void *)&color_l, V_STRING},
        {"team_r_color", (void *)&color_r, V_STRING},
        {"goalie_l_color", (void *)&goalie_color_l, V_STRING},
        {"goalie_r_color", (void *)&goalie_color_r, V_STRING},
        {"neck_l_color", (void *)&neck_color_l, V_STRING},
        {"neck_r_color", (void *)&neck_color_r, V_STRING},
        {"goalie_neck_l_color", (void *)&goalie_neck_color_l, V_STRING},
        {"goalie_neck_r_color", (void *)&goalie_neck_color_r, V_STRING},
        {"status_font",	(void *)&status_font, V_STRING},
        {"print_mark", (void *)&(field.pmark), V_ONOFF},
        {"mark_file_name", (void *)&(field.mark_file),	V_STRING},
        {"ball_file_name", (void *)&(ball_file), V_STRING},
        {"popup_msg", (void *)&popup, V_ONOFF},
        {"goal_label_font", (void *)&glabel_font, V_STRING},
        {"goal_label_width", (void *)&glabel_width, V_INT},
        {"goal_score_font", (void *)&gscore_font, V_STRING},
        {"goal_score_width", (void *)&gscore_width, V_INT},
        {"offside_label_font", (void *)&olabel_font, V_STRING},
        {"offside_label_width", (void *)&olabel_width, V_INT},
        {"player_widget_size", (void *)&(psize), V_DOUBLE},
        {"player_widget_font", (void *)&(pfont), V_STRING},
        {"uniform_num_pos_x", (void *)&(pfont_x), V_INT},
        {"uniform_num_pos_y", (void *)&(pfont_y), V_INT},
        {"eval", (void *)&(eval_flag), V_ONOFF},
        {"redraw_player", (void *)&(redraw), V_ONOFF},
        {"\0", NULL, 0}
    };

    char buf[MaxMesg];
    char onoff[16];
    FILE *fp;
    bool file_specified = false;

    /* skip command name */
    argv++; argc--;

    /* first, search option '-file' */
    for( int i = 0; i < argc; ++i )
    {
        if ( ! std::strncmp( *(argv + i), "-file" , std::strlen( "-file" ) ) )
        {
            file_specified = true;
            if ( i == argc - 1 )
            {
                std::cerr << "can't find file name" << std::endl;
                break;
            }

            if ( ( fp = std::fopen( *(argv+i+1), "r") ) == NULL )
            {
                std::cerr << "can't open config file " << *(argv+i+1) << std::endl;
                break;
            }

            readConf( fp );
            std::fclose( fp );
            break;
        }
    }

    if ( file_specified == false )
	  {
        std::snprintf( buf, sizeof( buf ),
                       "%s/%s",
                       getenv ( "HOME" ), SMON_CONFIG );
        if ( ( fp = std::fopen( buf, "r") ) == NULL )
	      {
            if ( ( fp = std::fopen( buf, "w") ) == NULL )
            {
                std::cerr << "can't open config file, " << buf << std::endl;
            }
            else
            {
                std::fprintf ( fp, "# %s configuration file\n\n", SMON_CONFIG );
                std::fclose ( fp );
                std::cout << "created monitor config file, " << buf << std::endl;
            }
	      }
        else
	      {
            readConf( fp );
            std::fclose( fp );
	      }
	  }

    /* next, analyze command line option */
    while ( argc )
    {
        if ( ! std::strncmp( *argv, "-file", std::strlen( "-file" ) ) )
        {
            argv += 2;
            argc -= 2;
            continue;
        }

        int p = 0;
        for ( p = 0; opt[p].vptr != NULL; ++p )
        {
            if ( std::strcmp( *argv + 1, opt[p].optname ) )
                continue;

            /* match */
            argv++;
            argc--;

            switch(opt[p].vsize) {
            case V_INT:
                *((int *)opt[p].vptr) = std::atoi( *argv );
                break;

            case V_DOUBLE:
                *((double *)opt[p].vptr) = std::atof( *argv );
                break;

            case V_STRING:
                std::strcpy( (char *)opt[p].vptr, *argv );
                break;

            case V_ONOFF:
                std::strcpy( onoff, *argv );
                *((int *)opt[p].vptr) = ( ! std::strcmp(onoff, "on")
                                          ? true
                                          : false );
                break;
            }

            break;
        }

        if ( opt[p].vptr == NULL )
            std::cerr << "Unrecognized Opion : " << *argv << std::endl;

        argv++;
        argc--;
    }

    field.length_magnify = length_magnify;
}

void
Stadium::MainLoop()
{
    XtAppMainLoop(app_context);
}

void
Stadium::sendfoulpos( short pos_x, short pos_y, short side )
{
    char tmp[64];
    short x, y;

    x = (short)(view_dir * (pos_x/length_magnify - PITCH_MARGIN \
                            - PITCH_LENGTH/2.0) * SHOWINFO_SCALE);
    y = (short)(view_dir * (pos_y/length_magnify - PITCH_MARGIN \
                            - PITCH_WIDTH/2.0) * SHOWINFO_SCALE);

    std::snprintf( tmp, sizeof( tmp ), "(dispfoul %d %d %d)", x, y, side );

    Std.port.send_info( tmp );
}

void
Stadium::senddiscard( short side, short unum )
{
    char tmp[64];

    std::snprintf( tmp, sizeof( tmp ), "(dispdiscard %d %d)", side, unum );

    Std.port.send_info( tmp );
}

void
Stadium::assign(Widget parent)
{
    Display *display;
    XColor def, closest;
    Widget b;
    XFontStruct *font_s, *font_gl, *font_gs, *font_ol;
    int i;
    char buf1[32];
    char buf2[32];

    Dimension width1, width2;
#ifdef X11R5
    main = XtCreateManagedWidget("main",formWidgetClass,
                                 parent,
                                 Args, 0);

    mySetArg_1st(XtNlabel, "Kick Off");
    b = XtCreateManagedWidget("start",commandWidgetClass,
                              main,
                              Args, Argn);
    mySetArg_1st(XtNwidth, &width1);
    XtGetValues(b, Args, Argn);
    XtAddCallback(b, XtNcallback, (XtCallbackProc)Start, (XtPointer)this);

    mySetArg_1st(XtNlabel, "Quit");
    b = XtCreateManagedWidget("quit",commandWidgetClass,
                              main,
                              Args, Argn);
    mySetArg_1st(XtNwidth, &width2);
    XtGetValues(b, Args, Argn);
    mySetArg_1st(XtNhorizDistance,
                 InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN)-width1-width2+2);
    XtSetValues(b, Args, Argn);
    XtAddCallback(b, XtNcallback, (XtCallbackProc)Quit, (XtPointer)this);
#else
    main = XtVaCreateManagedWidget("main",formWidgetClass,
                                   parent,
                                   NULL);

    b = XtVaCreateManagedWidget("start",commandWidgetClass,
                                main,
                                XtNlabel, "Kick Off",
                                NULL);
    XtVaGetValues(b, XtNwidth, &width1, NULL);
    XtAddCallback(b, XtNcallback, (XtCallbackProc)Start, (XtPointer)this);

    b = XtVaCreateManagedWidget("quit",commandWidgetClass,
                                main,
                                XtNlabel, "Quit",
                                NULL);
    XtVaGetValues(b, XtNwidth, &width2, NULL);
    XtVaSetValues(b,
                  XtNhorizDistance,
                  InPitchSize(PITCH_LENGTH + 2*PITCH_MARGIN)-width1-width2+2,
                  NULL);
    XtAddCallback(b, XtNcallback, (XtCallbackProc)Quit, (XtPointer)this);
#endif

    /* status line */
    Widget stf;

#ifdef X11R5
    mySetArg_1st(XtNwidth, InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN));
    mySetArg(XtNborderWidth, 2);
    mySetArg(XtNdefaultDistance, 0);
    stf = XtCreateManagedWidget("Status",formWidgetClass,
                                main, Args, Argn);
#else
    stf = XtVaCreateManagedWidget("Status",formWidgetClass,
                                  main,
                                  XtNwidth, InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN),
                                  XtNborderWidth, 2,
                                  XtNdefaultDistance, 0,
                                  NULL);
#endif

    display = XtDisplay(stf);

    if ((font_s = XLoadQueryFont(display, status_font)) == NULL)
    {
        std::printf("Can't find status line font!\nUse fixed font.\n");
        std::strcpy(status_font, DEFAULT_STATUS_FONT);
        font_s = XLoadQueryFont(display, status_font);
    }

    if (!XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                          goalie_color_l, &def, &closest))
    {
        std::printf("Can't find Team Left Goalie color!\nUse default color.\n");
        std::strcpy(color_l, GOALIE_L_COLOR);
    }
    if (!XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                          color_l, &def, &closest))
    {
        std::printf("Can't find Team Left color!\nUse default color.\n");
        std::strcpy(color_l, TEAM_L_COLOR);
        XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                         color_l, &def, &closest);
    }

#ifdef X11R5
    mySetArg_1st(XtNlabel, "Team_L");
    mySetArg(XtNwidth, InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) / 4 + 1);
    mySetArg(XtNjustify, XtJustifyLeft);
    mySetArg(XtNborderWidth, 0);
    mySetArg(XtNbackground, def.pixel);
    mySetArg(XtNhorizDistance, 0);
    mySetArg(XtNfont, font_s);
    status_l = XtCreateManagedWidget("Status_L",labelWidgetClass,
                                     stf, Args, Argn );

    mySetArg_1st(XtNlabel, "Play Mode");
    mySetArg(XtNwidth, InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) / 4 + 1);
    mySetArg(XtNjustify, XtJustifyRight);
    mySetArg(XtNborderWidth, 0);
    mySetArg(XtNhorizDistance,
             InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) / 4 + 1);
    mySetArg(XtNfont, font_s);
    status_m = XtCreateManagedWidget("Status_M",labelWidgetClass,
                                     stf, Args, Argn );

    mySetArg_1st(XtNlabel, "Time");
    mySetArg(XtNwidth, InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) / 4);
    mySetArg(XtNjustify, XtJustifyLeft);
    mySetArg(XtNborderWidth, 0);
    mySetArg(XtNhorizDistance,
             InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) / 2 + 1);
    mySetArg(XtNfont, font_s);
    status_t = XtCreateManagedWidget("Status_T",labelWidgetClass,
                                     stf, Args, Argn );
#else
    status_l = XtVaCreateManagedWidget("Status_L",labelWidgetClass,
                                       stf,
                                       XtNlabel, "Team_L",
                                       XtNwidth, InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) / 4 + 1,
                                       XtNjustify, XtJustifyLeft,
                                       XtNborderWidth, 0,
                                       XtNbackground, def.pixel,
                                       XtNhorizDistance, 0,
                                       XtNfont, font_s,
                                       NULL );

    status_m = XtVaCreateManagedWidget("Status_M",labelWidgetClass,
                                       stf,
                                       XtNlabel, "Play Mode",
                                       XtNwidth, InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) / 4 + 1,
                                       XtNjustify, XtJustifyRight,
                                       XtNborderWidth, 0,
                                       XtNhorizDistance,
                                       InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) / 4 + 1,
                                       XtNfont, font_s,
                                       NULL );

    status_t = XtVaCreateManagedWidget("Status_T",labelWidgetClass,
                                       stf,
                                       XtNlabel, "Time",
                                       XtNwidth, InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) / 4,
                                       XtNjustify, XtJustifyLeft,
                                       XtNborderWidth, 0,
                                       XtNhorizDistance,
                                       InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) / 2 + 1,
                                       XtNfont, font_s,
                                       NULL );
#endif

    if (!XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                          goalie_color_r, &def, &closest))
    {
        std::printf("Can't find Team Right Goalie color!\nUse default color.\n");
        std::strcpy(color_r, GOALIE_R_COLOR);
    }
    if (!XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                          color_r, &def, &closest))
    {
        std::printf("Can't find Team Right color!\nUse default color.\n");
        std::strcpy(color_r, TEAM_R_COLOR);
        XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                         color_r, &def, &closest);
    }

#ifdef X11R5
    mySetArg_1st(XtNlabel, "Team_R");
    mySetArg(XtNwidth, InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) / 4 + 1);
    mySetArg(XtNjustify, XtJustifyRight);
    mySetArg(XtNborderWidth, 0);
    mySetArg(XtNbackground, def.pixel);
    mySetArg(XtNhorizDistance,
             InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) * 3 / 4 + 2);
    mySetArg(XtNfont, font_s);
    status_r = XtCreateManagedWidget("Status_R",labelWidgetClass,
                                     stf, Args, Argn );
#else
    status_r = XtVaCreateManagedWidget("Status_R",labelWidgetClass,
                                       stf,
                                       XtNlabel, "Team_R",
                                       XtNwidth, InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) / 4 + 1,
                                       XtNjustify, XtJustifyRight,
                                       XtNborderWidth, 0,
                                       XtNbackground, def.pixel,
                                       XtNhorizDistance,
                                       InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) * 3 / 4 + 2,
                                       XtNfont, font_s,
                                       NULL );
#endif

    field.assign(main);

    /* Goal Print Setting */
    if ( popup )
    {
        goal = XtCreatePopupShell("goal",
                                  overrideShellWidgetClass, field.margin,
                                  NULL, 0);
        goalform = XtCreateManagedWidget("goalform",
                                         formWidgetClass, goal,
                                         NULL, 0);

        offside = XtCreatePopupShell("offside",
                                     overrideShellWidgetClass, field.margin,
                                     NULL, 0);
        offsideform = XtCreateManagedWidget("offsideform",
                                            formWidgetClass, offside,
                                            NULL, 0);

        if ((font_gl = XLoadQueryFont(display, glabel_font)) == NULL) {
            std::printf("Can't find PopUp goal label font!\nUse fixed font.\n");
            std::strcpy(glabel_font, DEFAULT_GOAL_LABEL_FONT);
            font_gl = XLoadQueryFont(display, glabel_font);
        }
        if ((font_gs = XLoadQueryFont(display, gscore_font)) == NULL) {
            std::printf("Can't find PopUp goal score font!\nUse fixed font.\n");
            std::strcpy(gscore_font, DEFAULT_GOAL_SCORE_FONT);
            font_gs = XLoadQueryFont(display, gscore_font);
        }
        if ((font_ol = XLoadQueryFont(display, olabel_font)) == NULL) {
            std::printf("Can't find PopUp offside label font!\nUse fixed font.\n");
            std::strcpy(olabel_font, DEFAULT_GOAL_LABEL_FONT);
            font_ol = XLoadQueryFont(display, olabel_font);
        }

#ifdef X11R5
        mySetArg_1st(XtNborderWidth, 0);
        mySetArg(XtNwidth, glabel_width);
        mySetArg(XtNlabel, "GOAL!!");
        mySetArg(XtNfont, font_gl);
        goallabel = XtCreateManagedWidget("goallabel",
                                          labelWidgetClass, goalform, Args, Argn );
        mySetArg_1st(XtNborderWidth, 0);
        mySetArg(XtNwidth, olabel_width);
        mySetArg(XtNlabel, "Offside!");
        mySetArg(XtNfont, font_ol);
        offsidelabel = XtCreateManagedWidget("offsidelabel",
                                             labelWidgetClass, offsideform, Args, Argn );
#else
        goallabel = XtVaCreateManagedWidget("goallabel",
                                            labelWidgetClass, goalform,
                                            XtNwidth, glabel_width,
                                            XtNborderWidth, 0,
                                            XtNlabel, "GOAL!!",
                                            XtNfont, font_gl,
                                            NULL);
        offsidelabel = XtVaCreateManagedWidget("offsidelabel",
                                               labelWidgetClass, offsideform,
                                               XtNwidth, olabel_width,
                                               XtNborderWidth, 0,
                                               XtNlabel, "Offside!",
                                               XtNfont, font_ol,
                                               NULL);
#endif
        XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                         color_l, &def, &closest);
#ifdef X11R5
        mySetArg_1st(XtNlabel, "0");
        mySetArg(XtNjustify, XtJustifyRight);
        mySetArg(XtNwidth, gscore_width);
        mySetArg(XtNborderWidth, 0);
        mySetArg(XtNbackground, def.pixel);
        mySetArg(XtNfromVert, goallabel);
        mySetArg(XtNvertDistance, 0);
        mySetArg(XtNfromHoriz, goallabel);
        mySetArg(XtNhorizDistance, -glabel_width);
        mySetArg(XtNfont, font_gs);
        goalscore_l = XtCreateManagedWidget("goalscore_l",
                                            labelWidgetClass, goalform, Args, Argn );
#else
        goalscore_l = XtVaCreateManagedWidget("goalscore_l",
                                              labelWidgetClass, goalform,
                                              XtNlabel, "0",
                                              XtNjustify, XtJustifyRight,
                                              XtNwidth, gscore_width,
                                              XtNborderWidth, 0,
                                              XtNbackground, def.pixel,
                                              XtNfromVert, goallabel,
                                              XtNvertDistance, 0,
                                              XtNfromHoriz, goallabel,
                                              XtNhorizDistance, -glabel_width,
                                              XtNfont, font_gs,
                                              NULL);
#endif

#ifdef X11R5
        mySetArg_1st(XtNlabel, "-");
        mySetArg(XtNwidth, (glabel_width - gscore_width * 2));
        mySetArg(XtNborderWidth, 0);
        mySetArg(XtNfromVert, goallabel);
        mySetArg(XtNvertDistance, 0);
        mySetArg(XtNfromHoriz, goalscore_l);
        mySetArg(XtNhorizDistance, 0);
        mySetArg(XtNfont, font_gs);
        goalscore_c = XtCreateManagedWidget("goalscore_c",
                                            labelWidgetClass, goalform, Args, Argn );
#else
        goalscore_c = XtVaCreateManagedWidget("goalscore_c",
                                              labelWidgetClass, goalform,
                                              XtNlabel, "-",
                                              XtNwidth,(glabel_width -
                                                        gscore_width * 2),
                                              XtNborderWidth, 0,
                                              XtNfromVert, goallabel,
                                              XtNvertDistance, 0,
                                              XtNfromHoriz, goalscore_l,
                                              XtNhorizDistance, 0,
                                              XtNfont, font_gs,
                                              NULL);
#endif
        XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                         color_r, &def, &closest);
#ifdef X11R5
        mySetArg_1st(XtNlabel, "0");
        mySetArg(XtNjustify, XtJustifyRight);
        mySetArg(XtNwidth, gscore_width);
        mySetArg(XtNborderWidth, 0);
        mySetArg(XtNbackground, def.pixel);
        mySetArg(XtNfromVert, goallabel);
        mySetArg(XtNvertDistance, 0);
        mySetArg(XtNfromHoriz, goalscore_c);
        mySetArg(XtNhorizDistance, 0);
        mySetArg(XtNfont, font_gs);
        goalscore_r = XtCreateManagedWidget("goalscore_r",
                                            labelWidgetClass, goalform, Args, Argn );
#else
        goalscore_r = XtVaCreateManagedWidget("goalscore_r",
                                              labelWidgetClass, goalform,
                                              XtNlabel, "0",
                                              XtNwidth, gscore_width,
                                              XtNjustify, XtJustifyRight,
                                              XtNborderWidth, 0,
                                              XtNbackground, def.pixel,
                                              XtNfromVert, goallabel,
                                              XtNvertDistance, 0,
                                              XtNfromHoriz, goalscore_c,
                                              XtNhorizDistance, 0,
                                              XtNfont, font_gs,
                                              NULL);
#endif
    }

    /* Foul Menu Setting */
    foulmenu = XtCreatePopupShell("foulmenu",
                                  overrideShellWidgetClass, field.margin,
                                  NULL, 0);

    foulbox = XtCreateManagedWidget("foulbox",
                                    boxWidgetClass, foulmenu,
                                    NULL, 0);
#ifdef	X11R5
    mySetArg_1st(XtNlabel, "Discard Team_L Player ==>");
    foullabel = XtCreateManagedWidget("foullabel",
                                      labelWidgetClass, foulbox,
                                      Args, Argn);
    mySetArg_1st(XtNwidth, &panel_width);
    XtGetValues(foullabel, Args, Argn);
    mySetArg_1st(XtNwidth, panel_width);
    mySetArg(XtNlabel, "Which ?");
    XtSetValues(foullabel, Args, Argn);
#else
    foullabel = XtVaCreateManagedWidget("foullabel",
                                        labelWidgetClass, foulbox,
                                        XtNlabel, "Discard Team_L Player ==>",
                                        NULL);
    XtVaGetValues(foullabel, XtNwidth, &panel_width, NULL);
    XtVaSetValues(foullabel,
                  XtNlabel, "Which ?",
                  XtNwidth, panel_width,
                  NULL);
#endif

    XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                     color_l, &def, &closest);
#ifdef	X11R5
    mySetArg_1st(XtNlabel, "Free Kick by Team_L");
    mySetArg(XtNbackground, def.pixel);
    mySetArg(XtNwidth, panel_width);
    foulpanel[0] = XtCreateManagedWidget("foulpanel0",
                                         commandWidgetClass, foulbox, Args, Argn);
#else
    foulpanel[0] = XtVaCreateManagedWidget("foulpanel0",
                                           commandWidgetClass, foulbox,
                                           XtNlabel, "Free Kick by Team_L",
                                           XtNbackground, def.pixel,
                                           XtNwidth, panel_width,
                                           NULL);
#endif
    XtAddCallback(foulpanel[0], XtNcallback,
                  (XtCallbackProc)FoulPanelChosen,(XtPointer)LEFT);

    XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                     color_r, &def, &closest);
#ifdef	X11R5
    mySetArg_1st(XtNlabel, "Free Kick by Team_R");
    mySetArg(XtNbackground, def.pixel);
    mySetArg(XtNwidth, panel_width);
    foulpanel[1] = XtCreateManagedWidget("foulpanel1",
                                         commandWidgetClass, foulbox,
                                         Args, Argn);
#else
    foulpanel[1] = XtVaCreateManagedWidget("foulpanel1",
                                           commandWidgetClass, foulbox,
                                           XtNlabel, "Free Kick by Team_R",
                                           XtNbackground, def.pixel,
                                           XtNwidth, panel_width,
                                           NULL);
#endif
    XtAddCallback(foulpanel[1], XtNcallback,
                  (XtCallbackProc)FoulPanelChosen,(XtPointer)RIGHT);

    XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                     "Bisque", &def, &closest);
#ifdef	X11R5
    mySetArg_1st(XtNlabel, "Drop Ball");
    mySetArg(XtNbackground, def.pixel);
    mySetArg(XtNwidth, panel_width);
    foulpanel[2] = XtCreateManagedWidget("foulpanel2",
                                         commandWidgetClass, foulbox,
                                         Args, Argn);
#else
    foulpanel[2] = XtVaCreateManagedWidget("foulpanel2",
                                           commandWidgetClass, foulbox,
                                           XtNlabel, "Drop Ball",
                                           XtNbackground, def.pixel,
                                           XtNwidth, panel_width,
                                           NULL);
#endif
    XtAddCallback(foulpanel[2], XtNcallback,
                  (XtCallbackProc)FoulPanelChosen,(XtPointer)NEUTRAL);

    if ( eval_flag )
    {
        XAllocNamedColor( display,
                          DefaultColormap( display, DefaultScreen(display) ),
                          color_l, &def, &closest );
#ifdef	X11R5
        mySetArg_1st(XtNlabel, "Discard Team_L Player ==>");
        mySetArg(XtNbackground, def.pixel);
        mySetArg(XtNwidth, panel_width);
        foulpanel[3] = XtCreateManagedWidget("foulpanel3",
                                             commandWidgetClass, foulbox,
                                             Args, Argn);
#else
        foulpanel[3] = XtVaCreateManagedWidget("foulpanel3",
                                               commandWidgetClass, foulbox,
                                               XtNlabel, "Discard Team_L Player ==>",
                                               XtNbackground, def.pixel,
                                               XtNwidth, panel_width,
                                               NULL);
#endif

        discardmenu1 = XtCreatePopupShell("discardmenu1",
                                          overrideShellWidgetClass, field.margin,
                                          NULL, 0);

        discardbox1 = XtCreateManagedWidget("discardbox1",
                                            boxWidgetClass, discardmenu1,
                                            NULL, 0);

        for (i = 0; i < MAX_PLAYER; i++)
        {
            std::snprintf(buf1, sizeof( buf1 ), "discardpanel1%d", i);
            std::snprintf(buf2, sizeof( buf2 ), "%2d: None", i+1);
#ifdef	X11R5
            mySetArg_1st(XtNlabel, buf2);
            mySetArg(XtNbackground, def.pixel);
            mySetArg(XtNwidth, panel_width/2);
            mySetArg(XtNjustify, XtJustifyLeft);

            discardpanel1[i] = XtCreateManagedWidget(buf1,
                                                     commandWidgetClass, discardbox1,
                                                     Args, Argn);
#else
            discardpanel1[i] = XtVaCreateManagedWidget(buf1,
                                                       commandWidgetClass, discardbox1,
                                                       XtNlabel, buf2,
                                                       XtNbackground, def.pixel,
                                                       XtNwidth, panel_width/2,
                                                       XtNjustify, XtJustifyLeft,
                                                       NULL);
#endif
            XtAddCallback(discardpanel1[i], XtNcallback,
                          (XtCallbackProc)DiscardPanelChosen1, (XtPointer)i);
        }

        XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                         color_r, &def, &closest);
#ifdef	X11R5
        mySetArg_1st(XtNlabel, "Discard Team_R Player ==>");
        mySetArg(XtNbackground, def.pixel);
        mySetArg(XtNwidth, panel_width);
        foulpanel[4] = XtCreateManagedWidget("foulpanel4",
                                             commandWidgetClass, foulbox,
                                             Args, Argn);
#else
        foulpanel[4] = XtVaCreateManagedWidget("foulpanel4",
                                               commandWidgetClass, foulbox,
                                               XtNlabel, "Discard Team_R Player ==>",
                                               XtNbackground, def.pixel,
                                               XtNwidth, panel_width,
                                               NULL);
#endif

        discardmenu2 = XtCreatePopupShell("discardmenu2",
                                          overrideShellWidgetClass, field.margin,
                                          NULL, 0);

        discardbox2 = XtCreateManagedWidget("discardbox2",
                                            boxWidgetClass, discardmenu2,
                                            NULL, 0);

        for (i = 0; i < MAX_PLAYER; i++) {
            std::snprintf(buf1, sizeof( buf1 ), "discardpanel2%d", i);
            std::snprintf(buf2, sizeof( buf2 ), "%2d: None", i+1);
#ifdef	X11R5
            mySetArg_1st(XtNlabel, buf2);
            mySetArg(XtNbackground, def.pixel);
            mySetArg(XtNwidth, panel_width/2);
            mySetArg(XtNjustify, XtJustifyLeft);
            discardpanel2[i] = XtCreateManagedWidget(buf1,
                                                     commandWidgetClass, discardbox2,
                                                     Args, Argn);
#else
            discardpanel2[i] = XtVaCreateManagedWidget(buf1,
                                                       commandWidgetClass, discardbox2,
                                                       XtNlabel, buf2,
                                                       XtNbackground, def.pixel,
                                                       XtNwidth, panel_width/2,
                                                       XtNjustify, XtJustifyLeft,
                                                       NULL);
#endif
            XtAddCallback(discardpanel2[i], XtNcallback,
                          (XtCallbackProc)DiscardPanelChosen2, (XtPointer)i);
        }
    }

    /* Message & Log Board */
    if ( plog )
    {
        int i;
        Dimension width;
        XawTextBlock tb;
        XawTextPosition pos;
        char initstr[64];
        for (i = 0; i < board_rows - 1; i++)
            initstr[i] = '\n';
        initstr[i] = NULLCHAR;
        tb.firstPos = 0;
        tb.length = std::strlen(initstr);
        tb.ptr = initstr;
        tb.format = FMT8BIT;

#ifdef X11R5
        mySetArg_1st(XtNwidth, &width);
        XtGetValues(field.margin, Args, Argn);
#else
        XtVaGetValues(field.margin,
                      XtNwidth, &width,
                      NULL);
#endif
        width = width / 2 - 3;

#ifdef X11R5
        mySetArg_1st(XtNwidth, width);
        mySetArg(XtNheight, board_rows * 14);
        mySetArg(XtNeditType, XawtextEdit);
        mySetArg(XtNborderWidth, 2);
        Msg_board = XtCreateManagedWidget("message", asciiTextWidgetClass,
                                          main, Args, Argn);
#else
        Msg_board = XtVaCreateManagedWidget("message", asciiTextWidgetClass,
                                            main,
                                            XtNwidth, width,
                                            XtNheight, board_rows * 14,
                                            XtNeditType, XawtextEdit,
                                            XtNborderWidth, 2,
                                            NULL);
#endif
        pos = XawTextTopPosition(Msg_board);
        XawTextReplace(Msg_board,pos,pos,&tb);
        XawTextSetInsertionPoint(Msg_board,pos+tb.length);

#ifdef X11R5
        mySetArg_1st(XtNwidth, width - 1);
        mySetArg(XtNheight, board_rows * 14);
        mySetArg(XtNeditType, XawtextEdit);
        mySetArg(XtNborderWidth, 2);
        Log_board = XtCreateManagedWidget("log", asciiTextWidgetClass,
                                          main, Args, Argn);
#else
        Log_board = XtVaCreateManagedWidget("log", asciiTextWidgetClass,
                                            main,
                                            XtNwidth, width - 1,
                                            XtNheight, board_rows * 14,
                                            XtNeditType, XawtextEdit,
                                            XtNborderWidth, 2,
                                            NULL);
#endif
        pos = XawTextTopPosition(Log_board);
        XawTextReplace(Log_board,pos,pos,&tb);
        XawTextSetInsertionPoint(Log_board,pos+tb.length);
    }

    XtAppAddActions(app_context, actions, XtNumber(actions));
}

void
Stadium::display_score( Side side, Name name, char score )
{
    static char buf[MaxStringSize];
    static char buf2[MaxStringSize];
    static char buf3[MaxStringSize];
    char *sc;

    sc = (side == LEFT) ? &(field.score_l) : &(field.score_r);

    if (*sc != score && strlen(name) != 0) {
        *sc = score;

        if ( score == 'x' )
        {
            std::snprintf(buf, sizeof( buf ), "%s",name);
            std::snprintf(buf2, sizeof( buf2 ), "Free Kick by %s",name);
        } else {
            std::snprintf(buf, sizeof( buf ), "%s:%2d",name,score);
            std::snprintf(buf2, sizeof( buf2 ), "Free Kick by %s",name);
            std::snprintf(buf3, sizeof( buf3 ), "%d",score);
        }
#ifdef X11R5
        mySetArg_1st(XtNlabel, buf);
        XtSetValues((side == LEFT) ? status_l : status_r,
                    Args, Argn);

        mySetArg_1st(XtNlabel, buf2);
        mySetArg(XtNwidth, panel_width);
        XtSetValues((side == LEFT) ? foulpanel[0] : foulpanel[1],
                    Args, Argn);
        if (popup) {
            mySetArg_1st(XtNlabel, buf3);
            mySetArg(XtNwidth, gscore_width);
            XtSetValues((side == LEFT) ? goalscore_l : goalscore_r,
                        Args, Argn);
        }
#else
        XtVaSetValues((side == LEFT) ? status_l : status_r,
                      XtNlabel,buf,
                      NULL);
        XtVaSetValues((side == LEFT) ? foulpanel[0] : foulpanel[1],
                      XtNlabel,buf2,
                      XtNwidth,panel_width,
                      NULL);
        if (popup) {
            XtVaSetValues((side == LEFT) ? goalscore_l : goalscore_r,
                          XtNlabel,buf3,
                          XtNwidth,gscore_width,
                          NULL);
        }
#endif
    }
}

void
Stadium::display_time( int time )
{
    static char buf[MaxStringSize];

    if ( playtime != time )
    {
        std::snprintf( buf, sizeof( buf ), "%8d", time );
#ifdef X11R5
        mySetArg_1st(XtNlabel, buf);
        XtSetValues(status_t, Args, Argn);
#else
        XtVaSetValues(status_t,
                      XtNlabel, buf,
                      NULL);
#endif
        playtime = time;
    }
}

void
Stadium::display_play_mode( PlayMode pm )
{
    static char *PlayModeString[] = PLAYMODE_STRINGS;

    if ( playmode != pm )
    {
#ifdef X11R5
        mySetArg_1st(XtNlabel, PlayModeString[pm]);
        XtSetValues(status_m, Args, Argn);
#else
        XtVaSetValues(status_m,
                      XtNlabel,PlayModeString[pm],
                      NULL);
#endif
        if ( popup )
        {
            Position	x, y;
            Dimension	width, height1, height2, pw_width, pw_height;
            if ( pm == PM_AfterGoal_Left || pm == PM_AfterGoal_Right )
            {
#ifdef X11R5
                mySetArg_1st(XtNwidth, &pw_width);
                mySetArg(XtNheight, &pw_height);
                XtGetValues(field.margin, Args, Argn);
                mySetArg_1st(XtNwidth, &width);
                mySetArg(XtNheight, &height1);
                XtGetValues(goallabel, Args, Argn);
                mySetArg_1st(XtNheight, &height2);
                XtGetValues(goalscore_l, Args, Argn);
                XtTranslateCoords(field.margin,
                                  (Position)((pw_width-width)/2 - 4),
                                  (Position)((pw_height-height1-height2)/2 - 4),
                                  &x, &y);
                mySetArg_1st(XtNx, x);
                mySetArg(XtNy, y);
                XtSetValues(goal, Args, Argn);
#else
                XtVaGetValues(field.margin,
                              XtNwidth, &pw_width,
                              XtNheight, &pw_height,
                              NULL);
                XtVaGetValues(goallabel,
                              XtNwidth, &width,
                              XtNheight, &height1,
                              NULL);
                XtVaGetValues(goalscore_l,
                              XtNheight, &height2,
                              NULL);
                XtTranslateCoords(field.margin,
                                  (Position)((pw_width - width)/2 - 4),
                                  (Position)((pw_height-height1-height2)/2 - 4),
                                  &x, &y);
                XtVaSetValues(goal,
                              XtNx, x,
                              XtNy, y,
                              NULL);
#endif
                XtPopup(goal, XtGrabNone);
            }
            else if ( pm == PM_OffSide_Left || pm == PM_OffSide_Right )
            {
#ifdef X11R5
                mySetArg_1st(XtNwidth, &pw_width);
                mySetArg(XtNheight, &pw_height);
                XtGetValues(field.margin, Args, Argn);
                mySetArg_1st(XtNwidth, &width);
                mySetArg(XtNheight, &height1);
                XtGetValues(offsidelabel, Args, Argn);
                XtTranslateCoords(field.margin,
                                  (Position)((pw_width-width)/2 - 4),
                                  (Position)((pw_height-height1)/2 - 4),
                                  &x, &y);
                mySetArg_1st(XtNx, x);
                mySetArg(XtNy, y);
                XtSetValues(offside, Args, Argn);
#else
                XtVaGetValues(field.margin,
                              XtNwidth, &pw_width,
                              XtNheight, &pw_height,
                              NULL);
                XtVaGetValues(offsidelabel,
                              XtNwidth, &width,
                              XtNheight, &height1,
                              NULL);
                XtTranslateCoords(field.margin,
                                  (Position)((pw_width - width)/2 - 4),
                                  (Position)((pw_height-height1)/2 - 4),
                                  &x, &y);
                XtVaSetValues(offside,
                              XtNx, x,
                              XtNy, y,
                              NULL);
#endif
                XtPopup(offside, XtGrabNone);
            }
            else if ( pm == PM_KickOff_Left || pm == PM_KickOff_Right )
                XtPopdown(goal);
            else if ( pm == PM_FreeKick_Left || pm == PM_FreeKick_Right )
                XtPopdown(offside);
        }
        playmode = pm;
    }
}

void
Stadium::write_message( Widget board, char *nmsg )
{
    /* if 'print_log' is on, then display message on Msg_board */
    if ( plog )
    {
        XawTextBlock tb;
        XawTextPosition pos, pos2, pos3;

        pos = XawTextGetInsertionPoint(board);
        pos2 = XawTextTopPosition(board);
        XawTextSetInsertionPoint(board, pos2);

        tb.firstPos = 0;
        tb.length = 1;
        tb.ptr = "\n";
        tb.format = FMT8BIT;
        pos3 = XawTextSearch(board,XawsdRight,&tb);

        tb.length = 0;
        tb.ptr = NULL;
        XawTextReplace(board,pos2,pos3+1, &tb);

        tb.length = strlen(nmsg);
        tb.ptr = nmsg;
        XawTextReplace(board, pos, pos, &tb);
        XawTextSetInsertionPoint(board, pos + tb.length);
    }
}

void Stadium::no_resize(Widget w)
{
    Dimension width, height;

#ifdef X11R5
    mySetArg_1st(XtNwidth, &width);
    mySetArg(XtNheight, &height);
    XtGetValues(w, Args, Argn );
#else
    XtVaGetValues(w, XtNwidth, &width, XtNheight, &height, NULL);
#endif

#ifdef X11R5
    mySetArg_1st(XtNminWidth, width);
    mySetArg(XtNmaxWidth, width);
    mySetArg(XtNminHeight, height);
    mySetArg(XtNmaxHeight, height);
    XtSetValues(w, Args, Argn);
#else
    XtVaSetValues(w,
                  XtNminWidth, width,
                  XtNmaxWidth, width,
                  XtNminHeight, height,
                  XtNmaxHeight, height,
                  NULL );
#endif
}

//#define DEBUG_CODE
void
Stadium::update()
{
    showinfo_t *show;
    msginfo_t *msg;
    drawinfo_t *draw;
    Display *display;
    short kind, side, unum, num;
    char c = port.recv_info();

#ifdef DEBUG_CODE
    std::cout << "Received messages of type " << (int)c << std::endl;
#endif

    switch (c) {
    case SHOW_MODE:
        if ( port.version == 1)
        {
            int i;
            show = &(port.rinfo.body.show);

            /* ball set */
            field.ball.set(view_dir * ntohs(show->pos[0].x),
                           view_dir * ntohs(show->pos[0].y));

            /* players set */
            for ( i = 0; i < MAX_PLAYER * 2; ++i )
            {
                kind = ntohs( show->pos[i+1].enable );
                side = ntohs( show->pos[i+1].side );
                unum = ntohs( show->pos[i+1].unum );
                num = ((side == LEFT) ? 0 : 1) * MAX_PLAYER + unum - 1;

                if (((kind & (DISCARD | STAND)) != player_status[num]) && eval_flag)
                    change_discardpanel(side, unum, kind);

                if ( field.player[i].player == false )
                {
                    field.player[i].assign(side, show->team[0].name, unum, kind);
                }
                field.player[i].set(
                                    view_dir * ntohs(show->pos[i+1].x),
                                    view_dir * ntohs(show->pos[i+1].y),
                                    ntohs(show->pos[i+1].angle) - 90 * (1 - view_dir),
                                    ( -ntohs(show->pos[i+1].angle) - 90 ) - 90 * (1 - view_dir),
                                    kind, redraw);
            }

            /* other informations set */
            display_play_mode((PlayMode)show->pmode);
            display_score(LEFT, show->team[0].name, ntohs(show->team[0].score));
            display_score(RIGHT, show->team[1].name, ntohs(show->team[1].score));
            display_time(ntohs(show->time));

            display = XtDisplay(field.margin);
            XFlush(display);
        }
        else
        {
            int i;
            showinfo_t2* show2 = &(port.rinfo2.body.show);
#ifdef DEBUG_CODE
            std::cout << "Received SHOW mode; time: " << ntohs(show2->time) << std::endl;
#endif

            /* ball set */
            field.ball.set( static_cast< Int16 >( view_dir * ((double)(Int32)ntohl(show2->ball.x) / SHOWINFO_SCALE2) * SHOWINFO_SCALE ),
                            static_cast< Int16 >( view_dir * ((double)(Int32)ntohl(show2->ball.y) / SHOWINFO_SCALE2) * SHOWINFO_SCALE ) );

            /* players set */
            for ( i = 0; i < MAX_PLAYER * 2; i++ )
            {
                kind = ntohs(show2->pos[i].mode);
                side = ( ( i < MAX_PLAYER ) ? LEFT : RIGHT );
                unum = (i % MAX_PLAYER) + 1;
                //num = ((side == LEFT) ? 0 : 1) * MAX_PLAYER + unum - 1;

                if (((kind & (DISCARD | STAND)) != player_status[i]) && eval_flag)
                    change_discardpanel(side, unum, kind);

                if ( field.player[i].player == false )
                {
                    field.player[i].assign(side, show2->team[0].name, unum, kind);
                }
                field.player[i].set( static_cast< Int16 >( view_dir * ((double)(Int32)ntohl(show2->pos[i].x) / SHOWINFO_SCALE2) * SHOWINFO_SCALE ),
                                     static_cast< Int16 >( view_dir * ((double)(Int32)ntohl(show2->pos[i].y) / SHOWINFO_SCALE2) * SHOWINFO_SCALE ),
                                     static_cast< Int16 >( Rad2Deg((double)(Int32)ntohl(show2->pos[i].body_angle) / SHOWINFO_SCALE2) - 90 * (1 - view_dir) ),
                                     static_cast< Int16 >( Rad2Deg( PI/2 - ( (double)(Int32)ntohl(show2->pos[i].body_angle) / SHOWINFO_SCALE2 + (double)(long)ntohl(show2->pos[i].head_angle) / SHOWINFO_SCALE2 ) ) - 90 * (1 - view_dir) ),
                                     kind, redraw,
                                     static_cast< Int16 >( (Int32)ntohl(show2->pos[i].stamina) / SHOWINFO_SCALE2) );
            }

            /* other informations set */
            display_play_mode((PlayMode)show2->pmode);
            display_score(LEFT, show2->team[0].name, ntohs(show2->team[0].score));
            display_score(RIGHT, show2->team[1].name, ntohs(show2->team[1].score));
            display_time(ntohs(show2->time));

            display = XtDisplay(field.margin);
            XFlush(display);


        }
        break;

    case MSG_MODE:
#ifdef DEBUG_CODE
        std::cout << "Received MSG mode" << std::endl;
#endif
	      if ( port.version == 1 )
            msg = &(port.rinfo.body.msg);
	      else
            msg = &(port.rinfo2.body.msg);

        switch (ntohs(msg->board)) {
        case MSG_BOARD:
            if (!std::strcmp(msg->message, "(referee half_time)\n")) {
                view_dir = VIEW_REV;
#ifdef X11R5
                mySetArg_1st(XtNjustify, XtJustifyLeft);
                mySetArg(XtNhorizDistance, 0);
                XtSetValues(status_r, Args, Argn);

                mySetArg_1st(XtNjustify, XtJustifyRight);
                mySetArg(XtNhorizDistance,
                         InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) * 3 / 4 + 2);
                XtSetValues(status_l, Args, Argn);
#else
                XtVaSetValues(status_r,
                              XtNjustify, XtJustifyLeft,
                              XtNhorizDistance, 0,
                              NULL);

                XtVaSetValues(status_l,
                              XtNjustify, XtJustifyRight,
                              XtNhorizDistance,
                              InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) * 3 / 4 + 2,
                              NULL);
#endif
                if(popup) {
#ifdef X11R5
                    mySetArg_1st(XtNfromHoriz, goallabel);
                    mySetArg(XtNhorizDistance, -glabel_width);
                    XtSetValues(goalscore_r, Args, Argn);
                    mySetArg_1st(XtNfromHoriz, goalscore_r);
                    XtSetValues(goalscore_c, Args, Argn);
                    mySetArg_1st(XtNfromHoriz, goalscore_c);
                    mySetArg(XtNhorizDistance, 0);
                    XtSetValues(goalscore_l, Args, Argn);
#else
                    XtVaSetValues(goalscore_r,
                                  XtNfromHoriz, goallabel,
                                  XtNhorizDistance, -glabel_width,
                                  NULL);
                    XtVaSetValues(goalscore_c,
                                  XtNfromHoriz, goalscore_r,
                                  NULL);
                    XtVaSetValues(goalscore_l,
                                  XtNfromHoriz, goalscore_c,
                                  XtNhorizDistance, 0,
                                  NULL);
#endif
                }
            }
            else if (!std::strcmp(msg->message, "(referee time_extended)\n")) {
                view_dir = VIEW_FOR;
#ifdef X11R5
                mySetArg_1st(XtNjustify, XtJustifyLeft);
                mySetArg(XtNhorizDistance, 0);
                XtSetValues(status_l, Args, Argn);

                mySetArg_1st(XtNjustify, XtJustifyRight);
                mySetArg(XtNhorizDistance,
                         InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) * 3 / 4 + 2);
                XtSetValues(status_r, Args, Argn);
#else
                XtVaSetValues(status_l,
                              XtNjustify, XtJustifyLeft,
                              XtNhorizDistance, 0,
                              NULL);

                XtVaSetValues(status_r,
                              XtNjustify, XtJustifyRight,
                              XtNhorizDistance,
                              InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) * 3 / 4 + 2,
                              NULL);
#endif
            }

            write_message(Msg_board, msg->message);
            break;

        case LOG_BOARD:
            write_message(Log_board, msg->message);
            break;

        default:
            std::cerr << "Illegal value(1): " << ntohs(msg->board) << std::endl;
            break;
        }

        break;

    case DRAW_MODE:
        draw = &(port.rinfo.body.draw);
        switch (ntohs(draw->mode)) {
        case DrawPoint:
            field.drawpoint(ntohs(draw->object.pinfo.x),
                            ntohs(draw->object.pinfo.y),
                            draw->object.pinfo.color);
            break;

        case DrawCircle:
            field.drawcircle(ntohs(draw->object.cinfo.x),
                             ntohs(draw->object.cinfo.y),
                             ntohs(draw->object.cinfo.r),
                             draw->object.cinfo.color);
            break;

        case DrawLine:
            field.drawline(ntohs(draw->object.linfo.x1),
                           ntohs(draw->object.linfo.y1),
                           ntohs(draw->object.linfo.x2),
                           ntohs(draw->object.linfo.y2),
                           draw->object.linfo.color);
            break;

        case DrawClear:
            field.drawclear();
            break;

        default:
            std::cerr << "Illegal value (2): " << ntohs(draw->mode) << std::endl;
            exit(1);
        }

        break;

    case NO_INFO:
        break;

    case BLANK_MODE:
        field.ball.set((short)0.0, (short)0.0);

        for ( int i = 0; i < MAX_PLAYER * 2; i++)
            if ( field.player[i].player != false )
                field.player[i].destroy();

        display_play_mode(PM_Null);
        display_score(LEFT, "Team_L", 'x');
        display_score(RIGHT, "Team_R", 'x');
        display_time(0);

        for ( int i = 0; i <= 6; i++) {
            write_message(Msg_board, "\n");
            write_message(Log_board, "\n");
        }

        display = XtDisplay(field.margin);
        XFlush(display);

        break;

    case PARAM_MODE:
        stamina_max = (short)(ntohl(port.rinfo2.body.sparams.stamina_max) / SHOWINFO_SCALE2);
        //pfr: 4/29/01: We need to make sure that stamina_max stays positive so that
        // we avoid divide by 0 errors. Some logfiles seem to have a problem with
        // their parameter mode being strange
        stamina_max = (stamina_max <= 0) ? 1 : stamina_max;
        break;

    case PPARAM_MODE:
    case PT_MODE:
        break;

    default:
        std::cerr << "Illegal value(3): " << (int)c << "'" << c << "'" << std::endl;
        exit(1);
    }
}


/*
 *===================================================================
 *Part: Field
 *===================================================================
 */
Field::Field()
{
    for ( int i = 1; i <= MAX_PLAYER * 2; ++i )
        player[i].player = false;

    score_l = score_r = -1;
    gwidth = GOAL_WIDTH;
    length_magnify = LENGTH_MAGNIFY;
    //std::strcpy( mark_file, DEFAULT_MARK_FILE_NAME );
    std::strcpy( mark_file, "" );
    pmark = true;
    degree = (int)Rad2Deg(acos((PENALTY_AREA_LENGTH-PENALTY_SPOT_DIST)
                               /CENTER_CIRCLE_R));
}

void Field::assign(Widget parent)
{
#ifdef X11R5
    mySetArg_1st(XtNwidth, InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) + 1);
    mySetArg(XtNheight,InPitchSize(PITCH_WIDTH + 2 * PITCH_MARGIN) + 1);
    mySetArg(XtNborderWidth, 2);
    mySetArg(XtNdefaultDistance, 0);
    margin = XtCreateManagedWidget("margin",
                                   formWidgetClass,
                                   parent, Args, Argn);
#else
    margin = XtVaCreateManagedWidget("margin",
                                     formWidgetClass,
                                     parent,
                                     XtNwidth, InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) + 1,
                                     XtNheight,InPitchSize(PITCH_WIDTH + 2 * PITCH_MARGIN) + 1,
                                     XtNborderWidth, 2,
                                     XtNdefaultDistance, 0,
                                     NULL );
#endif
}

void
Field::draw()
{
    XColor def, closest;

    display = XtDisplay(margin);
    window = XtWindow(margin);
    gc = DefaultGC(display, DefaultScreen(display) );

    field = XCreatePixmap( display, window,
                           InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) + 1,
                           InPitchSize(PITCH_WIDTH + 2 * PITCH_MARGIN) + 1,
                           DefaultDepthOfScreen(XtScreen(margin)));

    field_bak = XCreatePixmap( display, window,
                               InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) + 1,
                               InPitchSize(PITCH_WIDTH + 2 * PITCH_MARGIN) + 1,
                               DefaultDepthOfScreen(XtScreen(margin)));

    XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                     "indianred", &def, &closest);
    XSetForeground(display, gc, closest.pixel);

    /* margin */
    XFillRectangle(display, field, gc,
                   0, 0,
                   InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) + 1,
                   InPitchSize(PITCH_WIDTH + 2 * PITCH_MARGIN) + 1);

    XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                     DEFAULT_FIELD_COLOR, &def, &closest);
    XSetForeground(display, gc, closest.pixel);


    /* field */
    XFillRectangle(display, field, gc,
                   InFieldPosX(-PITCH_LENGTH/2.0),InFieldPosY(-PITCH_WIDTH/2.0),
                   InPitchSize(PITCH_LENGTH),InPitchSize(PITCH_WIDTH));

    /* print mark on field */
    if( pmark == true ){
        Pixmap mark;
        int status;
        unsigned int pmark_width, pmark_height;

        XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                         DEFAULT_FIELD_MARK_COLOR, &def, &closest);
        XSetBackground(display, gc, closest.pixel);

        if ( std::strlen( mark_file ) == 0
             || (status = XReadBitmapFile(display, field, mark_file,
                                          &pmark_width, &pmark_height, &mark,
                                          NULL, NULL)) != BitmapSuccess )
        {
            switch(status){
            case BitmapOpenFailed:
                std::fprintf(stderr, "xbitmap: could not open mark bitmap file.\n");
                break;
            case BitmapFileInvalid:
                std::fprintf(stderr, "xbitmap: mark bitmap file invalid.\n");
                break;
            case BitmapNoMemory:
                std::fprintf(stderr, "xbitmap: insufficient server memory to create ball bitmap.\n");
                break;
            }
            std::fprintf(stderr, "         use default bitmap file.\n");
            mark = XCreateBitmapFromData(display, field,
                                         (const char*)mark_bits,
                                         mark_width, mark_height);
            pmark_width = mark_width;
            pmark_height = mark_height;
        }

        XCopyPlane(display, mark, field, gc, 0, 0,
                   pmark_width, pmark_height,
                   (InFieldPosX(0) - pmark_width/2),
                   (InFieldPosY(0) - pmark_height/2), 1);
    }

    XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                     "white", &def, &closest);
    XSetForeground(display, gc, closest.pixel);

    /* field line */
    XDrawRectangle(display, field, gc,
                   InFieldPosX(-PITCH_LENGTH/2.0),InFieldPosY(-PITCH_WIDTH/2.0),
                   InPitchSize(PITCH_LENGTH),InPitchSize(PITCH_WIDTH));

    /* center line */
    XDrawLine(display, field, gc,
              InFieldPosX(0.0),InFieldPosY(-PITCH_WIDTH/2.0),
              InFieldPosX(0.0),InFieldPosY(PITCH_WIDTH/2.0));

    /* left penalty area */
    XDrawRectangle(display, field, gc,
                   InFieldPosX(-PITCH_LENGTH/2.0),
                   InFieldPosY(-PENALTY_AREA_WIDTH/2.0),
                   InPitchSize(PENALTY_AREA_LENGTH),
                   InPitchSize(PENALTY_AREA_WIDTH));

    /* right penalty area */
    XDrawRectangle(display, field, gc,
                   InFieldPosX(PITCH_LENGTH/2.0-PENALTY_AREA_LENGTH),
                   InFieldPosY(-PENALTY_AREA_WIDTH/2.0),
                   InPitchSize(PENALTY_AREA_LENGTH),
                   InPitchSize(PENALTY_AREA_WIDTH));

    /* left goal area */
    XDrawRectangle(display, field, gc,
                   InFieldPosX(-PITCH_LENGTH/2.0),
                   InFieldPosY(-GOAL_AREA_WIDTH/2.0),
                   InPitchSize(GOAL_AREA_LENGTH),
                   InPitchSize(GOAL_AREA_WIDTH));

    /* right goal area */
    XDrawRectangle(display, field, gc,
                   InFieldPosX(PITCH_LENGTH/2.0-GOAL_AREA_LENGTH),
                   InFieldPosY(-GOAL_AREA_WIDTH/2.0),
                   InPitchSize(GOAL_AREA_LENGTH),
                   InPitchSize(GOAL_AREA_WIDTH));

    /* center circle */
    XDrawArc(display, field, gc,
             InFieldPosX(-CENTER_CIRCLE_R),
             InFieldPosY(-CENTER_CIRCLE_R),
             InPitchSize(CENTER_CIRCLE_R*2.0),
             InPitchSize(CENTER_CIRCLE_R*2.0),
             0, 360 * 64);

    /* left penalty arc */
    XDrawArc(display, field, gc,
             InFieldPosX(-PITCH_LENGTH/2.0+PENALTY_SPOT_DIST -CENTER_CIRCLE_R) + 1,
             InFieldPosY(-CENTER_CIRCLE_R),
             InPitchSize(CENTER_CIRCLE_R*2.0),
             InPitchSize(CENTER_CIRCLE_R*2.0),
             -degree * 64, degree * 2 * 64);

    /* right penalty arc */
    XDrawArc(display, field, gc,
             InFieldPosX(PITCH_LENGTH/2.0-PENALTY_SPOT_DIST -CENTER_CIRCLE_R),
             InFieldPosY(-CENTER_CIRCLE_R),
             InPitchSize(CENTER_CIRCLE_R*2.0),
             InPitchSize(CENTER_CIRCLE_R*2.0),
             (180 - degree) * 64, degree * 2 * 64);

    /* upper left corner arc */
    XDrawArc(display, field, gc,
             InFieldPosX(-PITCH_LENGTH/2.0-CORNER_ARC_R),
             InFieldPosY(-PITCH_WIDTH/2.0-CORNER_ARC_R),
             InPitchSize(CORNER_ARC_R*2.0),
             InPitchSize(CORNER_ARC_R*2.0),
             -90 * 64, 90 * 64);

    /* upper right corner arc */
    XDrawArc(display, field, gc,
             InFieldPosX(PITCH_LENGTH/2.0-CORNER_ARC_R),
             InFieldPosY(-PITCH_WIDTH/2.0-CORNER_ARC_R),
             InPitchSize(CORNER_ARC_R*2.0),
             InPitchSize(CORNER_ARC_R*2.0),
             180 * 64, 90 * 64);

    /* lower left corner arc */
    XDrawArc(display, field, gc,
             InFieldPosX(-PITCH_LENGTH/2.0-CORNER_ARC_R),
             InFieldPosY(PITCH_WIDTH/2.0-CORNER_ARC_R),
             InPitchSize(CORNER_ARC_R*2.0),
             InPitchSize(CORNER_ARC_R*2.0),
             0 * 64, 90 * 64);

    /* lower right corner arc */
    XDrawArc(display, field, gc,
             InFieldPosX(PITCH_LENGTH/2.0-CORNER_ARC_R),
             InFieldPosY(PITCH_WIDTH/2.0-CORNER_ARC_R),
             InPitchSize(CORNER_ARC_R*2.0),
             InPitchSize(CORNER_ARC_R*2.0),
             90 * 64, 90 * 64);

    XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                     "black", &def, &closest);
    XSetForeground(display, gc, closest.pixel);

    /* left side goal */
    XFillRectangle(display,field,gc,
                   InFieldPosX(-PITCH_LENGTH/2.0-GOAL_DEPTH)+1,
                   InFieldPosY(-gwidth/2.0),
                   InPitchSize(GOAL_DEPTH)+1,
                   InPitchSize(gwidth)+1);

    /* right side goal */
    XFillRectangle(display,field,gc,
                   InFieldPosX(PITCH_LENGTH/2.0),
                   InFieldPosY(-gwidth/2.0),
                   InPitchSize(GOAL_DEPTH)+1,
                   InPitchSize(gwidth)+1);

    XSetWindowBackgroundPixmap(display, window, field);
    XClearWindow(display, window);

    XCopyArea(display, field, field_bak, gc, 0, 0,
              InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) + 1,
              InPitchSize(PITCH_WIDTH + 2 * PITCH_MARGIN) + 1,
              0,0);
}

void Field::drawpoint(short x, short y, char *color)
{
    XColor def, closest;

    if (!XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                          color, &def, &closest)) {
        std::printf("Can't find Draw color!\nUse default color.\n");
        XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display) ),
                         DEFAULT_DRAW_COLOR, &def, &closest);
    }

    XSetForeground(display, gc, closest.pixel);

    XDrawPoint(display, field, gc,
               InFieldPosX(x), InFieldPosY(y));

    XSetWindowBackgroundPixmap(display, window, field);
    XClearWindow(display, window);
}

void Field::drawcircle(short x, short y, short r, char *color)
{
    XColor def, closest;

    if (!XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display)),
                          color, &def, &closest)) {
        std::printf("Can't find Draw color!\nUse default color.\n");
        XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display)),
                         DEFAULT_DRAW_COLOR, &def, &closest);
    }

    XSetForeground(display, gc, closest.pixel);

    XDrawArc(display, field, gc,
             InFieldPosX(x), InFieldPosY(y),
             InPitchSize(r*2.0), InPitchSize(r*2.0),
             0, 360 * 64);

    XSetWindowBackgroundPixmap(display, window, field);
    XClearWindow(display, window);
}

void Field::drawline(short x1, short y1, short x2, short y2, char *color)
{
    XColor def, closest;

    if (!XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display)),
                          color, &def, &closest)) {
        std::printf("Can't find Draw color!\nUse default color.\n");
        XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display)),
                         DEFAULT_DRAW_COLOR, &def, &closest);
    }

    XSetForeground(display, gc, closest.pixel);

    XDrawLine(display, field, gc,
              InFieldPosX(x1), InFieldPosY(y1),
              InFieldPosX(x2), InFieldPosY(y2));

    XSetWindowBackgroundPixmap(display, window, field);
    XClearWindow(display, window);
}

void
Field::drawclear()
{
    XCopyArea(display, field_bak, field, gc, 0, 0,
              InPitchSize(PITCH_LENGTH + 2 * PITCH_MARGIN) + 1,
              InPitchSize(PITCH_WIDTH + 2 * PITCH_MARGIN) + 1,
              0,0);

    XSetWindowBackgroundPixmap(display, window, field);
    XClearWindow(display, window);
}

bool
Field::infieldcheck( short x, short y )
{
    if( x < InFieldPosX(-PITCH_LENGTH/2.0) ||
        x > InFieldPosX(-PITCH_LENGTH/2.0) + InPitchSize(PITCH_LENGTH)||
        y < InFieldPosY(-PITCH_WIDTH/2.0) ||
        y > InFieldPosY(-PITCH_WIDTH/2.0) + InPitchSize(PITCH_WIDTH) )
        return false;
    return true;
}

/*
 *===================================================================
 *Part: Misc
 *===================================================================
 */
static void Quit(void)
{
#ifdef HAVE_XTDESTROYAPPLICATIONCONTEXT
    XtDestroyApplicationContext(Std.app_context);
#endif
#ifdef HAVE_XTAPPSETEXITFLAG
    XtAppSetExitFlag(Std.app_context);
#else
    exit(0);
#endif
}

static void Start(void)
{
    Std.port.send_info("(dispstart)");
}

static void Update(void)
{
    Std.update();
}

static void FoulMenuPlace(Widget w, XButtonEvent *event)
{
    foul_pos.x = (short)event->x;
    foul_pos.y = (short)event->y;

#ifdef X11R5
    mySetArg_1st(XtNx, event->x_root - 10);
    mySetArg(XtNy, event->y_root -5 );
    XtSetValues(foulmenu, Args, Argn);
#else
    XtVaSetValues(foulmenu,
                  XtNx, event->x_root - 10,
                  XtNy, event->y_root - 5,
                  NULL);
#endif
    if( Std.field.infieldcheck(foul_pos.x, foul_pos.y) == false )
    {
#ifdef X11R5
        mySetArg_1st(XtNx, -100);
        mySetArg(XtNy, -100 );
        XtSetValues(foulmenu, Args, Argn);
#else
        XtVaSetValues(foulmenu,
                      XtNx, -100,
                      XtNy, -100,
                      NULL);
#endif
    }
}

static void FoulMenuCheck(void)
{
    if( Std.field.infieldcheck(foul_pos.x, foul_pos.y) == false )
        XtPopdown(foulmenu);
}

static void FoulPanelChosen(Widget w, XtPointer client_data)
{
    Std.sendfoulpos(foul_pos.x, foul_pos.y, (int)client_data);
    XtPopdown(foulmenu);
}

static void DiscardMenuPlace1(Widget w, XEvent *event)
{
    XLeaveWindowEvent *leave_event = (XLeaveWindowEvent *) event;
    Dimension height, width;

#ifdef X11R5
    mySetArg_1st(XtNheight, &height);
    mySetArg(XtNwidth, &width);
    XtGetValues(w, Args, Argn);
#else
    XtVaGetValues(w,
                  XtNheight, &height,
                  XtNwidth, &width,
                  NULL);
#endif

    if ((leave_event->x > width) &&
        (leave_event->y > 0) &&
        (leave_event->y < height)) {
#ifdef X11R5
        mySetArg_1st(XtNx, leave_event->x_root - 10);
        mySetArg(XtNy, leave_event->y_root -12);
        XtSetValues(discardmenu1, Args, Argn);
#else
        XtVaSetValues(discardmenu1,
                      XtNx, leave_event->x_root - 10,
                      XtNy, leave_event->y_root - 12,
                      NULL);
#endif
        XtPopup(discardmenu1, XtGrabNonexclusive);
    }
}

static void DiscardMenuPlace2(Widget w, XEvent *event)
{
    XLeaveWindowEvent *leave_event = (XLeaveWindowEvent *) event;
    Dimension height, width;

#ifdef X11R5
    mySetArg_1st(XtNheight, &height);
    mySetArg(XtNwidth, &width);
    XtGetValues(w, Args, Argn);
#else
    XtVaGetValues(w,
                  XtNheight, &height,
                  XtNwidth, &width,
                  NULL);
#endif

    if ((leave_event->x > width) &&
        (leave_event->y > 0) &&
        (leave_event->y < height)) {
#ifdef X11R5
        mySetArg_1st(XtNx, leave_event->x_root - 10);
        mySetArg(XtNy, leave_event->y_root -12);
        XtSetValues(discardmenu2, Args, Argn);
#else
        XtVaSetValues(discardmenu2,
                      XtNx, leave_event->x_root - 10,
                      XtNy, leave_event->y_root - 12,
                      NULL);
#endif
        XtPopup(discardmenu2, XtGrabNonexclusive);
    }
}

static void DiscardPanelChosen1(Widget w, XtPointer client_data)
{
    Std.senddiscard(LEFT, (int)(client_data)+1);
    XtPopdown(discardmenu1);
    XtPopdown(foulmenu);
}

static void DiscardPanelChosen2(Widget w, XtPointer client_data)
{
    Std.senddiscard(RIGHT, (int)(client_data)+1);
    XtPopdown(discardmenu2);
    XtPopdown(foulmenu);
}

static void PopdownDiscardMenu1(Widget w)
{
    XtPopdown(discardmenu1);
}

static void PopdownDiscardMenu2(Widget w)
{
    XtPopdown(discardmenu2);
}

void Stadium::change_discardpanel(short side, short unum, short kind)
{
    char buf[32];

    short num = ((side == LEFT) ? 0 : 1) * MAX_PLAYER + unum - 1;
    if (kind == DISABLE)
        player_status[num] = DISABLE;
    else if (!(player_status[num] & STAND) && kind & STAND)
        player_status[num] |= STAND;
    else if (player_status[num] & STAND && !(kind & STAND))
        player_status[num] &= ~STAND;
    else if (!(player_status[num] & DISCARD) && kind & DISCARD)
        player_status[num] |= DISCARD;
    else if (player_status[num] & DISCARD && !(kind & DISCARD))
        player_status[num] &= ~DISCARD;

    if (player_status[num] == DISABLE)
        std::snprintf(buf, sizeof( buf ), "%2d: None", unum);
    else if (player_status[num] == (STAND | DISCARD))
        std::snprintf(buf, sizeof( buf ), "%2d: Disable", unum);
    else if (player_status[num] == STAND)
        std::snprintf(buf, sizeof( buf ), "%2d: Active", unum);
    else
        std::snprintf(buf, sizeof( buf ), "%2d: Error", unum);

#ifdef X11R5
    mySetArg_1st(XtNlabel, buf);
    mySetArg(XtNwidth, panel_width/2);
    if (side == LEFT)
        XtSetValues(Std.discardpanel1[unum-1], Args, Argn);
    else
        XtSetValues(Std.discardpanel2[unum-1], Args, Argn);
#else
    if (side == LEFT)
        XtVaSetValues(Std.discardpanel1[unum-1],
                      XtNlabel, buf,
                      XtNwidth, panel_width/2,
                      NULL);
    else
        XtVaSetValues(Std.discardpanel2[unum-1],
                      XtNlabel, buf,
                      XtNwidth, panel_width/2,
                      NULL);
#endif
}
