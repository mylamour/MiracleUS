/*
 *Header:
 *File: field.h (for C++)
 *Author: Noda Itsuki
 *Date: 1996/01/28
 *EndHeader:
 */

/*
 *Copyright:

 Copyright (C) 1996-2000 Electrotechnical Laboratory.
 Itsuki Noda, Yasuo Kuniyoshi and Hitoshi Matsubara.
 Copyright (C) 2000-2007 RoboCup Soccer Server Maintainance Group.
 Patrick Riley, Tom Howard, Daniel Polani, Itsuki Noda,
 Mikhail Prokopenko, Jan Wendler

 This file is a part of SoccerServer.

 This code is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 *EndCopyright:
 */

#ifndef RCSSMONITOR_CLASSIC_FIELD_H
#define RCSSMONITOR_CLASSIC_FIELD_H

#include "netif.h"
#include "object.h"

#include <cstdio>

#include <X11/Intrinsic.h>

/*
 *===================================================================
 *Part: Window Size/Pos Parameter
 *===================================================================
 */
#define InPitchSize(l)		((int)((l) * length_magnify))
#define InPitchPosX(x)		InPitchSize((x) + PITCH_LENGTH/2.0)
#define InPitchPosY(y)		InPitchSize((y) + PITCH_WIDTH/2.0)
#define InFieldPosX(x)		InPitchPosX((x) + PITCH_MARGIN)
#define InFieldPosY(y)		InPitchPosY((y) + PITCH_MARGIN)

#define InDisplaySize(l)	(InPitchSize(l*2.0))

/*
 *===================================================================
 *Part: Field Class
 *===================================================================
 */
class Field {
public:
		Widget top;	/*!< top widget */
		Widget margin;/*!< margin */
		Display *display;
		Window window;
		GC gc;
		Pixmap field; /*!< field pixmap */
		Pixmap field_bak; /*!< backup field pixmap */
		char score_l;	/*!< for left team */
		char score_r;	/*!< for right team */
		Player player[MAX_PLAYER*2]; /*!< player widget */
		Ball ball; /*!< ball widget */
		Value gwidth; /*!< goal width */
		int degree;	/*!< penalty arc degree */
		double length_magnify; /*!< field size */
		char mark_file[128]; /*!< mark file name */
		bool pmark; /*!< flag of print mark */

    Field(); /*!< constructor */
		void assign(Widget);
		void draw();
		bool infieldcheck( short, short );
		void drawpoint( short, short, char* );
		void drawcircle( short, short, short, char* );
		void drawline( short, short, short, short, char* );
		void drawclear();
};


/*
 *===================================================================
 *Part: Stadium Class
 *===================================================================
 */
class Stadium {
public:
		XtAppContext	app_context;			/* application context */
		Widget			toplevel;				/* top widget */
		Widget			main;					/* main widget */
		Widget			Msg_board;				/* message board */
		Widget			Log_board;				/* log board */
		Widget			status_l;				/* for left team */
		Widget			status_r;				/* for right team */
		Widget			status_t;				/* to display time */
		Widget			status_m;				/* to display play mode */
		Widget			foulbox;				/* foul menu box */
		Widget			foullabel;				/* foul menu label */
		Widget			foulpanel[5];			/* foul menu panel */
		Widget			discardbox1;			/* discard menu box */
		Widget			discardlabel1;			/* discard menu label */
		Widget			discardpanel1[MAX_PLAYER];
		Widget			discardbox2;			/* discard menu box */
		Widget			discardlabel2;			/* discard menu label */
		Widget			discardpanel2[MAX_PLAYER];
		Widget			goal;					/* goal pop up & down */
		Widget			goalform;				/* goal form */
		Widget			goallabel;				/* goal label */
		Widget			goalscore_l;
		Widget			goalscore_r;
		Widget			goalscore_c;
		Widget			offside;				/* offside popu up & down */
		Widget			offsideform;			/* goal form */
		Widget			offsidelabel;			/* goal label */
		Field			field;					/* field */
		char			ball_file[128];		/* ball file name */
		double			psize;					/* player widget size */
		char			pfont[128];			/* player widget font */
		int				pfont_x;				/* player widget font pos x */
		int				pfont_y;				/* player widget font pos y */
		Player			player;
		PlayMode		playmode;				/* play mode */
		int				playtime;				/* play time */
		bool			plog;					/* flag of print log */
		bool			popup;					/* flag of popup msg */
		Port			port;					/* communication port */
		double			length_magnify;		/* field size */
		int				board_rows;			/* number of rows of board */
		char			color_l[128];			/* color of left side team */
		char			color_r[128];			/* color of right side team */
		char			goalie_color_l[128];	/* color of left side goalie */
		char			goalie_color_r[128];	/* color of right side goalie */
		char			neck_color_l[128];		/* color of left side necks */
		char			neck_color_r[128];		/* color of right side necks */
		char			goalie_neck_color_l[128];      /* color of left side goalie neck */
		char			goalie_neck_color_r[128];      /* color of right side goalie neck */
		char			status_font[128];		/* status line font
                                       team name,score,time,etc.*/
		char			glabel_font[128];		/* pop up "GOAL!!" font */
		int				glabel_width;			/* pop up "GOAL!!" width */
		char			gscore_font[128];		/* pop up score font */
		int				gscore_width;			/* pop up score width */
		char			olabel_font[128];		/* pop up "Offside!" font */
		int				olabel_width;			/* pop up "Offside!" width */
		short			view_dir;				/* view direction */
		int				player_status[MAX_PLAYER*2];
		Dimension		panel_width;
		int				eval_flag;				/* flag for eval mode */
		int				redraw; 		/* flag for linux XServer SVGA bug */
		short				stamina_max; 		/* stamina max */

    Stadium();				/* constructor */
    ~Stadium();
		void			init(int, char **);
		void			getOption(int, char **);
		void			MainLoop();
		void			sendfoulpos(short, short, short);
		void			senddiscard(short, short);
		void			assign(Widget);
		void			no_resize(Widget);
		void			display_score(Side, Name, char);
		void			display_time(int);
		void			display_play_mode(PlayMode);
		void			write_message(Widget, char *);
		void			update();
		void			change_discardpanel(short side, short unum, short side);
		void 			readConf ( FILE* fp );
};

#endif
