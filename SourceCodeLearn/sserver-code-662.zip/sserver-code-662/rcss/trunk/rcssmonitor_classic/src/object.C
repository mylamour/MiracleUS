/* -*- Mode: C++ -*-
 *Header:
 *File: object.C
 *Author: Noda Itsuki
 *Date: 1996/01/28
 *EndHeader:
 */

/*
 *Copyright:

 Copyright (C) 1996-2000 Electrotechnical Laboratory.
 Itsuki Noda, Yasuo Kuniyoshi and Hitoshi Matsubara.
 Copyright (C) 2000-2007 RoboCup Soccer Server Maintainance Group.
 Patrick Riley, Tom Howard, Daniel Polani, Itsuki Noda,
 Mikhail Prokopenko, Jan Wendler

 This file is a part of SoccerServer.

 This code is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 *EndCopyright:
 */


#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "object.h"

#include "param.h"
#include "fallback.h"
#include "types.h"
#include "utility.h"
#include "netif.h"
#include "field.h"

#include <cmath>
#include <cstdio>
#include <iostream>
#include <algorithm>

#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Form.h>

#include "ball.xbm"

extern Stadium Std;

#ifdef X11R5
static Arg Args[16];
static int Argn;
#endif

/*
 *===================================================================
 *Part: Ball
 *===================================================================
 */
void
Ball::assign()
{
    int status;
    unsigned int ball_xbm_width, ball_xbm_height;

    Pixmap pix, tmp;
    GC gc;
    XGCValues gcv;
    XColor def, closest;
    disp = XtDisplay( Std.field.margin );
    Window win = XtWindow( Std.field.margin );
    Screen *scr = XtScreen( Std.field.margin );

    XAllocNamedColor(disp, DefaultColormapOfScreen(scr),
                     DEFAULT_FIELD_COLOR, &def, &closest);

    if ( std::strlen( Std.ball_file ) != 0
         && (status = XReadBitmapFile(disp, win,
                                      Std.ball_file,
                                      &ball_xbm_width, &ball_xbm_height, &tmp,
                                      NULL, NULL)) == BitmapSuccess )
    {
        pix = XCreatePixmap(disp, win, ball_xbm_width, ball_xbm_height,
                            DefaultDepthOfScreen(scr));
        gcv.function = GXcopy;
        gcv.foreground = WhitePixel(disp, DefaultScreen(disp));
        gcv.background = closest.pixel;

        gc = XCreateGC(disp, pix, (GCFunction|GCForeground|GCBackground), &gcv);

        XCopyPlane(disp, tmp, pix, gc,
                   0, 0, ball_xbm_width, ball_xbm_height, 0, 0, 1);
        XFreeGC(disp, gc);
        XFreePixmap(disp, tmp);
    }
    else
    {
        switch(status){
        case BitmapOpenFailed:
            fprintf(stderr, "xbitmap: could not open ball bitmap file.\n");
            break;
        case BitmapFileInvalid:
            fprintf(stderr, "xbitmap: ball bitmap file invalid.\n");
            break;
        case BitmapNoMemory:
            fprintf(stderr, "xbitmap: insufficient server memory to create ball bitmap.\n");
            break;
        }
        fprintf(stderr, "         use default bitmap file.\n");
        pix = XCreatePixmapFromBitmapData(disp,DefaultRootWindow(disp),
                                          ball_bits,ball_width,ball_height,
                                          WhitePixel(disp, DefaultScreen(disp)), closest.pixel,
                                          DefaultDepthOfScreen(scr));
        ball_xbm_width = ball_width;
        ball_xbm_height = ball_height;
    }

    ball = XCreateSimpleWindow(disp, win,
                               (Position)ball_xbm_width, (Position)ball_xbm_height,
                               ball_xbm_width, ball_xbm_height, 0, 0, 0);
    XSetWindowBackgroundPixmap(disp, ball, pix);
    XMapWindow(disp, ball);
    XFreePixmap(disp, pix);

    length_magnify = Std.length_magnify;
    pos_x = -1;
    pos_y = -1;
}

void
Ball::set( short x, short y )
{
    if (pos_x != x || pos_y != y) {
        XMoveWindow(disp, ball,
                    std::max( InFieldPosX((x/SHOWINFO_SCALE)) - ball_width/2, 0 ),
                    std::max( InFieldPosY((y/SHOWINFO_SCALE)) - ball_height/2, 0 )
                    );
        pos_x = x;
        pos_y = y;
        XFlush( disp );
    }
}

/*
 *===================================================================
 *Part: Player
 *===================================================================
 */
void
Player::assign( Side side, Name team, int unum, short kind )
{
    /* XColor def; */ /* [I.Noda:2001.10.4: comment out to avoid warning */
    /* XColor closest; */ /* [I.Noda:2001.10.4: comment out to avoid warning */

    Window win = XtWindow(Std.field.margin);
    disp = XtDisplay(Std.field.margin);

    length_magnify = Std.length_magnify;
    pfont_x = Std.pfont_x;
    pfont_y = Std.pfont_y;
    size = std::max( ((Dimension)Std.psize), (Dimension)1 );
    std::snprintf( name, sizeof( name ), PLAYER_NAME_FORMAT, team, unum );
    std::snprintf( unumstr, sizeof( unumstr ), "%d", unum);
    ang = 1000;
    pos_x = -1;
    pos_y = -1;
    prev_kind = DISABLE;
    prev_stamina = 0;

    XColor c0, c1;
    XGCValues gcv;

    pix = XCreatePixmap(disp, win, size, size, DefaultDepth(disp, DefaultScreen(disp)));

    gcv.function = GXcopy;

    XAllocNamedColor(disp, DefaultColormap(disp, DefaultScreen(disp)),
                     (((side)== LEFT)? Std.color_l:Std.color_r), &c1, &c0);
    gcv.foreground = c1.pixel;
    fgh = XCreateGC(disp, pix, (GCFunction|GCForeground), &gcv);

    XAllocNamedColor(disp, DefaultColormap(disp, DefaultScreen(disp)),
                     (((side)== LEFT)? Std.goalie_color_l:Std.goalie_color_r), &c1, &c0);
    gcv.foreground = c1.pixel;
    fgh_g = XCreateGC(disp, pix, (GCFunction|GCForeground), &gcv);

    XAllocNamedColor(disp, DefaultColormap(disp, DefaultScreen(disp)),
                     DEFAULT_PLAYER_COLOR_T, &c1, &c0);
    gcv.foreground = c1.pixel;
    fgt = XCreateGC(disp, pix, (GCFunction|GCForeground), &gcv);

    XAllocNamedColor(disp, DefaultColormap(disp, 0),
                     (((side)== LEFT)? Std.neck_color_l:Std.neck_color_r), &c1, &c0);
    gcv.foreground = c1.pixel;
    fgn = XCreateGC(disp, pix, (GCFunction|GCForeground), &gcv);

    XAllocNamedColor(disp, DefaultColormap(disp, 0), (((side)== LEFT)?
                                                      Std.goalie_neck_color_l:Std.goalie_neck_color_r), &c1, &c0);
    gcv.foreground = c1.pixel;
    fgn_g = XCreateGC(disp, pix, (GCFunction|GCForeground), &gcv);

    XAllocNamedColor(disp, DefaultColormap(disp, DefaultScreen(disp)),
                     DEFAULT_FIELD_COLOR, &c1, &c0);
    gcv.foreground = c1.pixel;
    bg = XCreateGC(disp, pix, (GCFunction|GCForeground), &gcv);

    XAllocNamedColor(disp, DefaultColormap(disp, DefaultScreen(disp)),
                     DEFAULT_PLAYER_COLOR_S, &c1, &c0);

    XFontStruct *font;
    if ((font = XLoadQueryFont(disp, Std.pfont)) == NULL) {
        printf("Can not find Player Widget Font!\nUse Default Font.\n");
        strcpy(Std.pfont, DEFAULT_PLAYER_FONT);
    }
    else
        XFreeFont(disp, font);

    gcv.font = XLoadFont(disp, Std.pfont);
    gcv.foreground = c1.pixel;

    fgs = XCreateGC(disp, pix, (GCFunction|GCForeground|GCFont), &gcv);


    player = XCreateSimpleWindow(disp, win,
                                 (Position)size, (Position)size,
                                 size+1, size+1, 0, 0, 0);

    XMapWindow(disp, player);
}

void Player::set( short x, short y, short angle, short head_angle,
                  short kind, int redraw, short stamina )
{
    if (prev_stamina != stamina) {
        XColor col;
        col.red = col.green = col.blue = 0xFFFF - (0xFFFF/Std.stamina_max) * stamina;
        XAllocColor(disp, DefaultColormap(disp, DefaultScreen(disp)), &col);
        XSetForeground(disp, fgt, col.pixel);
        redraw = 1;

        prev_stamina = stamina;
    }

    if (redraw || ang != angle || prev_kind != kind) {
        XFillRectangle( disp, pix, bg, 0,0, size, size);
        if (!(kind & STAND))
            XFillArc(disp, pix, fgt, 0, 0, size, size, 0, 360*64);
        else if (kind & GOALIE){
            XFillArc(disp, pix, fgh_g, 0, 0, size, size, 0, 360*64);
            if (!(kind & CATCH))
                XFillArc(disp, pix, fgt,
                         0, 0, size, size, (-angle+90)*64, 180*64);
            XDrawArc(disp, pix, fgh_g, 0, 0, size, size, 0,360*64);
            if (kind & KICK) {
                XDrawArc(disp, pix, fgh_g, 2, 2, size-4, size-4, 0,360*64);
                XDrawArc(disp, pix, fgh_g, 3, 3, size-6, size-6, 0,360*64);
                XDrawArc(disp, pix, fgh_g, 4, 4, size-8, size-8, 0,360*64);
            }
            if (kind & BALL_COLLIDE)
            {
                XDrawArc(disp, pix, fgn_g, 0, 0, size+1, size+1, 0,360*64);
            }
            if (kind & PLAYER_COLLIDE)
            {
                XDrawArc(disp, pix, fgn_g, 0, 0, size+1, size+1, 0,360*64);
            }

        }
        else {
            XFillArc(disp, pix, fgh, 0, 0, size, size, 0, 360*64);
            XFillArc(disp, pix, fgt, 0, 0, size, size, (-angle+90)*64, 180*64);
            XDrawArc(disp, pix, fgh, 0, 0, size, size, 0,360*64);
            if (kind & KICK) {
                XDrawArc(disp, pix, fgh, 2, 2, size-4, size-4, 0,360*64);
                XDrawArc(disp, pix, fgh, 3, 3, size-6, size-6, 0,360*64);
                XDrawArc(disp, pix, fgh, 4, 4, size-8, size-8, 0,360*64);
            }
            if (kind & BALL_COLLIDE)
            {
                XDrawArc(disp, pix, fgn, 0, 0, size+1, size+1, 0,360*64);
            }
            if (kind & PLAYER_COLLIDE)
            {
                XDrawArc(disp, pix, fgn, 0, 0, size+1, size+1, 0,360*64);
            }
        }

        double head_angle_rad = Deg2Rad(head_angle);
        int head_x = (int) (size/2 * (1 + sin(head_angle_rad)));
        int head_y = (int) (size/2 * (1 + cos(head_angle_rad)));
        if (kind & GOALIE) {
            XDrawLine(disp, pix, fgn_g, size/2, size/2, head_x, head_y);
        }
        else {
            XDrawLine(disp, pix, fgn, size/2, size/2, head_x, head_y);
        }

        XDrawString(disp, pix, fgs, pfont_x, pfont_y, unumstr,strlen(unumstr));
        XSetWindowBackgroundPixmap(disp, player, pix);
        XClearWindow(disp, player);

        ang = angle;
        prev_kind = kind;
    }

    if (pos_x != x || pos_y != y) {
        XMoveWindow( disp, player,
                     std::max( InFieldPosX((x/SHOWINFO_SCALE)) - size/2, 0 ),
                     std::max( InFieldPosY((y/SHOWINFO_SCALE)) - size/2, 0 )
                    );
        pos_x = x;
        pos_y = y;
        XFlush( disp );
    }
}

void
Player::destroy()
{
    XDestroyWindow(disp, player);
    XFreePixmap(disp, pix);
    XFreeGC(disp, fgh);
    XFreeGC(disp, fgt);
    XFreeGC(disp, fgs);
    XFreeGC(disp, bg);
    XFlush(disp);
    player = false;
}
