/* -*- Mode: C++ -*-
 *Header:
 *File: netif.C
 *Author: Noda Itsuki
 *Date: 1996/01/29
 *EndHeader:
 */

/*
 *Copyright:

 Copyright (C) 1996-2000 Electrotechnical Laboratory.
 Itsuki Noda, Yasuo Kuniyoshi and Hitoshi Matsubara.
 Copyright (C) 2000-2007 RoboCup Soccer Server Maintainance Group.
 Patrick Riley, Tom Howard, Daniel Polani, Itsuki Noda,
 Mikhail Prokopenko, Jan Wendler

 This file is a part of SoccerServer.

 This code is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


 *EndCopyright:
 */


#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

// [2000/01/14:I.Noda]
//  escape prototype of recvfrom
//  for escape conversion of signed-unsigned ints
#define recvfrom _escape_recvfrom
//

#include "netif.h"

#include "param.h"
#include "types.h"
#include "utility.h"
#include "object.h"
#include "field.h"

#include <sys/socket.h>

#if defined(HAVE_SYS_IOCTL_H)
#  include <sys/ioctl.h>
#elif defined(HAVE_SYS_FILIO_H)
#    include <sys/filio.h>
#else
#    error "system does not have <sys/ioctl.h> or <sys/filio.h>"
#endif

#ifdef HAVE_STRINGS_H
#  include <strings.h>
#endif


#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>

#include <cstdio>
#include <iostream>
#include <cerrno>
#include <cstring>
#include <cassert>

#include <X11/Intrinsic.h>

// [2000/01/14:I.Noda]
//  escape prototype of recvfrom
//  for escape conversion of signed-unsigned ints
#undef recvfrom
//  prototype of recvfrom for escape conversion of signed-unsigned ints
//
extern "C" {
    int recvfrom(int s, void *buf, int len, unsigned int flags,
                 struct sockaddr *from, SOCKLEN_T *fromlen);
};
//

struct PortImpl {

		struct sockaddr_in	serv_addr;			/* server addr structure */

};


/*
 *===================================================================
 *Part: Port
 *===================================================================
 */
Port::Port()
    : M_impl( new PortImpl )
{
    assert( M_impl );

    strcpy(host, "localhost");
    portnum = DEFAULT_PORT_NUMBER;
    version = 2;
}

Port::~Port()
{
    if ( M_impl )
    {
        delete M_impl;
        M_impl = static_cast< PortImpl * >( 0 );
    }
}

bool
Port::init()
{
    struct hostent		*host_ent;
    struct in_addr		*addr_ptr;
    struct sockaddr_in	cli_addr;

    if ((host_ent = (struct hostent *)gethostbyname(host)) == NULL) {
        /* Check if a numeric address */
        if (inet_addr(host) == 0)
            return false;
    }
    else{
        addr_ptr = (struct in_addr *) *host_ent->h_addr_list;
        strcpy(host,inet_ntoa(*addr_ptr));
    }

    /* Open UDP socket */
    if ((socketfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
        return false;	/* Can't open socket. */

    /* Bind any local address */
    //bzero((char *)&cli_addr, sizeof(cli_addr));
    memset((char *)&cli_addr, 0, sizeof(cli_addr));
    cli_addr.sin_family	= AF_INET;
    cli_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    cli_addr.sin_port = htons(0);

    if ( bind( socketfd, (struct sockaddr *)&cli_addr, sizeof(cli_addr)) < 0 )
    {
        return false;
    }

    /* Fill in the structure with the address of the server  */
    std::memset(( char *) &M_impl->serv_addr, 0, sizeof( M_impl->serv_addr ) );
    M_impl->serv_addr.sin_family = AF_INET;
    M_impl->serv_addr.sin_addr.s_addr	= inet_addr(host);
    M_impl->serv_addr.sin_port = htons(portnum);

    if ( version == 1 )
        return send_info("(dispinit)");
    else
    {
        char buf[32];
        std::snprintf ( buf, sizeof( buf ), "(dispinit version %d)", version );
        return send_info(buf);
    }
}

bool
Port::send_info(char *msg)
{
    int n = strlen(msg);

    if (sendto(socketfd, msg, n, 0,
               (struct sockaddr *)&M_impl->serv_addr, sizeof( M_impl->serv_addr )) != n)
        return false;

    return true;
}

char
Port::recv_info()
{
    int n;
    SOCKLEN_T  servlen;

    servlen = sizeof( M_impl->serv_addr );
    if (version == 1)
    {
        n = recvfrom(socketfd, (char *)(&rinfo), sizeof(rinfo), 0,
                     (struct sockaddr *)&M_impl->serv_addr, &servlen);

        return (n >= 0) ? ntohs(rinfo.mode) : NO_INFO;
    }
    else
    {
        n = recvfrom(socketfd, (char *)(&rinfo2), sizeof(rinfo2), 0,
                     (struct sockaddr *)&M_impl->serv_addr, &servlen);
        return (n >= 0) ? ntohs(rinfo2.mode) : NO_INFO;
    }
}
