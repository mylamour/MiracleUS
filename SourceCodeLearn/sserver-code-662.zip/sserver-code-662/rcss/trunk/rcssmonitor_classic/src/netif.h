/*
 *Header:
 *File: netif.h (for C++)
 *Author: Noda Itsuki
 *Date: 1996/01/29
 *EndHeader:
 */

/*
 *Copyright:

 Copyright (C) 1996-2000 Electrotechnical Laboratory.
 Itsuki Noda, Yasuo Kuniyoshi and Hitoshi Matsubara.
 Copyright (C) 2000-2007 RoboCup Soccer Server Maintainance Group.
 Patrick Riley, Tom Howard, Daniel Polani, Itsuki Noda,
 Mikhail Prokopenko, Jan Wendler

 This file is a part of SoccerServer.

 This code is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 *EndCopyright:
 */


#ifndef RCSSMONITOR_CLASSIC_NETIF_H
#define RCSSMONITOR_CLASSIC_NETIF_H

/* [I.Noda:2001.10.4] comment out to adapt configure
   #include <sys/socket.h>
   #ifdef	Solaris
   #define bcopy(a, b)	memset(a, 0, b)
   #include <sys/filio.h>
   #else
   #include <sys/ioctl.h>
   #endif
   #include <netinet/in.h>
   #include <arpa/inet.h>
   #include <netdb.h>
   #include <fcntl.h>
*/

#include "types.h"

/*
 *===================================================================
 *Part: Port class
 *===================================================================
 */
struct PortImpl;

class Port {
private:
    PortImpl * M_impl;
public:
		int					socketfd ;			/* socket discriptor */
		char				host[256] ;			/* server's host name */
		int					portnum ;			/* server's port number */
		dispinfo_t			rinfo ;				/* receive packet buffer */
		dispinfo_t2			rinfo2 ;				/* receive packet buffer */
		int			version;			/* monitor protocal version */

    Port();			/* constructor */
    ~Port();
		bool				init();
		bool				send_info(char *) ;
		char				recv_info();
};

#endif
