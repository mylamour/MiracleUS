/*
 *Header:
 *File: object.h (for C++)
 *Author: Noda Itsuki
 *Date: 1996/01/28
 *EndHeader:
 */

/*
 *Copyright:

 Copyright (C) 1996-2000 Electrotechnical Laboratory.
 Itsuki Noda, Yasuo Kuniyoshi and Hitoshi Matsubara.
 Copyright (C) 2000-2007 RoboCup Soccer Server Maintainance Group.
 Patrick Riley, Tom Howard, Daniel Polani, Itsuki Noda,
 Mikhail Prokopenko, Jan Wendler

 This file is a part of SoccerServer.

 This code is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 *EndCopyright:
 */


#ifndef RCSSMONITOR_CLASSIC_OBJECT_H
#define RCSSMONITOR_CLASSIC_OBJECT_H

#include "types.h"

#include <X11/Intrinsic.h>

class Field;

/*
 *===================================================================
 *Part: Ball class
 *===================================================================
 */
class Ball {
public:
		Display* disp;
		Window ball;
		short pos_x; /*!< x-position */
		short pos_y; /*!< y-position */
		double length_magnify; /*!< length magnify */

		void assign();
		void set( short, short );
};


/*
 *===================================================================
 *Part: Player class
 *===================================================================
 */
class Player {
public:
		Display* disp;
		Window win;
		Window player;
		short ang; /*!< angle */
		short pos_x; /*!< x-position */
		short pos_y; /*!< y-position */
		short prev_kind; /*!< prev kind (stand or kick) */
		short prev_stamina; /*!< prev stamina */
		Pixmap pix; /*!< pixmap structure */
		Dimension	size;	/*!< player size */
		double length_magnify;	/*!< length magnify */
		int pfont_x; /*!< uniform num pos x */
		int	pfont_y; /*!< uniform num pos y */
		GC fgh; /*!< for head */
		GC fgh_g; /*!< for goalie head */
		GC fgt; /*!< for tail */
		GC fgs; /*!< for string */
		GC fgn; /*!< for neck */
		GC fgn_g; /*!< for goalie neck */
		GC bg; /*!< for background */
		char name[128]; /*!< player name */
		char unumstr[3]; /*!<unum string */

		void assign( Side, Name, int, short );
		void destroy();
		void set( short, short, short, short, short, int, short = 0 );
};

#endif
