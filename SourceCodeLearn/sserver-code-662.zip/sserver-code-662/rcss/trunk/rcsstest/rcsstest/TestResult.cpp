
#include "TestResult.h"
#include "Failure.h"

#include <iostream>



void TestResult::testWasRun()
{
	testCount++;
}

void TestResult::startTests () 
{
}

void TestResult::addFailure (Failure failure) 
{
	failureCount++;
}

void TestResult::endTests () 
{
	using namespace std;

	cout << "There where " << testCount << " subtests run" << endl;
	if (failureCount > 0)
		cout << "There were " << failureCount << " failures" << endl;
	else
		cout << "There were no subtest failures" << endl;
}
