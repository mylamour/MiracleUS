

#include "Test.h"
#include "TestRegistry.h"
#include "TestResult.h"
#include <iostream>


Test::Test (const char* testName,
            const char* className )
    : name (testName),
      class_name( className )
{
	TestRegistry::addTest (this);
}


void Test::run (TestResult& result) 
{
	result.output() << result.indent() << "Running " << class_name << "-" << name << ":\n";
	runTest (result);
	result.testWasRun();
	result.output() << std::endl;
}
