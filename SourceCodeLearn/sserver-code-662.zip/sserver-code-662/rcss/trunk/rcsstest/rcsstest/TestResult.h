

#ifndef TESTRESULT_H
#define TESTRESULT_H

// TestResult is a simple little class which accepts notifications from
// tests.  In its current form, it takes these notifications and prints
// them on the standard output.
//
// If you need different behavior, you can alter it in place or subclass 
// TestResult to provide it.  The TestResult hierarchy can be as simple
// or complex as you require to support your application.

#if defined(_WIN32) || defined(__WIN32__) || defined(WIN32)
#ifdef RCSSTEST_EXPORTS
#define RCSSTEST_API __declspec(dllexport)
#define RCSSTEST_EXTERN
#else
#define RCSSTEST_API __declspec(dllimport)
#define RCSSTEST_EXTERN extern
#endif
#else
#define RCSSTEST_API
#define RCSSTEST_EXTERN
#endif

#include <iostream>
#include <string>

class RCSSTEST_API Failure;

class RCSSTEST_API TestResult
{
public:
	TestResult () 
		: failureCount (0),
	      testCount(0),
		  m_output( &std::cout ),
		  m_error( &std::cerr ),
		  m_indent( 0 )
	{}
	void testWasRun ();
	void startTests ();
	void addFailure (Failure failure);
	void endTests ();
    
    int testsRun() const
        { return testCount; }

    int testsFailed() const
        { return failureCount; }

    int testsSucceeded() const
        { return testCount - failureCount; }

	void setOutput( std::ostream& o )
	{
		m_output = &o;
	}

	void setError( std::ostream& o )
	{
		m_error = &o;
	}

	std::ostream&
	output()
	{ return *m_output; }

	std::ostream&
	error()
	{ return *m_error; }
	
	int
	setIndent( int indent )
	{
		return m_indent = indent;
	}
	
	int
	incIndent()
	{
		return ++m_indent;
	}
	
	int
	decIndent()
	{
		return --m_indent;
	}

	std::string
	indent()
	{
		std::string rval;
		for( int i = 0; i < m_indent; ++i )
			rval += " ";
		return rval;
	}
	
private:
	int failureCount;
	int testCount;
	std::ostream* m_output;
	std::ostream* m_error;
	int m_indent;
};

#endif
