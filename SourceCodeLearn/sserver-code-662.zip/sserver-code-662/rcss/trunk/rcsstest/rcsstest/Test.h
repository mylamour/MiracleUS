
#ifndef TEST_H
#define TEST_H

// Test is a base class for all tests.  It provides a command interface for
// running tests (run) as well as a data member for recording the name of 
// the test.
//
// Tests are constructed using the TEST macro.  TEST creates a subclass of
// Test and static instance of that subclass.  If you look at the constructor
// for the Test class, you'll notice that it registers the created object 
// with a global TestRegistry.  These features combine to make test creation
// particularly easy.

#if defined(_WIN32) || defined(__WIN32__) || defined(WIN32)
#ifdef RCSSTEST_EXPORTS
#define RCSSTEST_API __declspec(dllexport)
#define RCSSTEST_EXTERN 
#else
#define RCSSTEST_API __declspec(dllimport)
#define RCSSTEST_EXTERN extern
#endif
#elif defined(macintosh) || defined(__APPLE__) || defined(__APPLE_CC__)
#define RCSSTEST_API
#define RCSSTEST_EXTERN extern
#else
#define RCSSTEST_API
#endif

#include <iostream>
#include <string>

class RCSSTEST_API TestResult;


class RCSSTEST_API Test
{
public:
	Test( const char* testName,
		  const char* className );

    virtual ~Test() {}

	virtual void	run (TestResult& result);
	
	virtual void    runTest( TestResult& result) = 0;

	
protected:
	const char*		name;
	const char*		class_name;
};



#define TEST(testname,classUnderTest)\
	class classUnderTest##testname##Test : public Test\
	{ \
		public: \
			classUnderTest##testname##Test () : Test( #testname "SubTest", #classUnderTest "Test") {} \
			void runTest (TestResult& result_); \
			void doRunTest (TestResult& result_); \
	} classUnderTest##testname##Instance; \
	void classUnderTest##testname##Test::runTest (TestResult& result_) \
	{\
	    try{ doRunTest( result_ ); }\
		catch( const std::exception& e ) \
		{ \
            Failure fail( name, __FILE__, __LINE__); \
            result_.error() << fail << "an exception was thrown: " << e.what() << std::endl;\
			result_.addFailure( fail ); \
		} \
		catch(...)\
		{\
            Failure fail( name, __FILE__, __LINE__); \
            result_.error() << fail << "an unknown exception was thrown" << std::endl;\
			result_.addFailure( fail ); \
		}\
	}\
	void classUnderTest##testname##Test::doRunTest (TestResult& result_) \

	
// Here is a collection of testing macros that can be used in the 
// bodies of tests.  CHECK tests a boolean expression and records
// a failure if the expression evaluates to false.  CHECK_LONGS_EQUAL
// and CHECK_DOUBLES_EQUAL compare longs and doubles respectively.
//
// To make this an industrial strength test harness, you should
// add equals macros for various low level types as you develop them.
// If, for instance, you have a daterange class, the ability to compare
// them directly and print out their values in the test output is 
// invaluable.




#define CHECK(condition) \
{\
	result_.incIndent(); \
	result_.output() << result_.indent() << "checking " #condition "... "; \
	if ( !(condition) ) {\
		result_.output() << "false\n"; \
        Failure fail( name, __FILE__, __LINE__); \
        result_.error() << fail << "\"" << #condition << "\" should have evaluated to true\n"; \
		result_.addFailure( fail ); \
    }\
    else \
    { \
        result_.output() << "true\n"; \
    } \
	result_.decIndent(); \
}

#define CHECK_EXCEPTION_BEGIN \
	result_.incIndent(); \
	result_.output() << result_.indent() << "checking exception(s)...\n"; \
	try \


#define CHECK_EXPECTED_EXCEPTION( except ) \
	catch( const except& ) \
	{ \
		result_.incIndent(); \
		result_.output() << result_.indent() \
				 << "checking for expected exception " \
				 << #except << "... true\n"; \
	    result_.decIndent(); \
	} \

#define CHECK_UNEXPECTED_EXCEPTION( except ) \
	catch( const except& e ) \
	{ \
		result_.incIndent(); \
		result_.output() << result_.indent() << "checking for no " << #except << "exception(s)... false\n"; \
        Failure fail( name, __FILE__, __LINE__); \
        result_.error() << fail << "an unexpected exception was thrown: " << e.what() << std::endl;\
		result_.addFailure ( fail ); \
		result_.decIndent();\
	}

#define CHECK_NO_EXCEPTION \
	result_.incIndent(); \
	result_.output() << result_.indent() << "checking for exception(s)... false\n"; \
    Failure fail( name, __FILE__, __LINE__ );\
    result_.error() << fail << "expected exception\n"; \
	result_.addFailure ( fail ); \
	result_.decIndent()

#define CHECK_EXCEPTION_END \
	result_.output() << result_.indent() << "... end checking exception(s)\n"; \
	result_.decIndent()

#define CHECK_EQUAL(expected,actual)\
{\
	result_.incIndent(); \
	result_.output() << result_.indent() << "checking " << #actual << " equals " << #expected << "... "; \
	if( !(expected == actual )) {\
		result_.output() << "false\n"; \
        Failure fail( name, __FILE__, __LINE__); \
        result_.error() << fail << "expected " << expected << "but was: " << actual << std::endl; \
		result_.addFailure( fail ); \
	}\
    else \
    { \
        result_.output() << "true\n"; \
    } \
	result_.decIndent(); \
}

#define CHECK_LONGS_EQUAL(expected,actual)\
{\
	long _expected = (expected);\
	long _actual = (actual);\
	result_.incIndent(); \
	result_.output() << result_.indent() << "checking " << #actual << " equals " << _expected << "... "; \
	if (_expected != _actual) {\
		result_.output() << "false\n"; \
        Failure fail( name, __FILE__, __LINE__); \
        result_.error() << fail << "expected " << _expected << " but was: " << _actual << std::endl; \
		result_.addFailure( fail );\
	}\
    else \
    { \
        result_.output() << "true\n"; \
    } \
	result_.decIndent(); \
}

#define CHECK_STRS_EQUAL(expected,actual)\
{\
	const std::string _expected = (expected);\
	const std::string _actual = (actual);\
	result_.incIndent(); \
	result_.output() << result_.indent() << "checking " #actual " equals \"" << _expected << "\"... "; \
	if ( _expected != _actual ) {\
		result_.output() << "false\n"; \
        Failure fail( name, __FILE__, __LINE__); \
        result_.error() << fail << "expected \"" << _expected << "\" but was: \"" << _actual << "\"\n"; \
		result_.addFailure( fail ); \
    }\
    else \
    { \
        result_.output() << "true\n"; \
    } \
	result_.decIndent(); \
}

#define CHECK_DOUBLES_EQUAL(expected,actual)\
{\
	double _expected = (expected);\
	double _actual = (actual);\
	result_.incIndent(); \
	result_.output() << result_.indent() << "checking \"" #actual "\" equals " << _expected << "... "; \
	if (fabs ((_expected)-(_actual)) / _expected > 0.001) {\
		result_.output() << "false\n"; \
        Failure fail( name, __FILE__, __LINE__); \
        result_.error() << fail << "expected " << expected << "but was: " << actual << std::endl; \
		result_.addFailure( fail ); \
	}\
    else \
    { \
        result_.output() << "true\n"; \
    } \
	result_.decIndent(); \
}



#endif



