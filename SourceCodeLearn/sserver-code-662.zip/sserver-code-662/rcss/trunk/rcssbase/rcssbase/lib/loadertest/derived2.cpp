// -*-c++-*-

/***************************************************************************
                  derived2.cpp  - Part of the rcss::LibLoader testing program
                             -------------------
    begin                : 28-Aug-2003
    copyright            : (C) 2003 by The RoboCup Soccer Server 
                           Maintenance Group.
    email                : sserver-admin@lists.sourceforge.net
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU GPL as published by the Free Software   *
 *   Foundation; either version 2 of the License, or (at your option) any  *
 *   later version.                                                        *
 *                                                                         *
 ***************************************************************************/

#include "base.hpp"
#include "../loader.hpp"
#include <iostream>

class Derived2
    : public Base
{
public:
    virtual ~Derived2() {}
    virtual int method() const { return 2; };

	static
    void
    destroy( Derived2* c )
    { delete c; }

	static
    Ptr 
    create()
    {
		return Ptr( new Derived2,
                    &destroy,
                    rcss::lib::Loader::loadFromCache( "libderived2" ) ); 
    }

};


RCSSLIB_INIT( libderived2 )
{ 
    Base::factory().reg( &Derived2::create, "derived2" );
    return true;
}

RCSSLIB_FIN( libderived2 )
{
    Base::factory().dereg( "derived2" );
}  
