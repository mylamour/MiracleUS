// -*-c++-*-

/***************************************************************************
                         addrtest.cpp  - A testing program
                             -------------------
    begin                : 13-Mar-2003
    copyright            : (C) 2003 by The RoboCup Soccer Server 
                           Maintenance Group.
    email                : sserver-admin@lists.sourceforge.net
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU LGPL as published by the Free Software  *
 *   Foundation; either version 2 of the License, or (at your option) any  *
 *   later version.                                                        *
 *                                                                         *
 ***************************************************************************/

#include <TestHarness/TestHarness.h>
#include "rcssbase/net/addr.hpp"
#include "rcssbase/net/exception.hpp"

int main( int argc, char **argv )
{
    TestResult tr;
    TestRegistry::runAllTests(tr);
    if( tr.testsFailed() )
    {
        return -1;
    }
    return 0;
}

using namespace rcss::net;

TEST( Addr, defaultConstruction ) 
{
        Addr a;
        CHECK ( 0 == a.getPort() );
        CHECK ( 0 == a.getHost() );
}

TEST( Addr, PortOnlyConstruction ) 
{
        Addr a( 6000 );
        CHECK ( 6000 == a.getPort() );
        CHECK ( 0 == a.getHost() );
}

TEST( Addr, PortHostStrConstruction ) 
{
        Addr a( 6000, "localhost" );
        CHECK ( 6000 == a.getPort() );
        CHECK ( "localhost" == a.getHostStr() );
}

TEST( Addr, PortNullHostStrConstruction ) 
{
    try
    {
        Addr a( 6000, "" );
    }
    catch( const HostNotFound& e )
    {
        CHECK( true );
        return;
    }
    CHECK( false );
}

TEST( Addr, CopyConstruction ) 
{
        Addr a( 6000, "localhost" );
        Addr b( a );
        CHECK ( 6000 == b.getPort() );
        CHECK ( "localhost" == b.getHostStr() );
}

TEST( Addr, AddrConstruction ) 
{
        Addr a( 6000, "localhost" );
        Addr b( a.getAddr() );
        CHECK ( a.getPort() == b.getPort() );
        CHECK ( a.getHost() == b.getHost() ); 
}

TEST( Addr, PortHostConstruction ) 
{
        Addr a( 6000, "localhost" );
        Addr b( a.getPort(), a.getHost() );
        CHECK ( a.getPort() == b.getPort() );
        CHECK ( a.getHost() == b.getHost() );
}

TEST( Addr, Equality ) 
{
        Addr b( 6000, "localhost" ), a( 6000, "localhost" );
        CHECK ( a == b );
}


TEST( Addr, Assign ) 
{
        Addr b, a( 6000, "localhost" );
        b = a;
        CHECK ( a == b );
        CHECK ( a.getHostStr() == b.getHostStr() );
}

TEST( Addr, SelfAssign ) 
{
        Addr a( 6000, "localhost" );
        a = a;
        CHECK ( 6000 == a.getPort() );
        CHECK ( "localhost" == a.getHostStr() );
}


