#include "sim_config.h"
#ifdef HOSODA_ARM

#include "Hosoda_Arm.h"
#include <iostream>
#include <fstream>
#include <boost/thread.hpp>  
#include <boost/date_time.hpp> 
#include "GPR.h"
#include "Eigen/Dense"
#ifdef HOSODA_KINECT
	#include "InputKinect.h"
#endif
#ifdef REALTIME
	#include <rtai.h>
	#include <rtai_lxrt.h>
	#include <rtai_sched.h>
	#include <rtai_msg.h>
	#include <rtai_netrpc.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <sys/time.h>
#endif

using namespace Eigen;

Hosoda_Arm::Hosoda_Arm(int delayy, bool feedbackk, int esn_neurons, 
					   double spectral_radius, double input_scale, bool direct, 
					   int esn_step_timee, bool permutation){
	feedback = feedbackk;
	exit_thread = false;
	thread_stopped = false;
	delay = boost::posix_time::microseconds(delayy*1000);
	esn_step_time = boost::posix_time::microseconds(esn_step_timee*1000);
	esn_timer.start();

	int esn_input_dim = num_sensors;
	if(feedback) esn_input_dim += num_actuators;
	esn = new ESN(esn_neurons, spectral_radius, esn_input_dim, input_scale, 
				  direct, permutation);
	esn_state = new VectorXd(esn->dim_out());
	last_input = new VectorXd(esn_input_dim);

	if(logfiles){
		step_logfile.open("log/steptime_hosoda.log");
		hosoda_pos.open("log/hosoda_pos.log");
		delay_log.open("log/delay.log");
	}

	disp_goal[0] = 400;
	disp_goal[1] = 300;
	disp_goal[2] = 0;

	body_color << 1,1,0;
	arm_pos << 0,0,0;
	last_action = VectorXd::Ones(num_actuators)*0.1;
	goal_reached_bool = false;
	(*last_input) = VectorXd::Zero(esn_input_dim);

	#ifdef HOSODA_KINECT
		// red marker
		VectorXd lower_bound = Vector3d(170,100,100);
		VectorXd upper_bound = Vector3d(180,255,255);
		kinect = new InputKinect(lower_bound, upper_bound,logfiles);
	#endif
	
	arm_sock.initializeSocket("192.168.102.201",6818);
	int msg = arm_sock.writeToSock("c(0)", 4);
	std::cout << "ArmMsg: " << msg << std::endl;

	#ifndef HOSODA_KINECT
		vision_sock.initializeSocket("192.168.2.38",49002);
		msg = vision_sock.writeToSock("@incGPR_ESN blob.right +;", 25);
		std::cout << "VisionMsg: " << msg << std::endl;
	#endif


	boost::thread * simThread = new boost::thread(simLoop);
	boost::unique_lock<boost::mutex> lock(mutex_all);
	initialized.wait(lock);
	sim_thread = simThread;
	boost::this_thread::at_thread_exit(stop);
	std::cout << "Thread created" << std::endl;
}

void Hosoda_Arm::get_actuator_range(MatrixXd &actuator_ranges){
	actuator_ranges.array() *= 0;
	actuator_ranges.col(0).array() += 0.1;
	// up to 0.7 but use 0.3 for test purposes
	actuator_ranges.col(1).array() += 0.5;
}

int Hosoda_Arm::get_number_actuators(){
	return num_actuators;
}

int Hosoda_Arm::get_number_sensors(){
	return esn->dim_out();
}

void Hosoda_Arm::get_sensors(VectorXd &sensors){
	mutex_all.lock();
	sensors = (*esn_state);
	mutex_all.unlock();
}

void Hosoda_Arm::get_pos(VectorXd &position){
	mutex_all.lock();
	position = arm_pos;
	#ifndef HOSODA_KINECT
		position *= 0.01;
	#endif
	mutex_all.unlock();
}

void Hosoda_Arm::set_actuators(const VectorXd &values){
	mutex_all.lock();
	last_action = values;
	action_queue.push(values);
	delay_queue.push(boost::posix_time::microsec_clock::universal_time());
	mutex_all.unlock();
}

void Hosoda_Arm::display_goal(VectorXd &goal){
	mutex_all.lock();
	disp_goal = goal;
	#ifndef HOSODA_KINECT
		disp_goal *= 100;
	#endif
	mutex_all.unlock();
}

void Hosoda_Arm::set_color(VectorXd &color){
	mutex_all.lock();
	body_color = color;
	mutex_all.unlock();
}

bool Hosoda_Arm::goal_reached(){
	mutex_all.lock();
	bool reached = goal_reached_bool;
	if(reached){
		goal_reached_bool = false;
	}
	mutex_all.unlock();
	return reached;
}

ESN & Hosoda_Arm::get_esn(){
	return (*esn);
}

boost::thread * Hosoda_Arm::get_thread(){
	return sim_thread;
}

void Hosoda_Arm::stop_sim(){
	exit_thread = true;
}

bool Hosoda_Arm::stopped(){
	return thread_stopped;
}

void Hosoda_Arm::pause(bool pause){
	paused = pause;
}

void Hosoda_Arm::get_goal(VectorXd & user_goal){
}

#endif
