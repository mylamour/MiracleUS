#include "Sim_Arm.h"
#include <iostream>
#include <fstream>
#include <ode/ode.h>
#ifdef VISUALIZE
	#include <drawstuff/drawstuff.h>
#endif
#include <boost/thread.hpp>  
#include <boost/date_time.hpp> 
#include "GPR.h"
#include "Eigen/Dense"
#include "SORN.h"
#ifdef REALTIME
	#include <rtai.h>
	#include <rtai_lxrt.h>
	#include <rtai_sched.h>
	#include <rtai_msg.h>
	#include <rtai_netrpc.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <sys/time.h>
#endif

using namespace Eigen;

Sim_Arm::Sim_Arm(int delayy, bool feedbackk, int esn_neurons, 
				 double spectral_radius, double input_scale, bool direct, 
				 int esn_step_timee, bool permutation, bool classicc, 
				 VectorXd & SORN_params){
	feedback = feedbackk;
	classic = classicc;
	exit_thread = false;
	thread_stopped = false;
	delay = boost::posix_time::microseconds(delayy*1000);
	esn_step_time = boost::posix_time::microseconds(esn_step_timee*1000);
	esn_timer.start();
	if(logfiles){
		classic_info = VectorXd::Zero(18);
		esn_states_log.open("log/esn_states.log");
		classic_states_log.open("log/classic_states.log");
		delay_log.open("log/delay.log");
	}

	int esn_input_dim = NUM_MUSCLES*(NUM_BODIES-1);
	if(feedback) esn_input_dim += NUM_MUSCLES*(NUM_BODIES-1);
	if(SORN_params.size() == 7){
		esn = new SORN(esn_neurons, spectral_radius, esn_input_dim, 
					   input_scale, direct, permutation, SORN_params);
	}
	else{
		esn = new ESN(esn_neurons, spectral_radius, esn_input_dim, input_scale, 
					  direct, permutation);
	}
	esn_state = new VectorXd(esn->dim_out());
	last_input = new VectorXd(esn_input_dim);

	lengths *= 0;
	hill_params *= 0;
	arm_pos *= 0;
	last_action *= 0;
	(*last_input) = VectorXd::Zero(esn_input_dim);

	if(logfiles){
		step_logfile.open("log/steptime_sim.log");
	}

	#ifdef VISUALIZE
		// setup pointers to drawstuff callback functions
		fn.version = DS_VERSION;
		fn.start = &start;
		fn.step = &simStepVisualize;
		fn.command = 0;
		fn.stop = &stop;
		fn.path_to_textures = "../ode-0.12/drawstuff/textures";
		step_timer.start();
		// Create Thread
		boost::thread* dsThread = new boost::thread(dsSimulationLoop,0,
													(char**)0,640,480,&fn);
		boost::unique_lock<boost::mutex> lock(mutex_all);
		initialized.wait(lock);
		sim_thread = dsThread;
	#else
		start();
		boost::thread * simThread = new boost::thread(simLoop);
		boost::unique_lock<boost::mutex> lock(mutex_all);
		initialized.wait(lock);
		sim_thread = simThread;
	#endif
	boost::this_thread::at_thread_exit(stop);
	std::cout << "Thread created" << std::endl;
}

void Sim_Arm::get_actuator_range(MatrixXd &actuator_ranges){
	actuator_ranges.array() *= 0;
	actuator_ranges.col(0).array() -= 0;
	actuator_ranges.col(1).array() += 1.0;
}

int Sim_Arm::get_number_actuators(){
	return NUM_MUSCLES*(NUM_BODIES-1);
}

int Sim_Arm::get_number_sensors(){
	if(classic){
		return 18;
	}
	return esn->dim_out();
}

void Sim_Arm::get_sensors(VectorXd &sensors){
	mutex_all.lock();
	if(classic){
		sensors = classic_info;
	}
	else{
		sensors = (*esn_state);
		//sensors += VectorXd::Random(sensors.size())*0.01;
		sensors = sensors.array().abs();
	}
	mutex_all.unlock();
}

void Sim_Arm::get_pos(VectorXd &position){
	mutex_all.lock();
	position = arm_pos;
	//position += VectorXd::Random(3)*0.01;
	mutex_all.unlock();
}

void Sim_Arm::set_actuators(const VectorXd &values){
	mutex_all.lock();
	last_action = values;
	action_queue.push(values);
	delay_queue.push(boost::posix_time::microsec_clock::universal_time());
	mutex_all.unlock();
}

void Sim_Arm::display_goal(VectorXd &goal){
	mutex_all.lock();
	disp_goal = goal;
	mutex_all.unlock();
}

void Sim_Arm::set_color(VectorXd &color){
	mutex_all.lock();
	body_color = color;
	mutex_all.unlock();
}

bool Sim_Arm::goal_reached(){
	mutex_all.lock();
	bool reached = goal_reached_bool;
	if(reached){
		goal_reached_bool = false;
	}
	mutex_all.unlock();
	return reached;
}

ESN & Sim_Arm::get_esn(){
	return (*esn);
}

boost::thread * Sim_Arm::get_thread(){
	return sim_thread;
}

void Sim_Arm::stop_sim(){
	exit_thread = true;
}

bool Sim_Arm::stopped(){
	return thread_stopped;
}

void Sim_Arm::pause(bool pause){
	paused = pause;	
}

void Sim_Arm::get_goal(VectorXd & user_goal){

}
