// Detect memory leaks
//#include <vld.h>

#include "sim_config.h"
#include <iostream>
#include "Eigen/Dense"
#include "ESN.h"
#include "CG_Min.h"
#include "Controller.h"
#include "IRobot.h"
#include "Dummy_Robot.h"
#include "GPR.h"
#ifdef HOSODA_ARM
	#include "Hosoda_Arm.h"
#elif defined AFFETTO
	#include "Affetto.h"
#else
	#include "Sim_Arm.h"
#endif
#include <vector>
#include <string>
#include <sstream>
#include <fstream>
#include <ctime>
#ifdef WIN32
	#include <process.h>
#endif

using Eigen::MatrixXd;

// global variable defined in sim_config.h
bool logfiles = true;

int main(int argc, char **argv)
{	unsigned seed = 100 * getpid() - time(0);
	//Set random seed (e.g. for ESN)
	srand(seed);

	std::cout << "Let's go!" << std::endl;
	// Parameters
	// number of learning steps
	int learn_steps = 200;
	// maximal number of parallel GPRs
	int num_GPRs = 3;
	// maximal observations per GPR (i.e. matrix size)
	int max_GPR_obs = 100;
	// set to 0 to not use esn
	int esn_neurons = 100;	
	// desired learning+prediction step time in milliseconds
	int step_time = 50;
	// esn step time in milliseconds
	int esn_step_time = 25;
	// number of observations used for hyperparameter optimization 
	// (size of covariance matrix)
	int opt_obs = 50;
	// in milliseconds
	int delay = 0;
	// prediction delay steps
	int delay_steps = 0;
	// number of parallel GPR-Readouts for prediction
	int num_predictions = 3;
	// amount of intial random exploration
	double rand_exploration = 0.5;
	// 0: all muscles always activated, 9: only few muscles activated per step
	int rand_sparse = 6;
	// number of steps with constant noise
	int rand_len = 10;
	// strength of perturbation of estimated actions in goal babbling
	double perturbation = 0.5;
	// spectral radius of ESN
	double spectral_radius = 0.95;
	// scale of the input weights for the ESN
	double input_scale = 0.2;
	// if closeness between obs and center of all GPRs is smaller(->further 
	// away) than this > make new GPR (range: 0,hyper(1))
	double max_dist = 0.85;
	// minimal uncertainty in prediction to include new data point in 
	// covariance matrix
	double min_var = 0.1;
	// GPRs for different actuators share same covariance matrix 
	// (and same hypers)
	bool multi = true;
	// substitute old obs with max covariances by new one if GPR is full
	// (affects only second learning)
	bool substitute = true;
	// last action is input for ESN
	bool feedback = true;
	// sensor values (and actuators if feedback) are also directly used for 
	// readout
	bool direct = true;
	// Automatic Relevance Determination (i.e. hyperparameter optimization)
	bool ARD = false;
	// Optimize only global parameters (sigma(hyper0),theta(hyper1)) 
	// (ARD must be true for this to take any effect)
	bool global = false;
	// Use classic information, i.e. joing angles, velocities and accelerations
	bool classic = false;
	// Use intrinsic plasticity to optimize the ESN
	bool use_ip = true;
	// Use a permuted identity matrix instead of a random reservoir matrix
	bool permutation = false;
	// Use a SORN instead of a regular ESN
	bool SORN = false;
	// 0: linear kernel (->ridge regression); 1: exp. kernel; for simple linear 
	// regression, set to 0 and hyper(0) also to 0
	double kernel = 1;
	// loaded hyperparameters
	VectorXd loaded_hyper;
	// number of points to follow (lower->faster)
	int trajectory_size = 100;
	// Scale to inflate trajectory for training
	double trajectory_diff = 0;
	// name of file to save trajectorys
	std::string filename = "test";
	// name of rmse-accumulator
	std::string rmse_filename = "rmse";
	// nunmber of trials for mean-taking
	int repetitions = 1;
	// file to dump the ESN-matrices to
	std::string esn_file = "";
	// Parameters for the SORN. See SORN.h for details
	VectorXd SORN_params(7);
	SORN_params << 9, 9, 0.04, 0.4, 0.19, 2.5, 1;

	// Read parameters from file (filename = first command-line argument)
	if(argc == 2){
		std::ifstream parameters;
		parameters.open(argv[1]);
		string tmp1;
		if(!(parameters.good())){
			std::cout << "Could not open parameter file - using defaults" 
					  << std::endl;
		}
		while(parameters.good()){
			char line[10000];
			std::stringstream linestream;
			parameters.getline(line,9999);
			linestream << line;
			linestream >> tmp1;
			if(tmp1 == "num_GPRs") linestream >> num_GPRs;
			else if(tmp1 == "learn_steps") linestream >> learn_steps;
			else if(tmp1 == "max_GPR_obs") linestream >> max_GPR_obs;
			else if(tmp1 == "esn_neurons") linestream >> esn_neurons;
			else if(tmp1 == "step_time") linestream >> step_time;
			else if(tmp1 == "esn_step_time") linestream >> esn_step_time;
			else if(tmp1 == "opt_obs") linestream >> opt_obs;
			else if(tmp1 == "delay") linestream >> delay;
			else if(tmp1 == "delay_steps") linestream >> delay_steps;
			else if(tmp1 == "num_predictions") linestream >> num_predictions;
			else if(tmp1 == "rand_exploration") linestream >> rand_exploration;
			else if(tmp1 == "rand_sparse") linestream >> rand_sparse;
			else if(tmp1 == "rand_len") linestream >> rand_len;
			else if(tmp1 == "perturbation") linestream >> perturbation;
			else if(tmp1 == "spectral_radius") linestream >> spectral_radius;
			else if(tmp1 == "input_scale") linestream >> input_scale;
			else if(tmp1 == "max_dist") linestream >> max_dist;
			else if(tmp1 == "min_var") linestream >> min_var;
			else if(tmp1 == "multi") linestream >> multi;
			else if(tmp1 == "substitute") linestream >> substitute;
			else if(tmp1 == "feedback") linestream >> feedback;
			else if(tmp1 == "direct") linestream >> direct;
			else if(tmp1 == "ARD") linestream >> ARD;
			else if(tmp1 == "global") linestream >> global;
			else if(tmp1 == "kernel") linestream >> kernel;
			else if(tmp1 == "use_ip") linestream >> use_ip;
			else if(tmp1 == "permutation") linestream >> permutation;
			else if(tmp1 == "SORN") linestream >> SORN;
			else if(tmp1 == "SORN_lambda") linestream >> SORN_params(0);
			else if(tmp1 == "SORN_tau") linestream >> SORN_params(1);
			else if(tmp1 == "SORN_input") linestream >> SORN_params(2);
			else if(tmp1 == "SORN_mue") linestream >> SORN_params(3);
			else if(tmp1 == "SORN_inhsize") linestream >> SORN_params(4);
			else if(tmp1 == "SORN_inhthresh") linestream >> SORN_params(5);
			else if(tmp1 == "SORN_fermia") linestream >> SORN_params(6);
			else if(tmp1 == "classic") linestream >> classic;
			else if(tmp1 == "max_GPR_obs") linestream >> max_GPR_obs;
			else if(tmp1 == "trajectory_size") linestream >> trajectory_size;
			else if(tmp1 == "trajectory_diff") linestream >> trajectory_diff;
			else if(tmp1 == "filename") linestream >> filename;
			else if(tmp1 == "rmse_filename") linestream >> rmse_filename;
			else if(tmp1 == "repetitions") linestream >> repetitions;
			else if(tmp1 == "logfiles") linestream >> logfiles;
			else if(tmp1 == "esn_file") linestream >> esn_file;
			else if(tmp1 == "hypers"){
				double item;
				int size = 0;
				while(linestream >> item){
					loaded_hyper.conservativeResize(++size);
					loaded_hyper(size-1) = item;
				}
			}
			tmp1 = "";
		}
		parameters.close();
	}

	// If SORN is active, warmup and plasticity are neccessary
	if(SORN){
		use_ip = true;
	}
	else{
		SORN_params = VectorXd::Zero(1);
	}

	// Make Lissajous-Curves
	std::vector<VectorXd> learn_trajectory;
	for(int i=0; i<trajectory_size; i++){
		#ifdef TWO_ARMS
			VectorXd tra_tmp(6);
		#else
			VectorXd tra_tmp(3);
		#endif
		#ifdef HOSODA_KINECT
			tra_tmp(0) = 0.5 + (0.15+trajectory_diff)*sin(i*2*M_PI
								/(double)trajectory_size);
			tra_tmp(1) = 0.5 + (0.15+trajectory_diff)*sin(i*4*M_PI
								/(double)trajectory_size);//-M_PI/2);
			tra_tmp(2) = 0.56 + 0.0*sin(i*2*M_PI/(double)trajectory_size);
		#elif defined HOSODA_ARM
			tra_tmp(0) = 5 + (1+trajectory_diff)*sin(i*4*M_PI
								/(double)trajectory_size);
			tra_tmp(1) = 3.5 + (0.5+trajectory_diff)*sin(i*2*M_PI
								/(double)trajectory_size);//+M_PI/4);
			// Only 2D Information (Position always 0 per default)
			tra_tmp(2) = 0;
		#elif defined AFFETTO
			tra_tmp(0) = 0.35 + (0.08+trajectory_diff)*sin(i*4*M_PI
								/(double)trajectory_size);
			tra_tmp(1) = 0.5 + (0.08+trajectory_diff)*sin(i*2*M_PI
								/(double)trajectory_size);//-M_PI/2);
			tra_tmp(2) = 0.56 + 0.0*sin(i*2*M_PI/(double)trajectory_size);
			#ifdef TWO_ARMS
				tra_tmp(3) = tra_tmp(1)+0.15;
				tra_tmp(4) = tra_tmp(0)+0.15;
				tra_tmp(5) = tra_tmp(2);
			#endif
		#elif defined simple_arm
			tra_tmp(0) = 0.25 + (1+trajectory_diff)*sin(i*4*M_PI
								/(double)trajectory_size);
			tra_tmp(1) = 0.25 + (1+trajectory_diff)*sin(i*4*M_PI
								/(double)trajectory_size-M_PI/2);
			tra_tmp(2) = 0.8 + 0.0*sin(i*2*M_PI/(double)trajectory_size);
		#else
			tra_tmp(0) = 0.25 + (1+trajectory_diff)*sin(i*4*M_PI
								/(double)trajectory_size);
			tra_tmp(1) = 0.25 + (1+trajectory_diff)*sin(i*2*M_PI
								/(double)trajectory_size);//+M_PI/4);
			tra_tmp(2) = 1.0 + 0.0*sin(i*2*M_PI/(double)trajectory_size);
		#endif
		learn_trajectory.push_back(tra_tmp);
	}

	std::vector<VectorXd> test_trajectory;
	for(int i=0; i<trajectory_size; i++){
		#ifdef TWO_ARMS
			VectorXd tra_tmp(6);
		#else
			VectorXd tra_tmp(3);
		#endif
		#ifdef HOSODA_KINECT
			tra_tmp(0) = 0.5 + (0.1+trajectory_diff)*sin(i*2*M_PI
								/(double)trajectory_size);
			tra_tmp(1) = 0.5 + (0.1+trajectory_diff)*sin(i*4*M_PI
								/(double)trajectory_size);//-M_PI/2);
			tra_tmp(2) = 0.56 + 0.0*sin(i*2*M_PI/(double)trajectory_size);
		#elif defined HOSODA_ARM
			tra_tmp(0) = 5 + 1*sin(i*4*M_PI/(double)trajectory_size);
			tra_tmp(1) = 3.5 + 0.5*sin(i*2*M_PI/(double)trajectory_size);//+M_PI/4);
			// Only 2D Information (Position always 0 per default)
			tra_tmp(2) = 0;
		#elif defined AFFETTO
			tra_tmp(0) = 0.35 + 0.08*sin(i*4*M_PI/(double)trajectory_size);
			tra_tmp(1) = 0.5 + 0.08*sin(i*2*M_PI/(double)trajectory_size);//-M_PI/2);
			tra_tmp(2) = 0.56 + 0.0*sin(i*2*M_PI/(double)trajectory_size);
			#ifdef TWO_ARMS
				tra_tmp(3) = tra_tmp(1)+0.15;
				tra_tmp(4) = tra_tmp(0)+0.15;
				tra_tmp(5) = tra_tmp(2);
			#endif
		#elif defined simple_arm
			tra_tmp(0) = 0.25 + 0.75*sin(i*4*M_PI/(double)trajectory_size);
			tra_tmp(1) = 0.25 + 0.75*sin(i*4*M_PI
								/(double)trajectory_size-M_PI/2);
			tra_tmp(2) = 0.8 + 0.0*sin(i*2*M_PI/(double)trajectory_size);
		#else
			tra_tmp(0) = 0.25 + 1.0*sin(i*4*M_PI/(double)trajectory_size);
			tra_tmp(1) = 0.25 + 1.0*sin(i*2*M_PI/(double)trajectory_size);//+M_PI/4);
			tra_tmp(2) = 1.0 + 0.0*sin(i*2*M_PI/(double)trajectory_size);
		#endif
		test_trajectory.push_back(tra_tmp);
	}

	// Switch x and y for generalization
	std::vector<VectorXd> generalization_trajectory;
	for(int i=0; i<trajectory_size; i++){
		#ifdef TWO_ARMS
			VectorXd tra_tmp(6);
		#else
			VectorXd tra_tmp(3);
		#endif
		tra_tmp(0) = test_trajectory[i](1);
		tra_tmp(1) = test_trajectory[i](0);
		tra_tmp(2) = test_trajectory[i](2);
		#ifdef TWO_ARMS
			tra_tmp(3) = tra_tmp(1)+0.15;
			tra_tmp(4) = tra_tmp(0)+0.15;
			tra_tmp(5) = tra_tmp(2);
		#endif
		generalization_trajectory.push_back(tra_tmp);
	}

	std::vector<VectorXd> perturb_trajectory;
	for(int i=0; i<trajectory_size; i++){
		#ifdef TWO_ARMS
			VectorXd tra_tmp(6);
		#else
			VectorXd tra_tmp(3);
		#endif
		#ifdef HOSODA_KINECT
			tra_tmp(0) = 0.5 + (0.1+trajectory_diff)*sin(i*2*M_PI
								/(double)trajectory_size);
			tra_tmp(1) = 0.5 + (0.1+trajectory_diff)*sin(i*4*M_PI
								/(double)trajectory_size);//-M_PI/2);
			tra_tmp(2) = 0.56 + 0.0*sin(i*2*M_PI/(double)trajectory_size);
		#elif defined HOSODA_ARM
			tra_tmp(0) = 5 + 1*sin(i*4*M_PI/(double)trajectory_size);
			tra_tmp(1) = 3.5 + 0.5*sin(i*2*M_PI/(double)trajectory_size);//+M_PI/4);
			// Only 2D Information (Position always 0 per default)
			tra_tmp(2) = 0;
		#elif defined AFFETTO
			tra_tmp(0) = 0.35 + 0.1*sin(i*4*M_PI/(double)trajectory_size);
			tra_tmp(1) = 0.5 + 0.1*sin(i*2*M_PI/(double)trajectory_size);//-M_PI/2);
			tra_tmp(2) = 0.56 + 0.0*sin(i*2*M_PI/(double)trajectory_size);
			#ifdef TWO_ARMS
				tra_tmp(3) = tra_tmp(1)+0.15;
				tra_tmp(4) = tra_tmp(0)+0.15;
				tra_tmp(5) = tra_tmp(2);
			#endif
		#elif defined simple_arm
			tra_tmp(0) = 0.25 + 0.75*sin(i*4*M_PI/(double)trajectory_size);
			tra_tmp(1) = 0.25 + 0.75*sin(i*4*M_PI
								/(double)trajectory_size-M_PI/2);
			tra_tmp(2) = 0.8 + 0.0*sin(i*2*M_PI/(double)trajectory_size);
		#else
			tra_tmp(0) = 0.25 + 1.0*sin(i*4*M_PI/(double)trajectory_size);
			tra_tmp(1) = 0.25 + 0.0*sin(i*2*M_PI/(double)trajectory_size);//+M_PI/4);
			tra_tmp(2) = 1.0 + 0.0*sin(i*2*M_PI/(double)trajectory_size);
		#endif
		perturb_trajectory.push_back(tra_tmp);
	}
	
	std::stringstream description("#");
	double rmse1 = 0,rmse2 = 0, rmse3 = 0, rmse4 = 0;

	for(int rep = 0; rep<repetitions; rep++){
		std::cout << std::endl << std::endl << "repetition = " << rep+1 
				  << std::endl;

		if(classic){
			esn_neurons = 18;
		}

		#ifdef HOSODA_ARM
			Hosoda_Arm tmp_arm = Hosoda_Arm(delay,feedback,esn_neurons,
									  spectral_radius,input_scale,
									  direct,esn_step_time, permutation);
		#elif defined AFFETTO
			Affetto tmp_arm = Affetto(delay,feedback,esn_neurons,
									  spectral_radius,input_scale,
									  direct,esn_step_time, permutation,
									  SORN_params);
		#else
			Sim_Arm tmp_arm = Sim_Arm(delay,feedback,esn_neurons,
									  spectral_radius,input_scale,
									  direct,esn_step_time, permutation,
									  classic, SORN_params);
		#endif
		boost::thread * sim_thread = tmp_arm.get_thread();

		IRobot &robo = tmp_arm;

		//			  pos|  |theta,sigma  |kernel
		int hyper_size = 3 +2            +1 + esn_neurons;
		#ifdef TWO_ARMS
			hyper_size += 3; //position for two arms
		#endif
		if(direct){
			hyper_size += robo.get_esn().dim_out() - esn_neurons;
		}
		
		// Initial guess for hyperparameters
		std::vector<VectorXd> hypers;
		for(int i=0; i<robo.get_number_actuators(); i++){			
					  
			hypers.push_back(VectorXd::Ones(hyper_size));
			if(!ARD && (hyper_size == loaded_hyper.size())){
				hypers[i] = loaded_hyper;
			}
			else if(!ARD){
				std::cout << "Could not load hypers although ARD is off " 
						  <<hyper_size << " " << loaded_hyper.size() 
						  << std::endl;
			}
			if(ARD && global){
				hypers[i] = loaded_hyper;
				hypers[i].head(2) == VectorXd::Ones(2);
			}
			hypers[i](hyper_size-1) = kernel;
		}

		// Create controller with hyperparameters
		Controller contr(num_GPRs,max_GPR_obs,max_dist, 
						 &hypers,learn_trajectory, robo,step_time,delay_steps,
						 num_predictions, multi,rand_sparse, perturbation, 
						 rand_len, min_var);

		#ifdef TWO_ARMS
			VectorXd testpos = VectorXd::Zero(6);
		#else
			VectorXd testpos = VectorXd::Zero(3);
		#endif
		robo.get_pos(testpos);
		std::cout << "Pos: " << testpos.transpose() << std::endl;

		// Perform automatic relevance determination

		std::cout << "ESN Warmup" << std::endl;
		if(esn_neurons > 0){
			int warmup_steps = 1000;
			if(use_ip){
				#ifdef HOSODA_ARM
					warmup_steps = 5000;
				#else
					warmup_steps = 5000;
				#endif
			}
			contr.ESN_warmup((int)((double)esn_step_time/(double)step_time 
							* warmup_steps),esn_file, use_ip);
		}
		if(ARD){
			VectorXd mean_hyper = VectorXd::Zero(hypers[0].size());
			std::cout << "Start ARD" << std::endl;
			contr.ARD(opt_obs,global);
			if(multi){
				// Calculate mean hyperparameters
				for(int i=0; i<hypers.size(); i++){
					mean_hyper += hypers[i];
				}
				int index = 0;
				mean_hyper(index) /= hypers.size();
				index++;
				mean_hyper(index) /= hypers.size();
				index++;
				#ifdef HOSODA_ARM
					mean_hyper.segment(index,2) = 
						VectorXd::Ones(3)*
							mean_hyper.segment(index,2).mean() / hypers.size();
					mean_hyper(index+2) /= hypers.size();
				#else
					#ifdef TWO_ARMS
						mean_hyper.segment(index,6) = 
							VectorXd::Ones(6)*
							mean_hyper.segment(index,6).mean() / hypers.size();
					#else
						mean_hyper.segment(index,3) = 
							VectorXd::Ones(3)*
							mean_hyper.segment(index,3).mean() / hypers.size();
					#endif
				#endif
				#ifdef TWO_ARMS
						index += 3;
				#endif
				index += 3;
				// removed mean
				mean_hyper.segment(index,esn_neurons) = 
					VectorXd::Ones(esn_neurons).array()*
					mean_hyper.segment(index,esn_neurons).array() 
										/ hypers.size();
				index += esn_neurons;
				if(direct){
					int direct_size = robo.get_esn().dim_out()-esn_neurons;
					if(feedback){
						direct_size -= robo.get_number_actuators();
					}
					mean_hyper.segment(index,direct_size) = 
						VectorXd::Ones(direct_size)*
						mean_hyper.segment(index,direct_size).mean() 
											/ hypers.size();
					index += direct_size;
					if(feedback){
						mean_hyper.segment(index,robo.get_number_actuators()) = 
							VectorXd::Ones(robo.get_number_actuators())*
							mean_hyper.segment(index,
							robo.get_number_actuators()).mean()/hypers.size();
						index += robo.get_number_actuators();
					}
				}
				mean_hyper(hyper_size-1) = kernel;
			}
			std::cout << "Finished ARD" << std::endl;
			/*
			std::cout << "Estimated Hyperparameters:" << std::endl;
			int size = global?2:hypers[0].size();
			for(unsigned int i=0; i<hypers.size(); i++){
				for(int j=0;j<size;j++){
					std::cout << hypers[i](j) << " ";
				}
				std::cout << std::endl;
			}
			*/
			if(multi){
				//std::cout << "Mean Hyperparameters (used by multi):" 
				//		  << std::endl;
				//std::cout << mean_hyper.transpose() << std::endl;
				hypers[0] = mean_hyper;
			}
			// "Reheat" esn after ARD (inputs were the same for lots of steps)
			contr.ESN_warmup(300,"",false);
		}
		else{
			//std::cout << "Use loaded Hyperparameters: " << std::endl;
			//std::cout << hypers[0].transpose() << std::endl;
		}

		description.str("");
		description << "#"
				<< " learn_steps: " << learn_steps << " num: " <<num_GPRs
				<< " obs: " << max_GPR_obs << " neurons: " << esn_neurons 
				<< " step: "<< step_time << " esn_steps: " << esn_step_time 
				<< " opt_obs: " << opt_obs << " delay: " << delay 
				<< " delay_steps: "<< delay_steps 
				<< " pred: " << num_predictions 
				<< " expl: " << rand_exploration 
				<< " rand_sprase: " << rand_sparse 
				<< " perturbation: " << perturbation 
				<< " rand_len: " << rand_len << " classic: " << classic 
				<< " use_ip: " << use_ip << " permutation: " << permutation
				<< " SORN: " << SORN 
				<< " SORN_params: " << SORN_params.transpose()
				<< " radius: " << spectral_radius 
				<< " input_scale " << input_scale 
				<< " max_dist: " << max_dist << " min_var: " << min_var 
				<< " multi: "<< multi << " subst: " << substitute 
				<< " feedback: "<<feedback << " direct: " << direct 
				<< " kernel: "<< kernel <<" trasize: " << trajectory_size 
				<< " trajectory_diff: " << trajectory_diff
				<< " rep: " << repetitions 
				<< " mean_hyper: " << hypers[0].transpose();

		std::cout << std::endl << "Parameters:" << std::endl 
				  << description.str().c_str() << std::endl << std::endl;
		//std::cout << "Logfiles: " << logfiles << std::endl;

		// Learn with rand_exploration% of inital random exploration
		// Lissajous-Curve is used for goal babbling

		if(substitute){
			std::cout << "Start first learning (subst.)" << std::endl;
		}
		else{
			std::cout << "Start first learning (no subst.)" << std::endl;
		}
		contr.learn(learn_steps,rand_exploration,substitute);
		std::cout << std::endl << "Start first test" << std::endl;
		// Follow the Lissajous-Curve
		rmse1 += contr.follow(test_trajectory,5,filename+"1",
							  description.str());

		std::cout << "Start second learning (subst.)" << std::endl;
		contr.learn(learn_steps,0,true);
		std::cout << std::endl << "Start second test" << std::endl;
		rmse2 += contr.follow(test_trajectory,5,filename+"2",
							  description.str());

		std::cout << "Perform generalization test" << std::endl;
		rmse3 += contr.follow(generalization_trajectory,5,filename+"_Gen",
							  description.str());

		std::cout << "Perform perturbation test" << std::endl;
		rmse4 += contr.follow(perturb_trajectory,5,filename+"_Per",
							  description.str(),false,true);

		std::cout << "Done testing" << std::endl;

		#ifdef VISUALIZE
			//contr.follow(test_trajectory,100000,filename+"_Inter",
			//			 description.str(),true);
		#else
			tmp_arm.stop_sim();
			while(!(tmp_arm.stopped())) {
				boost::this_thread::sleep( 
					boost::posix_time::milliseconds(10));
			}
		#endif
		sim_thread->~thread();
		delete sim_thread;
	}
	std::ofstream rmse_ofstream;
	rmse_ofstream.open(std::string("log/"+
					   rmse_filename+".log").c_str(),std::ios_base::app);
	rmse_ofstream << description.str() << std::endl;
	rmse_ofstream << rmse1/(double)(repetitions) << " " 
				  << rmse2/(double)(repetitions) << " " 
				  << rmse3/(double)(repetitions) << " " 
				  << rmse4/(double)(repetitions) << std::endl;
	rmse_ofstream.close();
}

