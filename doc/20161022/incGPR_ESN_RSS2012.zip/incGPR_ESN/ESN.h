#ifndef ESN_H
#define ESN_H

#include "Eigen/Dense"
#include <fstream>

using Eigen::VectorXd;
using Eigen::MatrixXd;
using Eigen::ArrayXd;

/// <summary>Basic Echo State Network with intrinsic plasticity</summary>
class ESN{
	bool direct;
	int dim_in;
	VectorXd last_input;
protected:
	bool ip;
	std::ofstream log1;
	std::ofstream log2;
	double eta;
	double mue;
public:
	// State of the reservoir. Initially zero.
	VectorXd reservoir;
	// Weights are dense, random and scaled according to the spectral 
	// radius.
	MatrixXd weight_res_res;
	// (units x input)-matrix
	MatrixXd weight_inp_res;
	// Parameters for IP
	ArrayXd a;
	ArrayXd b;
	/// <param name="radius">Spectral radius</param>
	/// <param name="input_dim">Dimension of the input vector</param>
	/// <param name="input_scale">w_in is multiplied by this factor</param>
	/// <param name="direct">Output = Reservoir+Input</param>
	/// <param name="permutation">Use permutation matrix instead of random 
	/// W_res</param>
	ESN(int size, double radius, int input_dim, double input_scale, 
		bool direct, bool permutation);
	virtual void step(const VectorXd &input);
	void get_state(VectorXd &state) const;
	/// <summary>Turns IP-learning on</summary>
	void ip_on();
	/// <summary>Turns IP-learning off</summary>
	void ip_off();
	bool get_ip();
	int dim_out();
};

#endif