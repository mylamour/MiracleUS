#ifndef SORN_H
#define SORN_H

#include "ESN.h"
#include "Eigen/Dense"

using Eigen::VectorXd;
using Eigen::MatrixXd;
using Eigen::ArrayXd;

/// <summary>ESN adapted from the SORN paper by Lazar, Pipa, Triesch (2009)
/// </summary>
class SORN: public ESN{
	VectorXd inh_reservoir;
	// Average Number of outgoing connections/neuron
	int lambda;
	int input_units;
	double tau;
	double rate_stdp;
	double inh_thresh;
	double fermi_a;
	MatrixXd weight_inh_res;
	MatrixXd weight_res_inh;
	MatrixXd res_conn;
	VectorXd inh_b;
public:
	/// <param name="SORN_params"> 0: lambda, 1: tau, 2: inputunits(percent) 
	/// 3: mue, 4: inhibitoryunits(percent </param>
	SORN(int size, double radius, int input_dim, double input_scale, 
		 bool direct, bool permutation, VectorXd & SORN_params);
	void step(const VectorXd &input);
};

#endif