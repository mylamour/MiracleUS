#ifndef ONLINE_LEARNER_H
#define ONLINE_LEARNER_H

#include "GPR_inc_multi_Group.h"
class  GPR_inc_Group;

using Eigen::VectorXd;
using Eigen::MatrixXd;

/// <summary>Formats observations, goals and actions so that they can be 
/// learned by groups of local GPRs for each actuator. Uses goal babbling to
/// find training goals.</summary>
class Online_Learner{
	VectorXd current_goal;
	std::vector<VectorXd> goal_set;
	std::vector<VectorXd> *hyper_all;
	std::vector<GPR_inc_Group> GPRigs;
	GPR_inc_multi_Group GPRimg;
	int dim_input;
	int dim_out;
	int current_goal_index;
	double speed;
	bool multi;
	/// <summary>Combines state and pos in new vector fusion which can be fed
	/// into GPRs</summary>
	static void fuse(const VectorXd &state, const VectorXd &pos, 
					 VectorXd &fusion);
public:
	/// <param name="goal_sett">Matrix of goals for training. Each row 
	/// corresponds to one goal.</param>
	/// <param name="dim_input">Dimension of input, i.e. size of state + size 
	/// of pos</param>
	/// <param name="dim_outt">Dimension of output, i.e. number of 
	/// actuators</param>
	/// <param name="hyper_all">See controller.h</param>
	/// <param name="GPRs_max">Maximal number of GPRs</param>
	/// <param name="GPRs_size_max">Max number of observations in GP</param>
	/// <param name="GPRs_max_dist">If distance between new obs and closest GP 
	/// is larger than this value, a new GP is added</param>
	/// <param name="num_pred">Number of simultaneous predictions</param>
	/// <param name="multi">Use same hyperparameters for all GPs</param>
	/// <param name="predict_variance">Calculate the uncertainty of predictions
	/// </param>
	Online_Learner(std::vector<VectorXd> &goal_sett, int dim_inputt, 
				   int dim_outt, std::vector<VectorXd> *hyper_alll, 
				   int GPRs_max, int GPRs_size_max, double GPRs_max_dist, 
				   int num_pred, bool mutli, bool predict_variance);
	/// <summary>Computes next commands for actuators (alg2 in paper)</summary>
	/// <param name="state">State of robot, e.g. ESNstate+Sensors</param>
	/// <param name="pos">Position of robot/arm</param>
	/// <param name="goal">Goal position</param>
	/// <param name="action">Vector for the action to execute</param>
	/// <returns>Prediction uncertainty</returns>
	double execute(const VectorXd &state, const VectorXd &pos, 
				 const VectorXd &goal, VectorXd &action);
	/// <summary>Updates GPRs for every actuator and selects next action by 
	/// goal babbling. (alg1 in paper)</summary>
	void learn_step(const VectorXd &state_old, const VectorXd &pos_old, 
					const VectorXd &pos, const VectorXd &action_old, 
					bool substitute);
	/// <summary>Creates an observation for GPRs by combining the last state 
	/// with the position difference</summary>
	static void format_obs(const VectorXd &last_state, 
						   const VectorXd &last_pos, const VectorXd &pos, 
						   VectorXd &observation);
	/// <summary>Uses current position and robo information about 
	/// goal to determine wether a new goal should be selected and writes
	/// new goal into current_goal.</summary>
	void babble_goal(const VectorXd &pos, bool goal_reached);
	/// <summary>Writes the current goal in goal</summary>
	void get_current_goal(VectorXd &goal);
	void estimate_pred_time(boost::posix_time::microseconds &time);
	void print_GPR_sizes(std::string str="");
};

#endif