#include "sim_config.h"
#include <iostream>
#include <math.h>
#include "ESN.h"
#include "Eigen/Dense"
#include <ctime>


using namespace Eigen;

ESN::ESN(int size, double radius, int input_dim, double input_scale, 
		 bool directt, bool permutation):
	eta(0.001),mue(0.5),ip(true){
	// Initialize Random weights and reservoir
	direct = directt;
	dim_in = input_dim;
	last_input = VectorXd::Zero(dim_in);
	reservoir = VectorXd::Zero(size);
	if(size<=0){
		return;
	}
	if(permutation){
		weight_res_res = MatrixXd::Identity(size,size);
		VectorXd tmp(size);
		for(int i=0; i<size*100; i++){
			int rand1 = rand()%size;
			int rand2 = rand()%size;
			tmp = weight_res_res.row(rand1);
			weight_res_res.row(rand1) = weight_res_res.row(rand2);
			weight_res_res.row(rand2) = tmp;
		}
	}
	else{
		weight_res_res = MatrixXd::Random(size,size);
	}
	weight_inp_res = MatrixXd::Random(size,input_dim);
	a = ArrayXd::Ones(size)*1;
	b = ArrayXd::Ones(size)*0;
	// Scale input weights
	//weight_inp_res *= 0.2;
	weight_inp_res *= input_scale;
	// Scale reservoir according to radius
	weight_res_res *= radius / weight_res_res.eigenvalues().array()
							    .abs().maxCoeff();
	if(logfiles){
		log1.open("./log/esn_1.log");
		log2.open("./log/esn_2.log");
	}
}


void ESN::step(const VectorXd &input){
	last_input = input;
	if(reservoir.size() <= 0){
		return;
	}
	// Reservoir activations
	VectorXd x = weight_res_res*reservoir +	weight_inp_res*input;
	// Fermi function
	reservoir = (1.0+(-a*x.array()-b).exp()).inverse();
	// Intrinsic plasticity parameter update
	if(ip){
		ArrayXd db = eta * (1.0 - (2.0+1.0/mue) * reservoir.array() + 
							 reservoir.array().square()/mue);
		b += db;
		a += eta * a.inverse() + db*x.array();
		if(logfiles){
			log1 << a.transpose().head(3) << std::endl;
			log2 << b.transpose().head(3) << std::endl;
		}
	}
	else{
		if(logfiles){
			log1.close();
			log2.close();
		}
	}
}

void ESN::get_state(VectorXd &state) const{
	state.head(reservoir.size()) = reservoir;
	if(direct){
		state.tail(dim_in) = last_input;
	}
}

void ESN::ip_on(){
	ip = true;
}

void ESN::ip_off(){
	ip = false;
}

bool ESN::get_ip(){
	return ip;
}

int ESN::dim_out(){
	int dim_out = reservoir.size();
	if(direct){
		dim_out += dim_in;
	}
	return dim_out;
}
