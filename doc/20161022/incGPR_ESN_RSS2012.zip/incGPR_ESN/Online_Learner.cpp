#include "Online_Learner.h"
#include "GPR_inc_Group.h"
#include "GPR_inc_multi_Group.h"
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <math.h>

using namespace Eigen;

Online_Learner::Online_Learner(std::vector<VectorXd> &goal_sett, 
							   int dim_inputt, int dim_outt, 
							   std::vector<VectorXd> *hyper_alll, int GPRs_max, 
							   int GPRs_size_max, double GPRs_max_dist, 
							   int num_pred,
							   bool multii, bool predict_variance) : 
							   goal_set(goal_sett), dim_input(dim_inputt), 
							   dim_out(dim_outt), hyper_all(hyper_alll),
							   multi(multii), current_goal(goal_sett[0]), 
							   GPRimg(dim_outt, GPRs_max, GPRs_size_max, 
							   GPRs_max_dist, &((*hyper_alll)[0]),num_pred,
							   predict_variance){
	// Create GPR for each output
	for(int i=0; i<dim_out; i++){
		GPRigs.push_back(GPR_inc_Group::GPR_inc_Group(GPRs_max, GPRs_size_max, 
						 GPRs_max_dist,&((*hyper_alll)[i]), num_pred));
	}
	current_goal_index = 0;
}

double Online_Learner::execute(const VectorXd &state, const VectorXd &pos, 
							 const VectorXd &goal, VectorXd &action){
	VectorXd norm_goal_diff = (goal-pos);
	VectorXd fusion(dim_input);
	fuse(state,norm_goal_diff,fusion);
	if(!multi){
		for(int i=0; i<dim_out; i++){
			action[i] = GPRigs[i].predict(fusion);
		}
		return 1;
	}
	else{
		return GPRimg.predict(fusion,action);
	}

}

void Online_Learner::learn_step(const VectorXd &state_old, 
								const VectorXd &pos_old, const VectorXd &pos, 
								const VectorXd &action_old, bool substitute){
	VectorXd fusion(dim_input);
	format_obs(state_old,pos_old,pos,fusion);
	if(!multi){
		for(int i=0; i<dim_out; i++){
			GPRigs[i].inc_learn(fusion,action_old(i),substitute);
		}
	}
	else{
		GPRimg.inc_learn(fusion,action_old,substitute);
	}
}

void Online_Learner::fuse(const VectorXd &state, const VectorXd &pos, 
						  VectorXd &fusion){
	fusion.head(pos.size()) = pos;
	fusion.tail(state.size()) = state;
}

void Online_Learner::babble_goal(const VectorXd &pos, bool goal_reached){
	// Select randomly a new goal from the goal set 
	// (can be identical to old one)
	if(goal_reached || (speed >= 1.0)){
		current_goal_index += rand();
		current_goal_index %= goal_set.size();
		current_goal = goal_set[current_goal_index];
		speed = 0.0;
		if(goal_reached){
			std::cout << "Hit ";
		}
	}
	else{
		speed += 1/(3.0*dim_out);
	}

}

void Online_Learner::format_obs(const VectorXd &last_state, 
									   const VectorXd &last_pos,
									   const VectorXd &pos, 
									   VectorXd &observation){
	fuse(last_state, pos-last_pos, observation);
}

void Online_Learner::get_current_goal(VectorXd &goal){
	goal = current_goal;
}

void Online_Learner::estimate_pred_time(boost::posix_time::microseconds &time){
	if(multi){
		GPRimg.estimate_pred_time(time);
	}
	else{
		GPRigs[0].estimate_pred_time(time);
		time *= dim_out;
	}
}

void Online_Learner::print_GPR_sizes(std::string str){
	GPRimg.print_GPR_sizes(str);
}