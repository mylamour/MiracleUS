#include "GPR_inc.h"
#include <math.h>
#include <iostream>

using namespace Eigen;

GPR_inc::GPR_inc(VectorXd *hypers, int max_sizee) : GPR(hypers),
	max_size(max_sizee) {
	covar = MatrixXd(max_size, max_size);
	inv = MatrixXd(max_size, max_size);
}

void GPR_inc::inc_learn(const VectorXd &obss, const double targett){
	int oldsize = obs.size();
	if(oldsize >= max_size){
		return;
	}
	// Update observations and targets
	obs.push_back(obss);
	target.conservativeResize(target.size()+1);
	target.tail(1) = VectorXd::Ones(1)*targett;

	// Update Covariance Matrix
	VectorXd covar_new_old(oldsize);
	for(int i=0; i<oldsize; i++){
		covar_new_old(i) = kernel(obs[i], obss);
	}
	double self_covar = kernel(obss, obss) + (*hypers)(0);
	covar.block(0,oldsize,oldsize,1) = covar_new_old;
	covar.block(oldsize,0,1,oldsize) = covar_new_old.transpose();
	covar(oldsize,oldsize) = self_covar;
	if(oldsize == 0){
		inv(0,0) = 1.0 / self_covar;
	}
	else{
		// Update the inverse by block inversion
		// see http://en.wikipedia.org/wiki/Invertible_matrix
		double DCAB = 1.0 / (self_covar - covar_new_old.transpose()
												*inv.topLeftCorner(oldsize,
																	oldsize)
												*covar_new_old);
		MatrixXd AB = inv.topLeftCorner(oldsize,oldsize)*covar_new_old;
		MatrixXd CA = covar_new_old.transpose()*inv.topLeftCorner(oldsize,
																	oldsize);

		//Topleft block
		inv.topLeftCorner(oldsize,oldsize) += AB*DCAB*CA;
		
		//Topright block
		inv.block(0,oldsize,oldsize,1) = -AB*DCAB;
		inv.block(oldsize,0,1,oldsize) = -DCAB*CA;
		inv(oldsize,oldsize) = DCAB;
	}
	pre_predict = inv.topLeftCorner(oldsize+1,oldsize+1)*target;
	if(oldsize == 0){
		center = obs[0];
	}
	else{
		center = (center*(obs.size()-1)+obs[oldsize])/obs.size();
	}
}

void GPR_inc::substitute(const VectorXd &obss, const double targett, 
						 int del_obs){
	int oldsize = obs.size();
	center = (center*(oldsize)-obs[del_obs]+obss)/oldsize;
	obs[del_obs] = obss;
	target(del_obs) = targett;
	VectorXd covar_new_old(oldsize);
	for(int i=0; i<oldsize; i++){
		covar_new_old(i) = kernel(obs[i], obss);
	}
	covar_new_old(del_obs) += (*hypers)(0);

	// Update inverse by Sherman-Morrison rule
	// Update Row
	VectorXd u = VectorXd::Zero(oldsize);
	u(del_obs) = 1;
	VectorXd v = covar_new_old-covar.row(del_obs).transpose();
	sherman_morrison(u,v);
	// Update Col
	u = covar_new_old-covar.col(del_obs);
	u(del_obs) = 0; //already updated
	v *= 0;
	v(del_obs) = 1;
	sherman_morrison(u,v);

	covar.block(0,del_obs,oldsize,1) = covar_new_old;
	covar.block(del_obs,0,1,oldsize) = covar_new_old.transpose();

	//std::cout << (covar.topLeftCorner(oldsize,oldsize).inverse()-inv).sum() << std::endl;

	pre_predict = inv.topLeftCorner(oldsize,oldsize)*target;
}

void GPR_inc::get_center(VectorXd &centerr) const{
	centerr = center;
}

bool GPR_inc::full() const{
	return obs.size() >= (unsigned int)max_size;
}

int GPR_inc::max_covar_obs() const{
	//TODO change back
	int guesses = max_size;
	VectorXd covar_sums(guesses);
	VectorXi guess_index = VectorXi::Random(guesses).array().abs();
	for(int i=0; i<guesses; i++){
		//TOOD change back
		guess_index(i) = i;//guess_index(i)%covar.cols();
		covar_sums(i) = covar.col(guess_index(i)).sum();
	}
	int index;
	covar_sums.maxCoeff(&index);
	return guess_index(index);
}

void GPR_inc::sherman_morrison(const VectorXd &u, const VectorXd &v){
	inv -= (inv*u)*(v.transpose()*inv)/(1+v.transpose()*inv*u);
}