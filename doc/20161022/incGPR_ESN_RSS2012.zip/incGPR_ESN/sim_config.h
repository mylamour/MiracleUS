#ifndef SIM_CONFIG_H
#define SIM_CONFIG_H
// Define to visualize results with drawstuff (or opencv for Affetto)
#define VISUALIZE
// Define to use synchronized realtime loops (requires RTAI)
//#define REALTIME

// Define to use Hosoda arm (else simarm)
//#define HOSODA_ARM
//#define HOSODA_KINECT
// Define to use Affetto
//#define AFFETTO
// Define to use only the left or right Affetto-arm
//#define AFFETTO_RIGHT_ARM // LEFT or RIGHT
// Define to relax the affetto arm every couple of minutes to allow pressure regeneration
//#define RELAX
//full body motion with two arm tracking
//#define TWO_ARMS 
// use for only one segment
//#define simple_arm
// If nothing is defined, the regular complex_arm is used

extern bool logfiles;

#endif
