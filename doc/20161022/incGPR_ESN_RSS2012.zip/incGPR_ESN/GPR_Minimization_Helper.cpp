#include "Eigen/Dense"
#include "GPR.h"
#include "GPR_Minimization_Helper.h"

using namespace Eigen;

GPR_Minimization_Helper::GPR_Minimization_Helper(VectorXd *hyperr, 
	VectorXi opt_parameterss, std::vector<VectorXd> &observations, 
	VectorXd &target) : 
	GPR(hyperr, opt_parameterss), backup_obs(observations), 
	backup_tar(target){}

double GPR_Minimization_Helper::operator() (VectorXd &paramss){
	VectorXd params = (*hypers);
	// only update parameters to optimize
	for(int i=0;i<opt_parameters.size();i++){
		params(opt_parameters(i)) = paramss(i);
	}
	if(!((last_ll_hyper.array() == params.array()).all())){
		(*hypers) = params;
		batch_learn(backup_obs, backup_tar);
		log_likelihood();
	}
	// Maximizing ll by minimizing -ll
	return -last_ll;
}

void GPR_Minimization_Helper::df(VectorXd &paramss, VectorXd &deriv){
	VectorXd params = (*hypers);
	// only update parameters to optimize
	for(int i=0;i<opt_parameters.size();i++){
		params(opt_parameters(i)) = paramss(i);
	}
	if(!((last_llp_hyper.array() == params.array()).all())){
		(*hypers) = params;
		batch_learn(backup_obs, backup_tar);
		log_likelihood_prime(deriv);
	}
	// Maximizing ll by minimizing -ll [(-ll)' = -(ll)']
	deriv = -last_llp;
}