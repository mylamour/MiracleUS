#include "sim_config.h"
#include "Controller.h"
#include "CG_Min.h"
#include "ESN.h"
#include "GPR.h"
#include "Eigen/Dense"
#include "IRobot.h"
#include "GPR_Minimization_Helper.h"
#include <iostream>
#include <math.h>
#include <time.h>
#include <random>
#include <fstream>
#include "GPR_inc.h"
#include "GPR_inc_Group.h"
#include <boost/thread.hpp>
#include <boost/timer/timer.hpp>
#include <boost/date_time.hpp>
#include <vector>
#include <queue>
#include "Affetto.h"

#ifdef REALTIME
	#include <rtai.h>
	#include <rtai_lxrt.h>
	#include <rtai_sched.h>
	#include <rtai_msg.h>
	#include <rtai_netrpc.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <sys/time.h>
#endif


using namespace Eigen;

#ifdef REALTIME
	void Controller::create_rt_task(){
		double d = step_time.total_microseconds()*1e+3;
		// Enable non-root hrt
		rt_allow_nonroot_hrt();
		// Create realtime task
		if( 
		(rt_task2=rt_task_init_schmod(nam2num("LEARNTH"),20,1024,1024,
									  SCHED_FIFO, 2)) == NULL )
		{
			fprintf(stderr,"Failed to create the realtime task.\n");
			fprintf(stderr,"Make sure RTAI modules are inserted\n");
		}    
		rt_set_runnable_on_cpuid(rt_task2,2);
		// Start a timer anyhow
		if(!rt_is_hard_timer_running()){
			start_rt_timer( 0 );
			std::cout << "Timer Running" << rt_is_hard_timer_running()
					  <<std::endl;
		}
		// Configure the details of the timer
		if( rt_task_make_periodic_relative_ns(rt_task2, 0, d) != 0 ){
			fprintf(stderr,"Failed to configure the timer\n");
		}
	}
#endif

Controller::Controller(int GPRs_max, int GPRs_size, double GPRs_max_dist, 
					   std::vector<VectorXd> *actuator_hyperss,
					   std::vector<VectorXd> goal_set, IRobot &roboo, 
					   int step_timee, int delay_stepss, int num_pred,
					   bool multii, int rand_sparsee, double perturbationn,
					   int rand_lenn, double min_varr): 
					   robo(roboo), actuator_hypers(actuator_hyperss), 
					   relax_steps(0), ol(goal_set, 
					   (*actuator_hyperss)[0].size()-3,
					   (*actuator_hyperss).size(), actuator_hyperss, GPRs_max,
					   GPRs_size, GPRs_max_dist,num_pred, 
					   multii,(bool)min_varr), step_time(1000*step_timee),	
					   delay_steps(delay_stepss), max_pred_time(0), 
					   rand_sparse(rand_sparsee), perturbation(perturbationn),
					   rand_len(rand_lenn),min_var(min_varr){
	ol.estimate_pred_time(max_pred_time);
	max_pred_time += boost::posix_time::milliseconds(4);
	std::cout << "Estimated prediction time: " << max_pred_time << std::endl;
}


void Controller::ESN_warmup(int warmup_steps, std::string esn_file, 
							bool use_ip){
	std::fstream esn_dump;

	//Load Backup instead of Warmup
	if(esn_file != ""){
		try{
			esn_dump.open(esn_file.c_str(), std::ios_base::in);
			for(int line_index=0; line_index<5; line_index++){
				if(!esn_dump.good()){
					throw 1;
				}
				char line[1000001];
				std::stringstream linestream;
				esn_dump.getline(line,1000000);
				double tmp;
				std::string tmp1;
				linestream << line;
				if(line_index == 0){
					for(int i=0; i<robo.get_esn().reservoir.size(); i++){
						if(!linestream.good()) throw 1;
						linestream >> tmp;
						robo.get_esn().reservoir(i) = tmp;
					}
				}
				else if(line_index == 1){
					for(int i=0; i<robo.get_esn().a.size(); i++){
						if(!linestream.good()) throw 1;
						linestream >> tmp;
						robo.get_esn().a(i) = tmp;
					}
				}
				else if(line_index == 2){
					for(int i=0; i<robo.get_esn().b.size(); i++){
						if(!linestream.good()) throw 1;
						linestream >> tmp;
						robo.get_esn().b(i) = tmp;
					}
				}
				else if(line_index == 3){
					for(int i=0; i<robo.get_esn().weight_res_res.size(); i++){
						if(!linestream.good()) throw 1;
						linestream >> tmp;
						robo.get_esn().weight_res_res(i) = tmp;
					}
				}
				else if(line_index == 4){
					for(int i=0; i<robo.get_esn().weight_inp_res.size(); i++){
						if(!linestream.good()) throw 1;
						linestream >> tmp;
						robo.get_esn().weight_inp_res(i) = tmp;
					}
				}
			}
			esn_dump.close();
			robo.get_esn().ip_off();
			std::cout << "Loaded ESN. Skip warmup." << std::endl;
			return;
		}
		catch(int i){
			std::cout << "Could not read esn_file. Proceed with regular warmup. " 
					  << i << std::endl;
		}
		catch(...){
			std::cout << "Could not read esn_file. Proceed with regular warmup. " 
					  << std::endl;
		}
	}

	VectorXd action = VectorXd::Zero(robo.get_number_actuators());
	VectorXd last_action = VectorXd::Zero(robo.get_number_actuators());
	VectorXd sensors = VectorXd::Zero(robo.get_number_sensors());
	if(use_ip){
		robo.get_esn().ip_on();
	}
	else{
		robo.get_esn().ip_off();
	}

	boost::timer::cpu_timer step_timer;
	std::ofstream step_logfile;
	if(logfiles){
		step_logfile.open("log/steptime_contr_warmup.log");
	}
	#ifdef REALTIME
		create_rt_task();
	#endif
	step_timer.start();

	for(int step=0; step<warmup_steps; step++){
		// Echo State Network warmup
		random_action_add(action);
		action += last_action;
		check_action(action);
		last_action = action;
		robo.set_actuators(action);

		#ifdef REALTIME
			rt_task_wait_period();
		#else
			boost::this_thread::sleep(step_time - 
				boost::posix_time::microseconds((step_timer.elapsed().wall
												 /1000)));
		#endif
		if(logfiles){
			int time_warmup = step_timer.elapsed().wall/1000;
			step_timer.start();
			step_logfile << time_warmup << std::endl;
		}
		else{
			step_timer.start();
		}

	}
	// Turn off IP after warmup for constant training
	robo.get_esn().ip_off();
	if(logfiles){
		step_logfile.close();
	}
	#ifdef REALTIME
		rt_task_delete(rt_task2);
	#endif 

	//Dump ESN
	try{
		esn_dump.open("log/esn.dump",std::ios_base::out);
		esn_dump << robo.get_esn().reservoir.transpose() << std::endl;
		esn_dump << robo.get_esn().a.transpose() << std::endl;
		esn_dump << robo.get_esn().b.transpose() << std::endl;
		for(int col=0; col<robo.get_esn().weight_res_res.cols();col++){
			esn_dump << robo.get_esn().weight_res_res.col(col).transpose();
			esn_dump << " ";
		}
		esn_dump << std::endl;
		for(int col=0; col<robo.get_esn().weight_inp_res.cols();col++){
			esn_dump << robo.get_esn().weight_inp_res.col(col).transpose();
			esn_dump << " ";
		}
		esn_dump << std::endl;
		esn_dump.close();
	}
	catch(...){
		std::cout << "Could not dump ESN" << std::endl;
	}
}

void Controller::ARD(int max_step, bool global){
	std::vector<VectorXd> observations(max_step);
	for(unsigned int i=0; i<observations.size(); i++){
		observations[i] = VectorXd::Zero((*actuator_hypers)[0].size()-3);
	}
	std::vector<VectorXd> targets(robo.get_number_actuators());
	for(unsigned int i=0; i<targets.size(); i++){
		targets[i] = VectorXd::Zero(max_step);
	}
	VectorXd hyper_act;
	VectorXd action = VectorXd::Zero(robo.get_number_actuators());
	VectorXd sensors = VectorXd::Zero(robo.get_number_sensors());
	#ifdef TWO_ARMS
		VectorXd pos = VectorXd::Zero(6);
	#else
		VectorXd pos = VectorXd::Zero(3);
	#endif
	std::queue<VectorXd> previous_sensors;
	std::queue<VectorXd> previous_poss;
	std::queue<VectorXd> previous_acts; 
	VectorXd last_action = VectorXd::Zero(robo.get_number_actuators());
	VectorXd observation(observations[0].size());
	boost::timer::cpu_timer step_timer;
	std::ofstream step_logfile;
	if(logfiles){
		step_logfile.open("log/steptime_contr_ard.log");
	}
	#ifdef REALTIME
		create_rt_task();
	#endif
	step_timer.start();

	int learn_step = 0;
	for(int step=0; learn_step<max_step; step++){
		robo.get_sensors(sensors);
		robo.get_pos(pos);
		random_action_add(action);
		action += last_action;
		check_action(action);
		// Sleep the time needed later to predict next action
		boost::this_thread::sleep(max_pred_time - boost::posix_time::
				microseconds((step_timer.elapsed().wall/1000)));

		robo.set_actuators(action);
		// Sleep the time needed later to learn action
		#ifdef REALTIME
			rt_task_wait_period();
		#else
			boost::this_thread::sleep(step_time - 
				boost::posix_time::microseconds((step_timer.elapsed().wall
												 /1000)));
		#endif	
		if(logfiles){
			int time_ard = step_timer.elapsed().wall/1000;
			step_timer.start();
			step_logfile << time_ard << std::endl;
		}
		else{
			step_timer.start();
		}

		if(previous_poss.size() == delay_steps+1){
			ol.format_obs(previous_sensors.front(),previous_poss.front(),pos,
						  observation);
			observations[learn_step] = observation;
			for(unsigned int i=0; i<targets.size(); i++){
				targets[i][learn_step] = previous_acts.front()[i];
			}
			previous_poss.pop();
			previous_sensors.pop();
			previous_acts.pop();
			learn_step++;
		}
		if(step!=0){
			previous_poss.push(pos);
			previous_sensors.push(sensors);
			previous_acts.push(action);
		}
		last_action = action;
	}
	if(logfiles){
		step_logfile.close();
	}
	#ifdef REALTIME
		rt_task_delete(rt_task2);
	#endif

	//Relax arm during optimization
	VectorXd relax_action = VectorXd::Zero(robo.get_number_actuators());
	check_action(relax_action);
	robo.set_actuators(relax_action);

	boost::this_thread::sleep(boost::posix_time::millisec(200));

	robo.pause(true);

	for(int i=0; i<robo.get_number_actuators(); i++){
		hyper_act = (*actuator_hypers)[i];
		if(!global){
			// Minimize the legthscales aka ARD		
			VectorXi opt_parameters1 = VectorXi::Zero(observations[0].size());
			for(int j=0; j<observations[0].size(); j++){
				opt_parameters1(j) = j+2;
			}
			GPR_Minimization_Helper gmh1(&hyper_act, opt_parameters1, 
										 observations, targets[i]);
			// Learn initial model to make first ll-evaluation possible
			gmh1.batch_learn(observations,targets[i]);
			CG_Min<GPR_Minimization_Helper> cgmin1(gmh1);
			VectorXd hyper_act_min1 = hyper_act.segment(2,
													   observations[0].size());
			try{
				hyper_act_min1 = cgmin1.minimize(hyper_act_min1);
			}
			catch(char *s){
				std::cout << s << std::endl;
			}
			for(int j=0; j<hyper_act_min1.size(); j++){
				hyper_act(opt_parameters1(j)) = hyper_act_min1(j);
			}
			(*actuator_hypers)[i] = hyper_act;
		}		

		// Minimize sigma+theta
		VectorXi opt_parameters2 = VectorXi::Zero(2);
		for(int j=0; j<2; j++){
			opt_parameters2(j) = j;
		}
		GPR_Minimization_Helper gmh2(&hyper_act, opt_parameters2, observations,
									 targets[i]);
		// Learn initial model to make first ll-evaluation possible
		gmh2.batch_learn(observations,targets[i]);
		CG_Min<GPR_Minimization_Helper> cgmin2(gmh2);
		VectorXd hyper_act_min2 = hyper_act.segment(0,2);
		try{
			hyper_act_min2 = cgmin2.minimize(hyper_act_min2);
		}
		catch(char *s){
			std::cout << s << std::endl;
		}
		for(int j=0; j<hyper_act_min2.size(); j++){
			hyper_act(opt_parameters2(j)) = hyper_act_min2(j);
		}
		(*actuator_hypers)[i] = hyper_act;
	}
	robo.pause(false);
}

void Controller::random_action_add(VectorXd &action_add) const{
	MatrixXd ranges = MatrixXd::Zero(robo.get_number_actuators(),2);
	action_add = VectorXd::Zero(robo.get_number_actuators());
	robo.get_actuator_range(ranges);
	for(int i=0; i<robo.get_number_actuators(); i++){
		if(rand()%10>=rand_sparse){
			// Generate rand number between -0.5 and +0.5
			double rand_d = (double)rand()/RAND_MAX - 0.5;
			// Adjust to range
			rand_d = rand_d*(ranges(i,1)-ranges(i,0));
			// Make change smaller
			//TODO remove
			#ifdef AFFETTO
				rand_d *= 0.5;
			#endif
			action_add[i] = rand_d;
		}
	}
}

void Controller::check_action(VectorXd &action) const{
	MatrixXd ranges = MatrixXd::Zero(robo.get_number_actuators(),2);
	robo.get_actuator_range(ranges);
	bool nanaction = false;
	for(int i=0; i<robo.get_number_actuators(); i++){
		if(action[i] > ranges(i,1)) action[i] = ranges(i,1);
		else if (action[i] < ranges(i,0)) action[i] = ranges(i,0);
		// check for NaN
		if(!((action[i] <= ranges(i,1)) && (action[i] >= ranges(i,0)))){
			action[i] = ranges(i,0);
			nanaction = true;
		}
	}
	if(nanaction){
		std::cout << "NaN-action: " << std::endl;
	}
}

void Controller::learn(int steps, double random_exploration, bool substitute){
	boost::timer::cpu_timer timer;
	VectorXd next_action(robo.get_number_actuators());
	VectorXd last_action = VectorXd::Zero(robo.get_number_actuators());
	VectorXd rand_action_add = VectorXd::Zero(robo.get_number_actuators());
	std::queue<VectorXd> previous_acts;
	std::queue<VectorXd> previous_poss;
	std::queue<VectorXd> previous_sensors;
	std::queue<double> previous_variances;
	VectorXd sensors = VectorXd::Zero(robo.get_number_sensors());
	VectorXd position;
	VectorXd curr_goal;
	VectorXd color(3);
	double progress;
	bool act_random = true;
	double variance;

	color << 0,1,1;
	robo.set_color(color);

	boost::timer::cpu_timer step_timer;
	std::ofstream step_logfile;
	std::ofstream variance_logfile;
	if(logfiles){	
		step_logfile.open("log/steptime_contr_learn.log");
		variance_logfile.open("log/variances.log");
	}

	#ifdef REALTIME
		create_rt_task();
	#endif
	step_timer.start();
	timer.start();
	for(int step=0; step<steps; step++){
		if(step%rand_len == 0){
			random_action_add(rand_action_add);
		}
		// Get position, sensors, esn-state and format it nicely
		robo.get_sensors(sensors);
		robo.get_pos(position);
		ol.babble_goal(position,robo.goal_reached());
		ol.get_current_goal(curr_goal);
		robo.display_goal(curr_goal);
		// Select next action depending on amount of steps passed
		progress = (double)step/(double)steps;
		variance = 1;
		if(act_random && progress > random_exploration){
			act_random = false;
			color << 0,1,0;
			robo.set_color(color);
			std::cout << std::endl << "End Random" << std::endl;
		}
		if(((step+1)%500 == 0) && (relax_steps == 0)){
			next_action = VectorXd::Zero(robo.get_number_actuators());
			relax_steps = 10;
			variance = 0;
			std::stringstream progress_message;
			progress_message << floor(100*progress) << "%  GPRs: ";
			ol.print_GPR_sizes(progress_message.str());

		}
		else if(relax_steps > 0){
			relax_steps--;
			next_action = VectorXd::Zero(robo.get_number_actuators());
			variance = 0;
		}
		else if(act_random){
			next_action = last_action+rand_action_add;
		}
		else{
			variance = ol.execute(sensors,position,curr_goal,next_action);
			next_action += perturbation*(rand_action_add);
		}

		check_action(next_action);
		boost::posix_time::microseconds pred_time((timer.elapsed().wall/1000));
		boost::posix_time::time_duration diff_pred = max_pred_time - pred_time;
		if(!(diff_pred.is_negative())){
			boost::this_thread::sleep(diff_pred);
		}
		else{
			std::cout << "Predicted too long: " << max_pred_time << " - " 
			<< pred_time << " = " << diff_pred << std::endl;
		}
		// Set Actuators
		robo.set_actuators(next_action);
		pred_time = boost::posix_time::microseconds(timer.elapsed().wall/1000);
		// Learn with the last state-pos-action pair
		timer.start();
		if(previous_sensors.size() == delay_steps+1){
			if(previous_variances.front() >= min_var){
				ol.learn_step(previous_sensors.front(),previous_poss.front(),
							  position,previous_acts.front(),substitute);
			}
			previous_sensors.pop();
			previous_acts.pop();
			previous_poss.pop();
			previous_variances.pop();
		}
		if(step!=0){
			previous_sensors.push(sensors);
			previous_acts.push(next_action);
			previous_poss.push(position);
			previous_variances.push(variance);
		}
		last_action = next_action;
		// Wait if still time left
		boost::posix_time::microseconds train_time((timer.elapsed().wall/
													1000));
		boost::posix_time::time_duration diff_train = step_time - pred_time
													  - train_time;
		if(diff_train.is_negative()){
			std::cout << std::endl << "Overtime: Pred(" << pred_time 
					  << ")+Train(" << train_time << "-Step("<< step_time
					  << ") = " << -diff_train << std::endl;
		}

		#ifdef REALTIME
			rt_task_wait_period();
		#else
		else{
			boost::this_thread::sleep(step_time - 
			boost::posix_time::microseconds((step_timer.elapsed().wall/1000)));
		}
		#endif
		if(logfiles){
			int time_train = step_timer.elapsed().wall/1000;
			step_timer.start();
			step_logfile << time_train << std::endl;
			variance_logfile << variance << std::endl;
		}
		else{
			step_timer.start();
		}
		timer.start();
	}
	if(logfiles){
		step_logfile.close();
		variance_logfile.close();
	}
	#ifdef REALTIME
		rt_task_delete(rt_task2);
	#endif
}

double Controller::follow(const std::vector<VectorXd> &trajectory, int times,
						std::string filename, std::string infostring, 
						bool interaction, bool perturb){
	VectorXd sensors = VectorXd::Zero(robo.get_number_sensors());
	VectorXd position;
	VectorXd next_action(robo.get_number_actuators());
	VectorXd goal;
	std::queue<VectorXd> previous_goals;

	boost::timer::cpu_timer step_timer;
	std::ofstream step_logfile;

	std::ofstream file;

	if(logfiles){
		step_logfile.open("log/steptime_contr_follow.log");

	}
	if(filename != ""){
		filename = "log/" + filename;
		filename += ".plt";

		try{
			file.open(filename.c_str());
		}
		catch(std::exception e){
			std::cout << "Problem opening file: "
						<< e.what() << std::endl;
		}
		if(file.good()){
			file << infostring << std::endl;
			file << "# step arm_x goal_x err_x arm_y goal_y err_y arm_z goal_z err_z ";
			#ifdef TWO_ARMS
				file << "#arm_x2 goal_x2 err_x2 arm_y2 goal_y2 err_y2 arm_z2 goal_z2 err_z2";
			#endif
			file << std::endl;
		}
	}
	#ifdef REALTIME
		create_rt_task();
	#endif
	step_timer.start();

	double error = 0;
	for(int i=0; i<trajectory.size()*times; i++){
		robo.get_pos(position);
		robo.get_sensors(sensors);
		goal = trajectory[i%trajectory.size()];
		if(interaction){
			// Doesnt change goal if no user interaction implemente
			robo.get_goal(goal);
		}

		ol.execute(sensors,position,goal,next_action);
		check_action(next_action);

		// Use same timing as in train
		boost::posix_time::microseconds pred_time((step_timer.elapsed().wall
												   /1000));
		boost::posix_time::time_duration diff_pred = max_pred_time - pred_time;
		if(!(diff_pred.is_negative())){
			boost::this_thread::sleep(diff_pred);
		}
		else{
			std::cout << "Predicted too long: " << max_pred_time << " - " 
			<< pred_time << " = " << diff_pred << std::endl;
		}

		// Perturb action by setting half of the actuators to max and the other 
		// half to min activation for 10 steps
		if(perturb && (i%trajectory.size() >= (trajectory.size() - 2))){
			MatrixXd ranges = MatrixXd::Zero(robo.get_number_actuators(),2);
			robo.get_actuator_range(ranges);
			for(int j=0; j<next_action.size(); j++){
				if(j%4 == 0){
					next_action(j) = ranges.col(1)(j);
				}
				else{
					next_action(j) = ranges.col(0)(j);
				}
			}
			//next_action = ranges.col(1);
			//next_action.head(ranges.col(1).size()/2) = ranges.col(0).head(ranges.col(1).size()/2);
			check_action(next_action);
		}
		robo.set_actuators(next_action);
		#ifdef REALTIME
			rt_task_wait_period();
		#else
			boost::this_thread::sleep(step_time - 
			boost::posix_time::microseconds((step_timer.elapsed().wall/1000)));
		#endif
		if(logfiles){
			int time_follow = step_timer.elapsed().wall/1000;
			step_timer.start();
			step_logfile << time_follow << std::endl;
		}
		else{
			step_timer.start();
		}
	
		if(previous_goals.size() == delay_steps +1){
			VectorXd prev_goal = previous_goals.front();
			previous_goals.pop();
			robo.display_goal(prev_goal);
			double e_x = fabs(position(0)-prev_goal(0));
			double e_y = fabs(position(1)-prev_goal(1));
			double e_z = fabs(position(2)-prev_goal(2));
			double tmp = e_x*e_x+e_y*e_y+e_z*e_z;
			#ifdef TWO_ARMS
				double e_x2 = fabs(position(3)-prev_goal(3));
				double e_y2 = fabs(position(4)-prev_goal(4));
				double e_z2 = fabs(position(5)-prev_goal(5));
				tmp += e_x2*e_x2+e_y2*e_y2+e_z2*e_z2;
			#endif
			error += sqrt(tmp);
			if(file.good()){
				file << i 
						<< " " << position(0) << " " << prev_goal(0) << " " << e_x
						<< " " << position(1) << " " << prev_goal(1) << " " << e_y
						<< " " << position(2) << " " << prev_goal(2) << " " << e_z;
				#ifdef TWO_ARMS
				file	<< " " << position(3) << " " << prev_goal(3) << " " << e_x
						<< " " << position(4) << " " << prev_goal(4) << " " << e_y
						<< " " << position(5) << " " << prev_goal(5) << " " << e_z;
				#endif
				file << std::endl;

			}
		}
		previous_goals.push(goal);
	}
	file.close();
	if(logfiles){
		step_logfile.close();
	}
	#ifdef REALTIME
		rt_task_delete(rt_task2);
	#endif
	double rmse = error/(trajectory.size()*times);
	std::cout << "################RMSE: " << rmse << std::endl;
	return rmse;
}
