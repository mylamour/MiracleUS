#include "sim_config.h"
#include "SORN.h"
#include <iostream>
#include "Eigen/Dense"

using namespace Eigen;

SORN::SORN(int size, double radius, int input_dim, double input_scale, 
			bool direct, bool permutation, VectorXd & SORN_params):
		ESN(size, radius, input_dim, input_scale, direct, permutation),
			rate_stdp(0.001){
		lambda = SORN_params(0);
		tau = SORN_params(1);
		input_units = SORN_params(2)*size;
		mue = SORN_params(3);
		int inh_size = SORN_params(4)*size;
		inh_thresh = SORN_params(5);
		fermi_a = SORN_params(6);
	
		if(!permutation){
			weight_res_res = MatrixXd::Random(size,size);
			weight_res_res = weight_res_res.array().abs();
		}
		
		// Create random weights in range [0,1]
		inh_reservoir = VectorXd::Zero(inh_size);
		inh_reservoir = inh_reservoir.array().abs();
		weight_res_inh = MatrixXd::Random(inh_size,size);
		weight_res_inh = weight_res_inh.array().abs();
		weight_inh_res = MatrixXd::Random(size,inh_size);
		weight_inh_res = weight_inh_res.array().abs();
		res_conn = MatrixXd::Ones(size,size);
		weight_inp_res = weight_inp_res.array().abs();

		// Select input units
		for(int i=0; i<(size-input_units); i++){
			weight_inp_res.row(rand()%size)*=0;
		}

		// Make network sparse
		for(int i=0; i<size; i++){
			for(int j=0; j<size; j++){
				if((rand()%size >= lambda)){
					weight_res_res(i,j) = 0;
					res_conn(i,j) = 0;
				}
				// No self-recurrent connections
				if((i == j)){
					weight_res_res(i,j) = 0;
					res_conn(i,j) = 0;
				}
			}
		}

		// Normalize weights
		for(int i=0; i<size; i++){
			double inpsum = weight_inp_res.row(i).sum(); 
			if(inpsum > 0){
				weight_inp_res.row(i) /= inpsum;
			}
			weight_res_res.row(i) /= weight_res_res.row(i).sum();
			weight_inh_res.row(i) /= weight_inh_res.row(i).sum();
			if(i<inh_size){
				weight_res_inh.row(i) /= weight_res_inh.row(i).sum();
			}
		}

		// Set random thresholds for inhibitory units
		// *2 to match threshold of regular b
		inh_b = VectorXd::Random(inh_size).array().abs()*(-inh_thresh*2);
		// TODO chagne to 2?!
		a.array() = VectorXd::Ones(size).array().abs()*(fermi_a);
		b.array() = VectorXd::Random(size).array().abs()*(-2);

		log1 << "# Active Reservoir Units" << std::endl;
		log2 << "# spectral radius" << std::endl;

		std::cout << "Average Connections/Neuron (excitatory): " 
				  << res_conn.sum()/res_conn.rows() << std::endl;
}
		
void SORN::step(const VectorXd &input){
	VectorXd old_reservoir;
	if(ip){
		// Needed for STDP
		old_reservoir = VectorXd(reservoir);
	}
	// Reservoir activations
	// Leaky Integrator Neuron
	VectorXd x = (1-1.0/(double)tau)*reservoir + (1.0/(double)tau)
				  *(weight_res_res*reservoir - (weight_inh_res*inh_reservoir) 
				  + weight_inp_res*input);
	// Set to 10 and -5 to get nice nonlinear curve in interval [0,1] to [0,1] 
	// (since weights are normalized, input can never be higher than 1
	//                       4											inh_b.array()
	inh_reservoir = (1.0 + (-fermi_a*(weight_res_inh*reservoir).array()-inh_b.array()).exp()).inverse();
	// Fermi function
	reservoir = (1.0+(-a*x.array()-b).exp()).inverse();

	// only use plasticity mechanisms during warmup
	if(ip){
		// STDP
		MatrixXd delta_weight =  rate_stdp*(reservoir*old_reservoir.transpose() 
										- old_reservoir*reservoir.transpose());
		delta_weight = delta_weight.array() * res_conn.array();
		double tmpmean = (double)delta_weight.array().abs().sum()
						 /(double)res_conn.sum();
		if(tmpmean > 0){
			delta_weight = delta_weight/tmpmean*rate_stdp;
		}
		weight_res_res += delta_weight;

		for(int i=0; i<reservoir.size(); i++){
			for(int j=0; j<reservoir.size(); j++){
				if(weight_res_res(i,j) < 0){
					weight_res_res(i,j) = 0;
				}
			}
		}

		// SN
		for(int i=0; i<reservoir.size(); i++){
			double sumtmp = weight_res_res.row(i).sum();
			if(sumtmp > 0){
				weight_res_res.row(i) /= sumtmp;
			}	
			if(sumtmp < 0.01){
				std::cout << "Sum smaller 0.01: " << sumtmp << std::endl;
			}
		}
		// Intrinsic plasticity parameter update
		ArrayXd db = eta * (1.0 - (2.0+1.0/mue) * reservoir.array() 
							+ reservoir.array().square()/mue);
		b += db;
		a += eta * a.inverse() + db*x.array();
	}
	if(logfiles){
		log1 << reservoir.sum() << " " 
			 << (weight_res_res.array()*weight_res_res.array()).sum() 
			 << std::endl;
		log2 << (reservoir.array() * reservoir.array()).sum() << std::endl;
	}
}