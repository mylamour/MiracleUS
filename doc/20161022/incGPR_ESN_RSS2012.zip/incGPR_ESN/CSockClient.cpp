#include "CSockClient.h"

CSockClient::CSockClient()
{}

CSockClient::~CSockClient()
{}

int CSockClient::initializeSocket(char* server_ip, int port)
{
	#ifdef WIN32
		WSADATA wsaData;
		int wsaret=WSAStartup(0x101,&wsaData);
	#endif

	// make socket
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	address.sin_family = AF_INET;
	address.sin_addr.s_addr = inet_addr(server_ip);
	address.sin_port = htons(port);
	len = sizeof(address);
	// connect
	int result =
	connect(sockfd, (struct sockaddr *)&address, (size_t)len);
	if(result == -1) {
	perror("can not connect");
	exit(1);
	}
	// regist for select
	FD_ZERO(&fds);
	FD_SET(sockfd, &fds);
	tv.tv_sec = 0;
	tv.tv_usec = 0;

	return 0;
}

int CSockClient::terminateSocket()
{
	#ifdef WIN32
		closesocket(sockfd);
	#else
		close(sockfd);
	#endif	
	return 0;
}

int CSockClient::writeToSock(const char* writeBuf, int size)
{
	#ifdef WIN32
		return send(sockfd, writeBuf, size,0);
	#else	
		return write(sockfd, writeBuf, size);
	#endif		
}

int CSockClient::readFromSock(char* readBuf, int size)
{
	#ifdef WIN32
		return recv(sockfd,readBuf,size,0);
		WSACleanup();
	#else
		return read(sockfd, readBuf, size);
	#endif
}

int CSockClient::readFromSockWithSelect(char* readBuf, int size)
{
	// tmp fd_set and timeval
	fd_set fdset;
	struct timeval tvout;

	memcpy(&fdset, &fds, sizeof(fd_set));
	memcpy(&tvout, &tv, sizeof(timeval));

	int n = select(sockfd+1, &fdset, NULL, NULL, &tvout);
	if(n == -1){
	// something error was caused
	perror("select");
	exit(-2);
	}else if(n == 0){
	// time out
	return -1;
	}else{
	return readFromSock(readBuf, size);
	}
	
	return 0;
}
