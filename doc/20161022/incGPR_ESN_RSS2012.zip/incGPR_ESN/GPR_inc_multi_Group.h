#ifndef GPR_INC_MULTI_GROUP_H
#define GPR_INC_MULTI_GROUP_H

#include "GPR_inc_multi.h"
#include "GPR_inc_Group.h"

using Eigen::VectorXd;
using Eigen::MatrixXd;

/// <summary>Collection of local incremental Gaussian Process Regressions.
/// multi-version. Adapted from Nguyen-tuongPetersLocalGPR2008.</summary>
class GPR_inc_multi_Group : public GPR_inc_Group{
	std::vector<GPR_inc_multi> GPRs;
	int dim_out;
	bool print_full;
public:
	/// <param name="max_GPRss">Maximal number of GPRs</param>
	/// <param name="max_sizee">Maximal number of obs per GPR</param>
	/// <param name="max_distt">Max distance between center of GPR and
	/// new observation to be included</param>
	/// <param name="predict_variance">Determines if predict returns the 
	/// prediction variance</param>
	GPR_inc_multi_Group(int dim_out, int max_GPRss, int max_sizee, double 
			max_distt, VectorXd *hyperr, int num_pred, bool predict_variance);
	/// <summary>Adds a new observation to the closest GPR or creates 
	/// new</summary>
	void inc_learn(const VectorXd &observation, const VectorXd &target, 
				   bool substitute);
	/// <summary>Predicts target by combining multiple GPRs and weighting them
	/// according to their kernel distance</summary>
	/// <returns>Prediction variance</returns>
	double predict(const VectorXd &observation, VectorXd &prediction);
	/// <summary>The estimated prediction time is for all actuators. 
	/// No multiplication neccessary here</summary>
	void estimate_pred_time(boost::posix_time::microseconds &time);
	void print_GPR_sizes(std::string str="");
};

#endif