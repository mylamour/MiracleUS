#ifndef DUMMY_ROBOT_H
#define DUMMY_ROBOT_H

#include "IRobot.h"

using Eigen::VectorXd;
using Eigen::MatrixXd;

/// <summary>Just a dummy class to make testing possible</summary>
class Dummy_Robot : public IRobot{
	int num_actuators;
	int num_sensors;
public:
	Dummy_Robot();
	void get_actuator_range(MatrixXd &actuator_ranges);
	int get_number_actuators();
	int get_number_sensors();
	void get_sensors(VectorXd &sensors);
	void set_actuators(const VectorXd &values);
	void get_pos(VectorXd &position);
	void display_goal(VectorXd &goal);
};

#endif