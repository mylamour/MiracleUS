#ifndef GPR_INC_MULTI_H
#define GPR_INC_MULTI_H

#include "GPR_inc.h"

using Eigen::VectorXd;
using Eigen::MatrixXd;

/// <summary>GPR with incremental learning for multiple outputs</summary>
class GPR_inc_multi : public GPR_inc{
	std::vector<VectorXd> targets;
	bool compute_variance;
public:
	/// <param name="max_size">Maximal number of observations</param>
	/// <param name="compute_variance">Determines if predict returns the 
	/// prediction variance</param>
	GPR_inc_multi(VectorXd *hypers, int max_size, int num_actuators,
				  bool compute_variance);
	/// <summary>Updates covariance matrix and inverse with the new 
	/// observation. Runtime for inversion is O(N^2)</summary>
	/// <param name="obs">Rowvector with the new observation</param>
	/// <param name="target">Targetvector for the observation</param>
	void inc_learn(const VectorXd &obs, const VectorXd & target);
	/// <returns>Prediction variance</returns>
	double predict(const VectorXd & obsNew, VectorXd & prediction);
	void substitute(const VectorXd &obs, const VectorXd &target, int del_obs);
};

#endif