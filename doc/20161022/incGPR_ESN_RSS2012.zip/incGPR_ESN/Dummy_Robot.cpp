#include "Dummy_Robot.h"
#include "Eigen/Dense"

using namespace Eigen;

Dummy_Robot::Dummy_Robot(){
	num_actuators = 1;
	num_sensors = 1;
}

void Dummy_Robot::get_actuator_range(MatrixXd &actuator_ranges){
	actuator_ranges = MatrixXd(num_actuators,2);
	actuator_ranges << 0.0, 1.0;
}

int Dummy_Robot::get_number_actuators(){
	return num_actuators;
}

int Dummy_Robot::get_number_sensors(){
	return num_sensors;
}

void Dummy_Robot::get_sensors(VectorXd &sensors){
	sensors = VectorXd::Zero(1);
}

void Dummy_Robot::set_actuators(const VectorXd &values){

}

void Dummy_Robot::get_pos(VectorXd &position){

}

void Dummy_Robot:: display_goal(VectorXd &goal){

}