#ifndef GPR_INC_GROUP_H
#define GPR_INC_GROUP_H

#include <vector>
#include "Eigen/Dense"
#include <boost/timer/timer.hpp>
#include <boost/date_time.hpp>

class GPR_inc;

using Eigen::VectorXd;
using Eigen::MatrixXd;


/// <summary>Collection of local incremental Gaussian Process Regressions.
/// Adapted from Nguyen-tuongPetersLocalGPR2008.</summary>
class GPR_inc_Group{
	std::vector<GPR_inc> GPRs;
protected:
	int GPRs_number;
	int max_size;
	int max_GPRs;
	int num_predictions;
	double max_dist;
	VectorXd *hypers;
public:
	/// <param name="max_GPRss">Maximal number of GPRs</param>
	/// <param name="max_sizee">Maximal number of obs per GPR</param>
	/// <param name="max_distt">Max distance between center of GPR and
	/// new observation to be included</param>
	/// <param name="hyperr">The hyperparameters</param>
	/// <param name="num_pred">The number of simultaneous predictions</param>
	GPR_inc_Group(int max_GPRss, int max_sizee, double max_distt, 
				  VectorXd *hyperr, int num_pred);
	/// <summary>Adds a new observation to the closest GPR or creates a 
	/// new one</summary>
	void inc_learn(const VectorXd &observation, const double target, 
				   bool substitute);
	/// <summary>Predicts target by combining multiple GPRs and weighting them
	/// according to their kernel distance</summary>
	/// <returns>The weighted prediction</returns>
	double predict(const VectorXd &observation);
	/// <summary>The estimated prediction time is only for one actuator -> 
	/// multiply with number of actuators/number of matrices</summary>
	void estimate_pred_time(boost::posix_time::microseconds &time);
};

#endif