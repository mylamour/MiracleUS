	/* //ESN TEST
	ESN esn(50,0.95,3);
	VectorXd input = VectorXd::Ones(3);
	VectorXd input0 = VectorXd::Zero(3);
	esn.step(input);
	std::cout << esn.get_state() << std::endl << "##########" << std::endl;
	for(int i=1; i<3000; i++){
		if (i%100 == 0){
			esn.step(VectorXd::Random(3));
			std::cout << esn.get_state() << std::endl << std::endl;
		} else{
			esn.step(input0);
		}
	//  std::cout<<esn.get_state().array().square()<<std::endl;
	}
	*/

/* CG_Min Test
struct funcd {
	double operator() (VectorXd &x){
		// evil hack
		if(x(2) < 0) x(2) = 0;//return (1-x(0))*(1-(0))+x(1)*x(1)*x(1)*x(1);
		return (1-x(0))*(1-x(0))+x(1)*x(1)*x(1)*x(1)+x(2);
	}
	void df(VectorXd &x, VectorXd &deriv){
		deriv(0) = 2.0*x(0)-2;
		deriv(1) = 4.0*x(1)*x(1)*x(1);
		if(x(2) <= 0){
			x(2) = 0;
			deriv(2) = 0;
		}
		else deriv(2) = 1;
	}
};

	funcd testfunc;
	CG_Min<funcd> CG_Min(testfunc);
	VectorXd p(3);
	p << 3.0, 
		 3.0,
		 3.0;
	try{
		p = CG_Min.minimize(p);
	}
	catch(char *str){
		std::cout << "Exception: " << str << std::endl;
	}
	std::cout << p << std::endl;
	std::cout << std::endl << "Cast Test" << std::endl;
	std::cout << (p.array() > 0.0001) << (p.array() > 0.0001).cast<double>() 
			  << p.array() * (p.array() > 0.0001).cast<double>() << std::endl;
	*/



	//MatrixXd &lscales = *(new MatrixXd(1,3));
	//lscales = MatrixXd::Ones(1,3);
	//delete &lscales;


	/* Test GPR
	MatrixXd obs = MatrixXd::Random(100,2)*2*M_PI;
	VectorXd tar = obs.col(0).array().sin() + obs.col(1).array().sin();
	VectorXd lscaless = VectorXd::Ones(2);
	VectorXd newObs = VectorXd::Ones(2)*-0.5;
	GPR gpr(1.0, 1.0, lscaless);
	gpr.batch_learn(obs,tar);
	std::cout << gpr.predict(newObs) << std::endl;
	*/

/*  Log param, ll, llp, sin
	std::ofstream logfile;
	logfile.open("log.dat");
	VectorXd params = actuator_hypers.row(actuator);
	VectorXd df = actuator_hypers.row(actuator);
	for(double i=0.001; i<50; i++){
		params(2) = i/50.0;	
		gmh.df(params,df);
		logfile << i/50.0 << " " << gmh(params) << " " << df(2) << " " << gmh.predict(testvector) << std::endl;
	}
	logfile.close();
*/

/*		// <Testcode>
		VectorXd input = VectorXd::Random(robo.get_number_sensors())*3.14;
		esn.step(input);
		esn.get_state(esn_state);
		observations.row(step).head(esn.get_neurons()) = esn_state;
		targets(step) = sin(old_input.array().sum());
		old_input = input;
		// </Testcode>
*/

	/* //TestCode for Testing
	// 4 200 0.001 
	GPR_inc_Group gprig(4,200,0.001,hyper_act);
	VectorXd state;
	for(int i=0;i<400;i++){
		VectorXd input = VectorXd::Random(robo.get_number_sensors())*3.14;
		esn.step(input);
		esn.get_state(state);
		gprig.inc_learn(state,sin(old_input.array().sum()));
		old_input = input;
	}

	 
	std::ofstream logfile;
	logfile.open("log.dat");
	for(int i=0; i<500; i++){
		VectorXd testinput = VectorXd::Random(robo.get_number_sensors())*3.14;
		esn.step(testinput);
		VectorXd tmp = VectorXd::Random(robo.get_number_sensors())*3.14;
		esn.step(tmp);
		esn.get_state(state);
		double test = gprig.predict(state);
		logfile << testinput.array().sum() << " " << test << " " << i << " " << abs(sin(testinput.array().sum())-test) << std::endl;
	}
	logfile.close();
	*/

/*	// Goal set
	MatrixXd goal_set(4,3);
	 // Goal Set for 2 Bodies
	goal_set <<  0.25,0.65,0.5,
				0.25,-0.15,0.5,
				0.65, 0.25,0.5,
				-0.15,0.25,0.5;
	 // Goal Set for 3 Bodies
	
	goal_set << 0.25,0.9,0.9,
				0.25,-0.4,0.9,
				0.9,0.25,0.9,
				-0.4,0.25,0.9;
	
	goal_set << 0.25, 1.2, 1.2,
				0.25, -0.8, 1.0,
				1.2, 0.25, 1.2,
				-0.8, 0.25, 1.0;
*/



/* // COM-Connection
	int   bStatus;
	DCB          comSettings;          // Contains various port settings
	COMMTIMEOUTS CommTimeouts;
	// Open COM port
	if ((comport = 
		 CreateFileA("\\\\.\\COM1",                // open com1:
					GENERIC_READ | GENERIC_WRITE, // for reading and writing
					0,                            // exclusive access
					NULL,                         // no security attributes
					CREATE_NEW, //OPEN_EXISTING,              
					FILE_ATTRIBUTE_NORMAL,
					NULL)) == INVALID_HANDLE_VALUE)
	{
		std::cout << "Could not open COM port" << std::endl;
	}
	// Set timeouts in milliseconds
	CommTimeouts.ReadIntervalTimeout         = 0; 
	CommTimeouts.ReadTotalTimeoutMultiplier  = 0; 
	CommTimeouts.ReadTotalTimeoutConstant    = 10;
	CommTimeouts.WriteTotalTimeoutMultiplier = 0;
	CommTimeouts.WriteTotalTimeoutConstant   = 10;
	bStatus = SetCommTimeouts(comport,&CommTimeouts);
	if (bStatus != 0)
	{
		// error processing code goes here
	}
	// Set Port parameters.
	// Make a call to GetCommState() first in order to fill
	// the comSettings structure with all the necessary values.
	// Then change the ones you want and call SetCommState().
	GetCommState(comport, &comSettings);
	comSettings.BaudRate = 460800;
	comSettings.StopBits = ONESTOPBIT;
	comSettings.ByteSize = 8;
	comSettings.Parity   = NOPARITY;
	comSettings.fParity  = FALSE;
	bStatus = SetCommState(comport, &comSettings);
	if (bStatus == 0)
	{
		// error processing code goes here
	}
	*/

	/*	
	int flag = 1;
	result = setsockopt(affetto_socket,           
								 IPPROTO_TCP,     
								 TCP_NODELAY,    
								 (char *) &flag,    
								 sizeof(int));
	*/
	
	
/*
	cv::Mat red = m_imgColor.clone();
	cv::Mat thresh = m_imgColor.clone();
	red.setTo(0);
	thresh.setTo(0);
	std::cout << m_imgColor.rows << "x" << m_imgColor.cols << "x" << m_imgColor.channels() << " vs " << thresh.channels() << std::endl;
		
	for(int i=0; i<red.cols; i++){
		for(int j=0; j<red.rows; j++){
			red.ptr<uchar>(j)[i] = m_imgColor.ptr<uchar>(j)[i*3+2];
		}
	}
	cv::threshold(red,thresh,150,255,cv::THRESH_BINARY);

	cv::Point3f coordinate3d(m_img3d.ptr<float>(j)[i * 3 + 0],
	m_img3d.ptr<float>(j)[i * 3 + 1], m_img3d.ptr<float>(j)[i * 3 + 2]);
		
	cv::Point3i coordinateC(m_imgColor.ptr<uchar>(j)[i * 3 + 0],
		m_imgColor.ptr<uchar>(j)[i * 3 + 1], m_imgColor.ptr<uchar>(j)[i * 3 + 2]);

	std::cout << coordinate3d << " " << thresh.ptr<bool>(j)[i] << " " << coordinateC << std::endl;
	*/

// IP and Activation for binary neurons
/*
	//Constructor
		thresh_e_max = 0.5;
		thresh_i_max = 1.0;
		thresh_e = VectorXd::Random(size);
		thresh_e = thresh_e.array().abs() * thresh_e_max;
		thresh_i = VectorXd::Random(inh_size);
		thresh_i = thresh_i.array().abs() * thresh_i_max;

	VectorXd old_inh(inh_reservoir);
	// Activation
	VectorXd tmpres = (weight_res_res*reservoir) - (weight_inh_res*inh_reservoir) + (weight_inp_res*input) - thresh_e;
	VectorXd tmpinh = weight_res_inh*reservoir - thresh_i;

	for(int i=0; i<reservoir.size(); i++){
		if(tmpres(i) > 0){
			reservoir(i) = 1;
		}
		else{
			reservoir(i) = 0;
		}
	}
	for(int i=0; i<inh_reservoir.size(); i++){
		if(tmpinh(i) > 0){
			inh_reservoir(i) = 1;
		}
		else{
			inh_reservoir(i) = 0;
		}
	}



		thresh_e = thresh_e.array() + rate_ip*(old_reservoir.array()-2*(double)input_units/(double)reservoir.size());
		//std::cout << old_reservoir.head(30).transpose() << std::endl;// << thresh_e.head(6).transpose() << std::endl << rate_ip*(old_reservoir.array()-2*(double)input_units/(double)reservoir.size()).head(6).transpose() << std::endl << std::endl;
		int under_zero = 0;
		for(int i=0; i<reservoir.size(); i++){
			if(thresh_e(i) > thresh_e_max){
				thresh_e(i) = thresh_e_max;
			}
			if(thresh_e(i) < 0){
				thresh_e(i) = 0;
				under_zero += 1;
			}
		}
*/	