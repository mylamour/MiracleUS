#ifndef SIM_ARM_H
#define SIM_ARM_H

#define dDOUBLE

#include "sim_config.h"
#include "Eigen/Dense"
#include <iostream>
#include <fstream>
#include <ode/ode.h>
#include "ESN.h"
#ifdef VISUALIZE
	#include <drawstuff/drawstuff.h>
#endif
#include "IRobot.h"
#include <boost/thread.hpp>  
#include <boost/timer/timer.hpp>
#include <queue>
#ifdef REALTIME
	#include <rtai.h>
	#include <rtai_lxrt.h>
	#include <rtai_sched.h>
	#include <rtai_msg.h>
	#include <rtai_netrpc.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <sys/time.h>
#endif

using Eigen::VectorXd;
using Eigen::MatrixXd;
using Eigen::Matrix;

#ifdef _MSC_VER
#pragma warning(disable:4244 4305)  // for VC++, no precision loss complaints
#endif

// select correct drawing functions
#ifdef dDOUBLE
#define dsDrawBox dsDrawBoxD
#define dsDrawCapsule dsDrawCapsuleD
#define dsDrawSphere dsDrawSphereD
#define dsDrawLine dsDrawLineD
#endif


// some constants
#define SIDE 0.5	// side length of a box
#define RADIUS 0.25
#define SIDE_SMALL 0.025	// side length of a box
// 2body --> weight = 0.1 works good
#define MASS 1.0	// mass of a box
#define MASS_SMALL 0.001 // small boxes
#define RADIUS_GOAL 0.1 //CHANGED from 0.3
#define NUM_MUSCLES 4 // up to 4
#ifdef simple_arm
		#define NUM_BODIES 2 // up to what the computer can handle
#else
		#define NUM_BODIES 4
#endif
#define SIM_STEP 0.005
#define HILL_A 375.0 //375
#define HILL_B 1.0  //1
#define HILL_C 750.0 //750

struct muscle{
	dBodyID body_1;
	dBodyID body_2;

	dReal vectorB1ToB2(dVector3 &returnVector){
		const dReal *pos2 = dBodyGetPosition(body_2);
		const dReal *pos1 = dBodyGetPosition(body_1);
		returnVector[0] = pos2[0]-pos1[0];
		returnVector[1] = pos2[1]-pos1[1];
		returnVector[2] = pos2[2]-pos1[2];
		//normalize
		dReal length = sqrt(returnVector[0]*returnVector[0]+returnVector[1]
							*returnVector[1]+returnVector[2]*returnVector[2]);
		returnVector[0] /= length;
		returnVector[1] /= length;
		returnVector[2] /= length;
		return length;
	}

	dReal hill(dReal speed){
		return (HILL_C / (speed + HILL_B) - HILL_A);
	}
};

// global variables for thread communication
static boost::mutex mutex_all;
static boost::condition_variable initialized;
static bool goal_reached_bool;
static Matrix<double,(NUM_BODIES-1)*NUM_MUSCLES,1> lengths;
static Matrix<double,3,1> arm_pos;
static Matrix<double,(NUM_BODIES-1)*NUM_MUSCLES,1> last_action;
static Matrix<double,(NUM_BODIES-1)*NUM_MUSCLES,1> hill_params;
static Matrix<double,3,1> disp_goal;
static Matrix<double,3,1> body_color;
static std::queue<VectorXd> action_queue;
static std::queue<boost::posix_time::ptime> delay_queue;
static boost::posix_time::microseconds delay(0);
static ESN *esn;
static boost::posix_time::microseconds esn_step_time(0);
static boost::timer::cpu_timer esn_timer;
static bool feedback;
static VectorXd * esn_state;
static boost::thread * sim_thread;
static bool exit_thread(false);
static bool thread_stopped(false);
static boost::timer::cpu_timer step_timer;
static std::ofstream step_logfile;
static bool classic;
static Matrix<double,(NUM_BODIES-1)*3*2,1> classic_info;
static std::ofstream esn_states_log;
static std::ofstream classic_states_log;
static bool paused(false);
static std::ofstream delay_log;
static boost::timer::cpu_timer global_timer;
static VectorXd * last_input;

// dynamics and collision objects
static dWorldID world;
static dBodyID body[NUM_BODIES];
static dBodyID body_small[(NUM_BODIES-1)*2*NUM_MUSCLES];
static dBodyID pos_marker;
static dJointID universals[NUM_BODIES-1];
static dJointID hinges[(NUM_BODIES-1)*2*NUM_MUSCLES];
static dJointID pos_hinge;
static muscle muscles[(NUM_BODIES-1)*NUM_MUSCLES];

#ifdef VISUALIZE
	static dsFunctions fn;
#endif
#ifdef REALTIME
	static RT_TASK *rt_task;
#endif

using namespace Eigen;

static double hillEq(double speed)
{
	return HILL_C / (speed + HILL_B) - HILL_A;
}

static void simStep (int pause, int step)
{
	unsigned int time = 0;
	#ifdef REALTIME
		rt_task_wait_period();
	#else
		time = step_timer.elapsed().wall/1000;
		boost::this_thread::sleep(
			boost::posix_time::microseconds(SIM_STEP*1000*1000-time));
	#endif
	if(logfiles){
		time = step_timer.elapsed().wall/1000;
		step_timer.start();
		if(esn->get_ip()){
			step_logfile << time << std::endl;
		}
	}
	else{
		step_timer.start();
	}
	if(!pause){
		if(classic || logfiles){
			mutex_all.lock();
			// for all joints
			for(int i=0; i<3; i++){
				//angles
				classic_info(i) = dJointGetUniversalAngle1(universals[i]);
				classic_info(3+i) = dJointGetUniversalAngle2(universals[i]);
				//accelarations
				double tmp_vel1 = dJointGetUniversalAngle1Rate(universals[i]);
				double tmp_vel2 = dJointGetUniversalAngle2Rate(universals[i]);
				classic_info(6+i) = tmp_vel1 - classic_info(12+i);
				classic_info(9+i) = tmp_vel2 - classic_info(15+i);			
				//velocities
				classic_info(12+i) = tmp_vel1;
				classic_info(15+i) = tmp_vel2;
			}
			mutex_all.unlock();
		}

		// Write current state in global vars
		mutex_all.lock();
		if((!(action_queue.empty())) && 
			(boost::posix_time::microsec_clock::universal_time()
			 -delay_queue.front() >= delay)){
			if(logfiles){
				// log negative last action to get positive correlation with forces
				delay_log << global_timer.elapsed().wall/(1000.0*1000.0*1000.0) 
						  << " " << -last_action.transpose() << " " 
						  << (*last_input).transpose() << std::endl;	
			}
			hill_params = action_queue.front();
			action_queue.pop();
			delay_queue.pop();
		}

		const dReal *position = dBodyGetPosition(pos_marker);
		arm_pos[0] = position[0];
		arm_pos[1] = position[1];
		arm_pos[2] = position[2];
		dReal distance = sqrt((position[0]-disp_goal[0])
								*(position[0]-disp_goal[0])+
							  (position[1]-disp_goal[1])
								*(position[1]-disp_goal[1])+
							  (position[2]-disp_goal[2])
								*(position[2]-disp_goal[2]));
		if(distance <= RADIUS_GOAL){
			goal_reached_bool = true;
		}
		dVector3 tmp;
		for(int i=0; i<(NUM_BODIES-1)*NUM_MUSCLES; i++){
			lengths[i] = muscles[i].vectorB1ToB2(tmp);
		}
		VectorXd forces(hill_params.size());
		for(int i=0; i<NUM_MUSCLES*(NUM_BODIES-1); i++){
			forces[i] = muscles[i].hill((1-hill_params[i]));
		}
	
		boost::posix_time::microseconds timer_time(esn_timer.elapsed().wall
												   /1000);

		#ifdef REALTIME
			if(step%(esn_step_time.total_microseconds()
				/(int)(SIM_STEP*1000*1000)) == 0){
		#else
			if((esn_step_time - timer_time).is_negative()){
		#endif
			esn_timer.start();
			int size = NUM_MUSCLES*(NUM_BODIES-1);
			if(feedback){
				size += NUM_MUSCLES*(NUM_BODIES-1);
			}
			VectorXd input(size);
			input.head(NUM_MUSCLES*(NUM_BODIES-1)) = lengths;
			if(feedback){
				input.tail(NUM_MUSCLES*(NUM_BODIES-1)) = last_action;
			}
			esn->step(input);
			esn->get_state((*esn_state));
			if(logfiles){
				// Sample states for correlation meausrment
				if(step%100 == 0){
					esn_states_log << (*esn_state).transpose() << std::endl;
					classic_states_log << classic_info.transpose() 
									   << std::endl;
				}
			}
			(*last_input) = input;
		}

		mutex_all.unlock();

		dReal hill;
		for(int i = 0; i < (NUM_BODIES-1); i++){
			for(int j=0; j<NUM_MUSCLES; j++){
				dVector3 dir;
				double length = muscles[i*NUM_MUSCLES+j].vectorB1ToB2(dir);
				hill = forces[i*NUM_MUSCLES+j];
				dir[0] *= hill*length;
				dir[1] *= hill*length;
				dir[2] *= hill*length;
				dBodyAddForce (muscles[i*NUM_MUSCLES+j].body_1,dir[0],dir[1],
							   dir[2]);
				dBodyAddForce (muscles[i*NUM_MUSCLES+j].body_2,-dir[0],-dir[1],
							   -dir[2]);
			}
		}

		if (!pause) 
		{
			dWorldStep (world,SIM_STEP);
		}
		
		// draw stuff
	
		#ifdef VISUALIZE
			dReal sides1[3] = {SIDE,SIDE,SIDE};
			dReal sides2[3] = {SIDE_SMALL,SIDE_SMALL,SIDE_SMALL};
			dReal sides3[3] = {0.1,0.1,0.1};

			dsSetTexture (DS_WOOD);
			for (int i=0; i<NUM_BODIES; i++){
				//dsSetColor (NUM_BODIES/(float)(i+1),NUM_BODIES/(float)(i+1),0);
				//dsDrawBox (dBodyGetPosition(body[i]),dBodyGetRotation(body[i]),sides1);
				dsSetColor(body_color(0), body_color(1), body_color(2));
				dsDrawCapsule (dBodyGetPosition(body[i]),
							   dBodyGetRotation(body[i]),SIDE,RADIUS);
			}
			for (int i=0; i<(NUM_BODIES-1)*2*NUM_MUSCLES; ++i) 
			{
				dsSetColor(1,0,1);
				dsDrawBox (dBodyGetPosition(body_small[i]),
						   dBodyGetRotation(body_small[i]),sides2);
			}
			// Draw Joints
			dVector3 universalAnchor;
			dMatrix3 R;
			dRSetIdentity (R);
			for (int i=0; i<(NUM_BODIES-1); i++){
				dsSetColor (1,0,0);
				dJointGetUniversalAnchor (universals[i], universalAnchor);
				dsDrawSphere (universalAnchor,R,0.01);
				dsDrawLine(universalAnchor,dBodyGetPosition(body[i]));
				dsDrawLine(universalAnchor,dBodyGetPosition(body[i+1]));
			}
			// Draw Muscles
			dReal maxVal = hillEq(0);
			dReal minVal = hillEq(1);
			dReal color;
			for (int i=0; i<(NUM_BODIES-1)*NUM_MUSCLES;i++){
				color = 1-(forces[i]-minVal)/(maxVal-minVal);
				dsSetColor(color,color,color);
				dsDrawLine(dBodyGetPosition(muscles[i].body_1),
							dBodyGetPosition(muscles[i].body_2));
			}
			// Draw goal marker
			dsSetColor(1,0,0);
			dsDrawSphere (dBodyGetPosition(pos_marker),
						  dBodyGetRotation(pos_marker),0.05);
			// Draw current goal
			dVector3 goal;
			goal[0] = disp_goal[0];
			goal[1] = disp_goal[1];
			goal[2] = disp_goal[2];
			dsSetColor(1,1,0);
			dsDrawSphere(goal,R,RADIUS_GOAL);
		#endif
	}
}


static void simStepVisualize (int pause){
	simStep(pause, -1);
}


static void start()
{
	// create world
	dInitODE2(0);
	world = dWorldCreate();
	
	dWorldSetERP (world, 0.8);
	dWorldSetCFM (world, 1e-5);
	dWorldSetDamping(world,0.01,0.01);
	dWorldSetGravity(world,0,0,-9.81);

	dMass m;
	dMassSetCapsule(&m,1,3,RADIUS,SIDE);
	dQuaternion q;
	dQFromAxisAndAngle (q,1,0,0,0);
	
	for (int i=0; i<NUM_BODIES; i++){
		body[i] = dBodyCreate (world);
		dMassAdjust (&m,MASS);
		dBodySetMass (body[i],&m);
		dBodySetPosition (body[i],0.5*SIDE,0.5*SIDE,(2*i+2)*SIDE);
		dBodySetQuaternion (body[i],q);
	}
	dBodySetKinematic(body[NUM_BODIES-1]);

	pos_marker = dBodyCreate (world);
	dBodySetPosition(pos_marker,0.5*SIDE,0.5*SIDE,1.5*SIDE-RADIUS);
	dBodySetQuaternion(pos_marker,q);
	pos_hinge = dJointCreateHinge (world,0);
	dJointAttach(pos_hinge,pos_marker,body[0]);
	dJointSetHingeParam(pos_hinge,dParamLoStop,0);
	dJointSetHingeParam(pos_hinge,dParamHiStop,0);

	dMassSetBox (&m,1,SIDE_SMALL,SIDE_SMALL,SIDE_SMALL);
	dMassAdjust (&m,MASS_SMALL);
	
	// setup the small cubes at the sides of the big ones
	dReal x,y,z;
	for (int i=0; i < (NUM_BODIES-1)*2; ++i) 
	{
		for (int j=0; j < NUM_MUSCLES; ++j) 
		{
			body_small[i*NUM_MUSCLES+j] = dBodyCreate (world);
			dBodySetMass (body_small[i*NUM_MUSCLES+j],&m);
			switch(j){
			case 0: case 1:
				x = 0.5*SIDE;
				y = 0.5*(j*2-1)*SIDE_SMALL+j*SIDE;
				break;
			case 2: case 3:
				x = 0.5*((j-2)*2-1)*SIDE_SMALL+(j-2)*SIDE;
				y = 0.5*SIDE;
				break;
			}
			// write 2.5 for 1
			z = (2.5+i%2)*SIDE+(i%2*2-1)*0.5*SIDE_SMALL;
			z += (i/(int)2)*2*SIDE;
			dBodySetPosition(body_small[i*NUM_MUSCLES+j],x,y,z);

			dBodySetQuaternion (body_small[i*NUM_MUSCLES+j],q);
		}
	}
	
	for (int i=0; i<NUM_BODIES-1; i++){
		universals[i] = dJointCreateUniversal (world,0);
		dJointAttach (universals[i],body[i],body[i+1]);
		dJointSetUniversalAnchor(universals[i],0.5*SIDE,0.5*SIDE,(i*2+3)*SIDE);
		dJointSetUniversalParam(universals[i],dParamLoStop,  -M_PI/2);
		dJointSetUniversalParam(universals[i],dParamLoStop2, -M_PI/2);
		dJointSetUniversalParam(universals[i],dParamHiStop,  M_PI/2);
		dJointSetUniversalParam(universals[i],dParamHiStop2, M_PI/2);
	}
	
	dReal xAxis, yAxis;
	for (int i=0; i < (NUM_BODIES-1)*2; ++i) 
	{
		for (int j=0; j < NUM_MUSCLES; ++j) 
		{
			hinges[i*NUM_MUSCLES+j] = dJointCreateHinge (world,0);
			dJointAttach (hinges[i*NUM_MUSCLES+j],
						  body_small[i*NUM_MUSCLES+j],body[(i+1)/2]);
			switch(j){
			case 0: case 1:
				x = 0.5*SIDE;
				y = j*SIDE;
				xAxis = 0;
				yAxis = (2*j-1)*1;
				break;
			case 2: case 3:
				x = (j-2)*SIDE;
				y = 0.5*SIDE;
				xAxis = (2*(j-2)-1)*1;
				yAxis = 0;
				break;
			}
			// write 2.5 for 1
			z = (2.5+i%2)*SIDE+(1-i%2*2)*0.5*SIDE_SMALL;
			z += (i/(int)2)*2*SIDE;
			dJointSetHingeAnchor (hinges[i*NUM_MUSCLES+j],x,y,z);
			dJointSetHingeAxis (hinges[i*NUM_MUSCLES+j], xAxis, yAxis, 0);

			dJointSetHingeParam(hinges[i*NUM_MUSCLES+j],dParamLoStop,0);
			dJointSetHingeParam(hinges[i*NUM_MUSCLES+j],dParamHiStop,0);
		}
	}

	for (int i=0; i < NUM_BODIES-1 ; i++){
		for (int j=0; j<NUM_MUSCLES; j++){
			muscles[i*NUM_MUSCLES+j].body_1 = body_small[i*2*NUM_MUSCLES+j];
			muscles[i*NUM_MUSCLES+j].body_2 = body_small[i*2*NUM_MUSCLES+j
												+NUM_MUSCLES];
		}
	}

	dAllocateODEDataForThread(dAllocateMaskAll);
	
	disp_goal[0] = SIDE/2;
	disp_goal[1] = SIDE/2;
	disp_goal[2] = -1;

	body_color << 1,1,0;
	goal_reached_bool = false;


	#ifdef VISUALIZE
		//static float xyz[3] = {1.0382f,-1.0811f,1.4700f};
		// z=height
		static float xyz[3] = {2.f,-2.f,3.6f};
		//static float hpr[3] = {135.0000f,-19.5000f,0.0000f};
		static float hpr[3] = {135.0000f,-30.000f,0.0000f};
		dsSetViewpoint (xyz,hpr);
		initialized.notify_all();
	#endif
}

static void stop(){
	if(thread_stopped) return;
	std::cout << "Destroy Simulation" << std::endl;
	if(logfiles){
		step_logfile.close();
	}
	if(logfiles){
		esn_states_log.close();
		classic_states_log.close();
	}
	dWorldDestroy (world);
	dCloseODE();
	delete esn;
	delete esn_state;
	delete last_input;
}

static void simLoop(){
	boost::this_thread::at_thread_exit(stop);
	#ifdef REALTIME
		double d = SIM_STEP*1000*1e+6;
		// Enable non-root hrt
		rt_allow_nonroot_hrt();
		// Create realtime task
		if( (rt_task=rt_task_init_schmod(nam2num("ARMTH"),1,1024,1024,
										 SCHED_FIFO, 2)) == NULL ){
			fprintf(stderr,"Failed to create the realtime task.\n");
			fprintf(stderr,"Make sure RTAI modules are inserted\n");
			return;
		}    
		rt_set_runnable_on_cpuid(rt_task,1);
		// Start a timer anyhow
		rt_set_oneshot_mode();
		//rt_set_periodic_mode();
		if(!rt_is_hard_timer_running()){
			start_rt_timer( 0 );
			std::cout << "start_rt_timer" << std::endl;
		}
		// Configure the details of the timer
		if( rt_task_make_periodic_relative_ns(rt_task, 0, d) != 0 ){
			fprintf(stderr,"Failed to configure the timer\n");
		}
	#endif
	step_timer.start();
	global_timer.start();
	
	initialized.notify_all();
	for(int i=0; !exit_thread; i++){
		simStep(paused, i);
	}
	stop();
	#ifdef REALTIME
		rt_task_delete(rt_task);
	#endif
	thread_stopped = true;
}

class Sim_Arm : public IRobot{
public:
	Sim_Arm(int delay, bool feedback, int esn_neurons, double spectral_radius,
			double input_scale, bool direct, int esn_step_timee, 
			bool permutation, bool classic, VectorXd & SORN_params);
	void get_actuator_range(MatrixXd &actuator_ranges);
	int get_number_actuators();
	int get_number_sensors();
	void get_sensors(VectorXd &sensors);
	void get_pos(VectorXd &position);
	void get_goal(VectorXd & user_goal);
	void set_actuators(const VectorXd &values);
	void display_goal(VectorXd &goal);
	void set_color(VectorXd &color);
	bool goal_reached();
	boost::thread * get_thread();
	ESN & get_esn();
	void stop_sim();
	bool stopped();
	void pause(bool pause);
};

#endif
