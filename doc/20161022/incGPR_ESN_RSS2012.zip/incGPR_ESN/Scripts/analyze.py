# This script analyzes a trial by computing means, stds, mins and maxs
# and sorts trials and corresponding parameters accordingly

import sys
import os
import re
import math
from operator import itemgetter

# Compute mean, std, min and max of a list of values
def stats(list):
	mean = 0
	tmp = 0
	std = 0
	for item in list:
		mean += item
		tmp += item*item
	mean /= len(list)
	std = tmp/len(list)-mean*mean
	std = math.sqrt(std)
	return (mean, std, min(list), max(list))

# Parse command line arguments
arglen = len(sys.argv)
printKey = 0
sortby = 0
if(arglen < 3):
	print "Usage: ./analyze.py PATH_TO_FOLDER FOLDER [param=PARAMSTRING] [sortby=(means|stds|mins|maxs)(1|2)]"
	sys.exit(0)
path = sys.argv[1]
folder = sys.argv[2]
if(arglen > 3):
	for param in sys.argv[3:]:
		[key, value] = param.split("=")
		if key == 'param':
			printKey = value
		if key == 'sortby':
			sortby = value

topdir = '%s/%s/LOGS'%(path,folder)

dirname_re = re.compile('%s_(.+)_\d*'%folder)

data1 = {}
data2 = {}

# Collect data from logfiles
for dirpath, dirnames, filenames in os.walk(topdir, topdown = True):
	for filename in filenames:
		if filename == "rmse_test.log":
			file = open(dirpath+'/'+filename)
			file.readline()
			line = file.readline().strip().split()
			file.close()
			group = dirname_re.search(dirpath).group(1)
			if(data1.has_key(group)):
				data1[group].append(float(line[0]))
				data2[group].append(float(line[1]))
			else:
				data1[group] = [float(line[0])]
				data2[group] = [float(line[1])]
				
if(printKey):
	print data1[printKey]
	print data2[printKey]
	sys.exit(0)
				
means1 = {}
stds1 = {}
mins1 = {}
maxs1 = {}

means2 = {}
stds2 = {}
mins2 = {}
maxs2 = {}

# Analyze the data and print results to the command line
for key in sorted(data1.iterkeys()):
	(means1[key], stds1[key], mins1[key], maxs1[key]) = stats(data1[key])
	(means2[key], stds2[key], mins2[key], maxs2[key]) = stats(data2[key])
	if sortby == 0:
		print key
		print "  1: " + "mean:%f std:%f min:%f max:%f"%(means1[key], stds1[key], mins1[key], maxs1[key])
		print "  2: " + "mean:%f std:%f min:%f max:%f"%(means2[key], stds2[key], mins2[key], maxs2[key])
		print " "

if not sortby == 0:
	for item in sorted(vars()[sortby].items(), key=itemgetter(1), reverse=True):
		key = item[0]
		print key
		print "  1: " + "mean:%f std:%f min:%f max:%f"%(means1[key], stds1[key], mins1[key], maxs1[key])
		print "  2: " + "mean:%f std:%f min:%f max:%f"%(means2[key], stds2[key], mins2[key], maxs2[key])
		print " "
		
print "\nGlobal stats 1:"
print "  Min mean : (%f, %s)"%min([ (means1[x], x) for x in means1])
print "  Min std  : (%f, %s)"%min([ (stds1[x], x) for x in stds1])
print "  Min value: (%f, %s)"%min([ (mins1[x], x) for x in mins1])
print "\n\nGlobal stats 2:"
print "  Min mean : (%f, %s)"%min([ (means2[x], x) for x in means2])
print "  Min std  : (%f, %s)"%min([ (stds2[x], x) for x in stds2])
print "  Min value: (%f, %s)"%min([ (mins2[x], x) for x in mins2])


	
