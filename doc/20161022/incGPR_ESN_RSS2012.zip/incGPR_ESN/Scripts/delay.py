# This script copmutes the delayed correlation between 
# motor commands and sensors for Affetto

import sys
import numpy as np
import matplotlib.pyplot as plt
import matplotlib

# Pearson covariance between two arrays a and b
def cov(a,b):
	meana = a.mean()
	meanb = b.mean()
	covar = 0
	for x in range(a.shape[0]):
		covar += (a[x]-meana)*(b[x]-meanb)
	covar /= a.shape[0]
	covar /= a.std()
	covar /= b.std()
	return covar

# #steps to check for correlation
delaysteps = 20
total_actuators = 12
# #actuators to take into consideration
actuators = 12
# take only every modulos value
modulo = 1
# only relevant if not logged (old data)
steptime = 0.0004
# if data comes from hosodaarm
hosoda = 0
	
# Read path from command line argument and load corresponding array
path = "delay.log"
if(len(sys.argv) == 2):
	path = sys.argv[1]
logs = np.loadtxt(path)
print "Shape: ", logs.shape

#preparations
start = 0
# check if time is logged
if logs.shape[1] == 2*total_actuators+1:
	start = 1
if hosoda:
	start = 1;
if start == 1:
	# compute average steptime
	steptime = sum(logs[1:logs.shape[0],0]-logs[0:logs.shape[0]-1,0])/(1.0*(logs.shape[0]-1))
	print "Steptime: %.3fs"%(steptime)
	#TODO: change back
	#steptime = 0.05
time = np.arange(delaysteps/modulo)*steptime*modulo
covars = np.zeros((actuators,delaysteps/modulo))
histdata = np.zeros((delaysteps/modulo))
colors = ["b","g","r","c","m","y","k"]
plt.figure()

# compute covariances for all actuators as a function of delaysteps
for act in range(actuators):
	for delay in range(delaysteps):
		if(delay%modulo == 0):
			covars[act,delay/modulo] = cov(logs[0:logs.shape[0]-delay,start+act],logs[delay:logs.shape[0],start+act+total_actuators])
	max = covars[act,:].argmax()
	print "For action", "%2d"%(act), "max covar at:","%.3fs"%(max*modulo*steptime)
	if hosoda and (act == 0 or act == 16):
		pass
	else:
		histdata[max] += 1
		plt.plot(time,covars[act,:], colors[act%len(colors)])
		plt.plot([max*modulo*steptime, max*modulo*steptime], [covars[act,max],0], colors[act%len(colors)])
		plt.hold(True)
plt.xlabel("Delay in Seconds")
plt.ylabel("Pearson Correlation")
plt.title("Delayed Correlation between Sensors and Actuators")
#plt.legend(("action0","action1","action2","action3","action4"),loc = "lower right")
# plot number of maximas / delaystep on second y-axis
ax2 = plt.twinx()
plt.ylabel("Number of Maximas per Delaystep")
plt.bar(time-steptime/4.0, histdata, width=steptime/2.0, alpha=0.3)
plt.show()
	

		
