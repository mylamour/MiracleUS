# This script performs ANOVAs for a given data-folder

import sys
import os
import re
import math
import numpy as np
import scipy as sp
import matplotlib
matplotlib.use('Agg')	
import matplotlib.pyplot as plt
import networkx as nx
from matplotlib import rc
rc('text', usetex=True)
rc('font', family='serif')

# parameters
alpha = 0.05

# parse command line arguments
arglen = len(sys.argv)
printKey = 0
sortby = 0
labels = 0
defaults = 0
labels = 0
if(arglen != 5):
	print "Usage: ./analyze2.py PATH_TO_FOLDER FOLDER DEFAULT_VALUES LABLES"
	print "Example: ./analyze2.py . T01 180_1 esn_kernel"
	sys.exit(0)
path = sys.argv[1]
folder = sys.argv[2]
defaults = [float(x) for x in sys.argv[3].split("_")]
labels = sys.argv[4].split("_")

topdir = '%s/%s/LOGS'%(path,folder)

dirname_re = re.compile('%s_(.+)_\d*'%folder)

categories = {}
levels = []
sample_size = 0

# walk through directory and read rmse from rmse_test.log files
for dirpath, dirnames, filenames in os.walk(topdir, topdown = True):
	for filename in filenames:
		if filename == "rmse_test.log":
			file = open(dirpath+'/'+filename)
			file.readline()
			line = file.readline().strip().split()
			file.close()
			group = dirname_re.search(dirpath).group(1)
			sgroup = group.split("_")
			tmp = categories
			# save rmses in tree of variables (levels = leaves) modeled
			# with dictionaries of dictionaries
			for i in range(len(sgroup)):
				# also save name of levels
				if(i == 1 and folder=='T14'):
					sgroup[i] ='%d'%(float(sgroup[i])-float(sgroup[i-1])/60)
				if(len(levels) <= i):
					levels.append([float(sgroup[i])])
				if not float(sgroup[i]) in levels[i]:
					levels[i].append(float(sgroup[i]))
				if not tmp.has_key(sgroup[i]):
					tmp[sgroup[i]] = {}
				if i==len(sgroup)-1:
					if(tmp[sgroup[i]].has_key('1')):
						tmp[sgroup[i]]['1']["data"].append(float(line[0]))
						tmp[sgroup[i]]['2']["data"].append(float(line[1]))
						
						# also count the number of samples per condition
						if(sample_size < len(tmp[sgroup[i]]['1']["data"])):
							sample_size = len(tmp[sgroup[i]]['1']["data"])
					else:
						tmp[sgroup[i]]['1'] = {"data":[float(line[0])]}
						tmp[sgroup[i]]['2'] = {"data":[float(line[1])]}
				tmp = tmp[sgroup[i]]
levels.append([1,2])

# Data does not need to be sorted because its organized in a dictionary
for x in levels:
	x.sort()

# levelsizes needed to initialize a np array for better data handling
levelsizes = []
for i in range(len(levels)):
	levelsizes.append(len(levels[i]))
levelsizes.append(sample_size)
# init arrays
data = np.zeros(tuple(levelsizes))
levelsizes.pop()
means = np.ones(tuple(levelsizes))
stds  = np.ones(tuple(levelsizes))
sums  = np.ones(tuple(levelsizes))
ss    = np.ones(tuple(levelsizes))

tmp = categories
tmpold = []
keystack = categories.keys()
level = []
depth = -1
# walk through tree of conditions and save data, means and stds in nparrays
while not keystack == ["_"]:
	# keystack is the stack with keys to visit next. levels are separated by "_"
	nextkey = keystack[len(keystack)-1]
	keystack.pop()
	if nextkey == "_":
		tmp = tmpold[len(tmpold)-1]
		tmpold.pop()
		level.pop()
		depth -= 1
	else:
		tmpold.append(tmp)
		tmp = tmp[nextkey]
		depth += 1
		level.append(levels[depth].index(float(nextkey)))
		if(tmp.has_key("data")):
			# transfer data and compute mean
			try:
				data[tuple(level)] = tmp["data"]
			except:
				print "Not enought data (expected len %d):"%(sample_size), tmp["data"]
				length = len(tmp["data"])
				while(length < sample_size):
					tmp["data"].append(np.mean(tmp["data"]))
					length += 1
				print "Padded with mean:", tmp["data"]
				data[tuple(level)] = tmp["data"]
			means[tuple(level)] = np.mean(data[tuple(level)])
			stds[tuple(level)] = np.std(data[tuple(level)])
			sums[tuple(level)] = np.sum(data[tuple(level)])
			ss[tuple(level)] = np.sum(data[tuple(level)]*data[tuple(level)])
			level.pop()
			depth -= 1
			tmp = tmpold[len(tmpold)-1]
			tmpold.pop()
		else:
			keystack.append("_")
			keystack.extend(tmp.keys())
					
					
# take all possible combinations of independent variables and plot the mean and
# stds of all levels against each other
# save in folder "images"
try:
	os.mkdir("plots")
except:
	pass

	
for (i,j) in [(x,y) for x in range(len(levels)) for y in range(x+1,len(levels))]:
		m = 0
		s = 0
		x = 0
		tmpindex=[]
		tmpindex.extend(defaults)
		for h in range(len(levels)):
			tmpindex[h] = levels[h].index(defaults[h])
		# slice(None) is used to represent ":" to get whole rows/columns
		tmpindex[i] = slice(None)
		tmpindex[j] = slice(None)
		
		# significances
		
		# ANOVA
		n = len(levels[i])*len(levels[j])*sample_size
		significant = np.zeros(3)
		sums_tmp = sums[tuple(tmpindex)]
		ss_tmp = ss[tuple(tmpindex)]
		ss_cond = np.zeros(3)
		df_cond = np.zeros(3)
		ms_cond = np.zeros(3)
		f_cond  = np.zeros(3)
		
		fisher_sigs = ["",""]
		graph = 0
		pos_nodes = {}
		pos_edges = []
		edges = []
		maxindex = max(len(levels[i]),len(levels[j]))
		
		fcrit_cond = np.zeros(3)
		mean_summ_squared = (np.sum(sums_tmp)*np.sum(sums_tmp)/n)
		ss_between = np.sum((sums_tmp*sums_tmp)/sample_size)-mean_summ_squared
		df_between = len(levels[i])*len(levels[j])-1
		ss_tot  =  np.sum(ss_tmp)-mean_summ_squared
		df_tot = n-1
		ss_within = ss_tot-ss_between
		for condition in range(3):
			if condition == 0:
				tmp = 0
				for levelindex in range(len(levels[i])):
					tmp += np.sum(sums_tmp[levelindex,:])*np.sum(sums_tmp[levelindex,:])
				tmp /= (sample_size * len(levels[j]))
				ss_cond[0] = tmp-mean_summ_squared
				df_cond[0] = len(levels[i])-1
			if condition == 1:
				tmp = 0
				for levelindex in range(len(levels[j])):
					tmp += np.sum(sums_tmp[:,levelindex])*np.sum(sums_tmp[:,levelindex])
				tmp /= (sample_size * len(levels[i]))
				ss_cond[1] = tmp-mean_summ_squared
				df_cond[1] = len(levels[j])-1
			if condition == 2:
				ss_cond[2] = ss_between - ss_cond[0] - ss_cond[1]
				df_cond[2] = df_between - df_cond[0] - df_cond[1]
			ms_cond[condition] = ss_cond[condition]/df_cond[condition]	
		df_within = df_tot-np.sum(df_cond)
		ms_within = ss_within/df_within
		for condition in range(3):
			f_cond[condition] = ms_cond[condition]/ms_within
			fcrit_cond[condition] = sp.stats.f.isf(alpha,df_cond[condition],df_within)
			if(fcrit_cond[condition] < f_cond[condition]):
				significant[condition] = 1		
				# Post-Hoc using Fisher's LSD instead of Tuckey's HSD because no studentized range distribution for python
				if condition == 0:
					indices = [i,j]
				elif condition == 1:
					indices = [j,i]
				else:
					indices = 0
				if indices:
					# Check levels of main effects and visualize as table
					fisher_denom = np.sqrt(ms_within*2*(1.0/(sample_size*len(levels[indices[0]]))))
					fisher_sigs[condition] += r"\begin{tabular}{l |"
					for _ in range(len(levels[indices[0]])):
						fisher_sigs[condition] += r" c"
					fisher_sigs[condition] += r"} %s "%(labels[indices[0]])
					for h in range(len(levels[indices[0]])):
						fisher_sigs[condition] += r" & %s"%(levels[indices[0]][h])
					fisher_sigs[condition] += r"\\ \hline "
					for a in range(len(levels[indices[0]])):
						fisher_sigs[condition] += r" %s "%(levels[indices[0]][a])
						for b in range(len(levels[indices[0]])):
							if condition == 0:
								lsd = np.abs((np.sum(sums_tmp[a,:])/(sample_size*len(levels[indices[1]])) - np.sum(sums_tmp[b,:])/(sample_size*len(levels[indices[1]]))) / fisher_denom)
							elif condition == 1:
								lsd = np.abs((np.sum(sums_tmp[:,a])/(sample_size*len(levels[indices[0]])) - np.sum(sums_tmp[:,b])/(sample_size*len(levels[indices[0]]))) / fisher_denom)
							sig = (lsd-sp.stats.t.isf(alpha,df_within) > 0)
							fisher_sigs[condition] += r" & %d "%(sig)
						fisher_sigs[condition] += r" \\ "
					fisher_sigs[condition] += r" \end{tabular} "
				else:
					# Check interactions and visualize as graph
					graph = nx.Graph()
					fisher_denom = np.sqrt(ms_within*2*(1.0/sample_size))
					for _ in range(maxindex):
						pos_edges.append({})
						edges.append([])
					for a in range(len(levels[i])):
						for b in range(len(levels[j])):
							key = '%s%s-%s%s'%(labels[i][0],levels[i][a],labels[j][0],levels[j][b])
							graph.add_node(key)
							pos_nodes[key] = (a,b)
							for h in range(maxindex):
								pos_edges[h][key] = (a-h*0.05,b-h*0.05)
					for (a,b) in [(x,y) for x in range(len(levels[i])) for y in range(len(levels[j]))]:
						key1 = '%s%s-%s%s'%(labels[i][0],levels[i][a],labels[j][0],levels[j][b])
						for a2 in range(len(levels[i])):
							key2 = '%s%s-%s%s'%(labels[i][0],levels[i][a2],labels[j][0],levels[j][b])
							lsd = np.abs((sums_tmp[a,b]/sample_size - np.sum(sums_tmp[a2,b])/sample_size) / fisher_denom)
							if (lsd-sp.stats.t.isf(alpha,df_within) > 0):
								graph.add_edge(key1,key2)
								edges[abs(a2-a)-1].append((key1,key2))
						for b2 in range(len(levels[j])):
							key2 = '%s%s-%s%s'%(labels[i][0],levels[i][a],labels[j][0],levels[j][b2])
							lsd = np.abs((sums_tmp[a,b]/sample_size - np.sum(sums_tmp[a2,b])/sample_size) / fisher_denom)
							if (lsd-sp.stats.t.isf(alpha,df_within) > 0):
								graph.add_edge(key1,key2)	
								edges[abs(b2-b)-1].append((key1,key2))
		
		# means, stds
		m = means[tuple(tmpindex)]
		s = stds[tuple(tmpindex)]
		x = np.zeros(m.shape)
			
			
		# Plot
		plt.figure(figsize=(6,14))
		plt.subplot(311)
		
		if(len(levels[j]) <= len(levels[i])):
			for h in range(len(levels[j])):
				x[:,h] = levels[i]
				plt.errorbar(x[:,h],m[:,h],yerr=(s[:,h]/np.sqrt(sample_size)),label="%s = %s"%(labels[j],levels[j][h]))
			plt.xlabel(labels[i])
			plt.title("%s: %s vs. %s with standard error"%(folder, labels[i],labels[j]))
		else:
			for h in range(len(levels[i])):
				x[h,:] = levels[j]
				plt.errorbar(x[h,:],m[h,:],yerr=(s[h,:]/np.sqrt(sample_size)),label="%s = %s"%(labels[i],levels[i][h]))
			plt.xlabel(labels[j])
			plt.title("%s: %s vs. %s with standard error"%(folder, labels[j],labels[i]))
		plt.ylabel("rmse")
		plt.legend()
		# Widen plot to see errorbars
		v = plt.axis()
		diff1 = (v[1]-v[0])/10
		diff2 = (v[3]-v[2])/10
		plt.axis([v[0]-diff1,v[1]+diff1,v[2]-diff2,v[3]+diff2])
		
		ax = plt.subplot(312, frame_on=False)
		ax.xaxis.set_visible(False)
		ax.yaxis.set_visible(False)
		# prepare ANOVA table
		tablestring = r'$\\'
		tablestring += r'\begin{tabular}{l c c c c c c} \hline \hline ANOVA & & & & & & \\ \hline \hline Source & SS & df & MS & F & F$_{%.3f}$ & Sig. \\ \hline '%(alpha)
		tablestring += r'Between &  &  &  &  & & \\'
		tablestring += r' ~%s & %.3f & %d  & %.3f  & %.3f & %.3f & %d \\'%(labels[i],ss_cond[0],df_cond[0],ms_cond[0],f_cond[0],fcrit_cond[0],significant[0])
		tablestring += r' ~%s & %.3f & %d  & %.3f  & %.3f & %.3f & %d\\'%(labels[j],ss_cond[1],df_cond[1],ms_cond[1],f_cond[1],fcrit_cond[1],significant[1])
		tablestring += r' ~Interaction & %.3f & %d  & %.3f  & %.3f & %.3f & %d \\'%(ss_cond[2],df_cond[2],ms_cond[2],f_cond[2],fcrit_cond[2],significant[2])
		tablestring += r' Within & %.3f & %d  & %.3f  &  & & \\'%(ss_within,df_within,ms_within)
		tablestring += r' Total & %.3f & %d & & & & \end{tabular}'%(ss_tot,df_tot)
		tablestring += r' \\ \\ \\ \textrm{Post-Hoc Significance (Fisher-LSD):} \\ \textrm{~%s}'%(fisher_sigs[0])
		tablestring += r' \\ \\ \textrm{~%s}'%(fisher_sigs[1])
		tablestring += r'$'
		plt.text(0,1,tablestring,horizontalalignment='left',verticalalignment='top')
		
		ax = plt.subplot(313, frame_on=False)
		ax.xaxis.set_visible(False)
		ax.yaxis.set_visible(False)
		if graph:
			# Get the nodes first
			nx.draw(graph,pos=pos_nodes,edgelist=[],node_size=700,node_color="w")
			# Then add the edges for all significant interactions
			for h in range(maxindex):
				nx.draw_networkx_edges(graph,pos=pos_edges[h],edgelist=edges[h], style='dashed', width=1)
		plt.savefig("plots/%s_%s_%s"%(folder,labels[i],labels[j]))

	
