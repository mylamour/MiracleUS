# Performs ANOVAs for all collected grid-data
import os

# Arguments and corresponding default values for analysis
arguments = [	[	"gprs_numpred_radius_subst",\
					"10_3_0.7_2"],\
				[	"esntime_sparse_perturb_subst",\
					"30_5_0.4_2"],\
				[	"gprs_inscale_kernel_subst",\
					"10_2.0_1_2"],\
				[	"neurons_subst2_trasize_subst",\
					"100_0_150_2"],\
				[	"neurons_inscale_subst",\
					"100_1.0_2"],\
				[	"steps_maxobs_neurons_feedback_subst",\
					"5000_800_180_1_2"],\
				[	"maxobs_radius_inscale_subst",\
					"800_0.7_1.1_2"],\
				[	"maxobs_feedback_ip_inscale_subst",\
					"800_0_1_1.1_2"],\
				[	"maxobs_radius_inscale_subst",\
					"800_0.7_1.1_2"],\
				[	"maxobs_radius_inscale_subst",\
					"900_0.7_1.1_2"],\
				[	"maxobs_radius_inscale_subst",\
					"925_0.7_1.2_2"],\
				[	"trasize_randexp_subst",\
					"150_0.01_2"],\
				[	"esntime_delay_randexp_ip_feedback_subst",\
					"30_0_0.01_1_0_2"],\
				[	"delay_delaysteps_radius_inscale_feedback_subst",\
					"0_1_0.7_1.0_0_2"],\
				[	"steps_neurons_delay_delaysteps_randexp_radius_inscale_subst",\
					"10000_200_0_1_0.01_0.6_1.1_2"],\
				[	"fermi_permutation_subst",\
					"0_0_2"],\
				[	"fermi_augmented_subst",\
					"0_0_2"],\
				[	"fermi_augmented_subst",\
					"0_0_2"],\
				[	"neurons_feedback_direct_trasize_subst",\
					"180_0_0_170_2"],\
				[	"esntime_permutation_tradiff_subst",\
					"30_0_0.20_2"],\
				[	"Missing",\
					"Folder"],\
				[	"neurons_randexp_subst2_kernel_subst",\
					"180_0.01_0_1_2"],\
				[	"neurons_randexp_subst2_kernel_subst",\
					"180_0.01_0_1_2"]\
			]
for (i,[label,default]) in enumerate(arguments):
	if i==i:
		print "T%02d"%(i+1),label,default
		os.system("analyze2.py . T%02d %s %s"%(i+1,default,label))