# This script identifies the correlations between joint angles, velocities and accelerations and the ESN-states

import sys
import os
import scipy as sp
import numpy as np

esn = np.loadtxt("esn_states.log")
classic = np.loadtxt("classic_states.log")

covarM = np.zeros((esn.shape[1],classic.shape[1]))

for i in xrange(9,esn.shape[1]):
	for j in xrange(classic.shape[1]):
		covar = np.cov(esn[:,i],classic[:,j])
		covarM[i,j] = covar[0,1]/(np.sqrt(covar[0,0])*np.sqrt(covar[1,1]))

maxCovar = np.abs(covarM).max(0)
		
print "maximum covariances between all esn-units and joints 1-6"
print " pos-covariance:"
print "  ",maxCovar[0:6]
print " vel-covariance:"
print "  ",maxCovar[12:18]
print " acc-covariance:"
print "  ",maxCovar[6:12]
	