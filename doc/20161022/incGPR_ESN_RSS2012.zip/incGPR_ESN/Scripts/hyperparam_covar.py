# This script analyzes the correlation between and within optimized hyperparameters

import sys
import numpy as np

# Read file path from command line arguments
path = "output.log"
if(len(sys.argv) == 2):
	path = sys.argv[1]
# Read output file until estimated hyperparameters come up
output = open(path)
line = output.readline()
while(not line == "Estimated Hyperparameters:\n"):
	line = output.readline()
line = output.readline()
line = line.strip()
# And write them into an array (in float)
hypers = np.array(map(float,line.split(" ")))
line = output.readline()
while(line != "Mean Hyperparameters (used by multi):\n"):
	line = line.strip()
	hypers = np.vstack((hypers,np.array(map(float, line.split(" ")))))
	line = output.readline()

# Compute standart deviation within each set of estimated hyperparameters
# Not taking into account variance in sigma, theta, position and kernel
std_within = np.zeros(hypers.shape[0])
for (i,hyper) in enumerate(hypers):
	std_within[i] = hyper[5:hypers.shape[1]-2].std()
# and between each set of estimated hyperparameters for every parameter
std_between = np.zeros(hypers.shape[1])
for (i,hyper) in enumerate(hypers.transpose()):
	std_between[i] = hyper.std()
	
print "Std Within:"
print std_within
print " "
print "Std Between:  (sigma, theta, position*3, hypers*%i, kernel)"%(hypers.shape[1]-6)
print std_between
# Finally compute the mean
print "Number of sets (actuators):", hyper.shape[0]
print "Number of hyperparameters/set (without theta, sigma, kernel and position):",\
		hypers.shape[1]-6
print "Mean Std Within:", std_within.mean()
print "Mean Std Between:", std_between.mean()