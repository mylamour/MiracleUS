# This script plots prior and posterior samples from gaussian processes

import numpy as np
import matplotlib
matplotlib.use('Agg')
matplotlib.rc('xtick', labelsize=20) 
matplotlib.rc('ytick', labelsize=20) 
font = {'family' : 'sans',
        'weight' : 'normal',
        'size'   : 22}
matplotlib.rc('font', **font)
import matplotlib.pyplot as plt

# open parameters
n_samples = 100
n_tests = 5
n_obs = 5
sigma = 0.0
range = [0,10]
default_theta = 1
default_eta = 1
obs_offset = 0

# exponential kernel
def exp_kernel(x,y,theta=default_theta,etas=0):
	if etas == 0 or not etas.size == x.size:
		etas = np.ones(x.size)*default_eta
	return theta*np.exp(-0.5*np.sum(((x-y)*(x-y))*etas))

x = np.linspace(range[0],range[1],n_samples)
covar_x_x = np.zeros((n_samples,n_samples))

# generate and plot prior functions
# 1. calculate covariance matrix
for i in xrange(n_samples):
	for j in xrange(n_samples):
		covar_x_x[i,j] = exp_kernel(x[i],x[j])
		if i==j:
			covar_x_x[i,j] += sigma
plt.figure()		
# 2. draw sample functions from gaussian distribution
mean_prior = np.zeros(n_samples)
covar_prior = covar_x_x
for i in xrange(n_tests):
	y = np.random.multivariate_normal(mean_prior,covar_prior)
	plt.plot(x,y,marker='x',ls='')
	plt.hold('on')
plt.title('Prior $\sigma=%.2f$ $\\theta=%.2f$ $\eta_1=%.2f$'%(sigma,default_theta,default_eta))
plt.xlim([-1,11])
plt.savefig('gpr_prior.eps')

# generate and plot posterior functions
# 1. generate -r-a-n-d-o-m- fixed observations
#obs = (np.random.rand(n_obs)+range[0])*(range[1]-range[0])
#obs_y = np.random.rand(n_obs)+obs_offset
obs = np.array([0.9, 3, 7.1, 7.2, 8.5])
obs_y = np.array([1, -1, 0.2, 0, 1.5])

# 2. calculate covariances between observations and priors
covar_obs_obs = np.zeros((n_obs,n_obs))
covar_obs_x = np.zeros((n_obs,n_samples))
for i in xrange(n_obs):
	for j in xrange(n_obs):
		covar_obs_obs[i,j] = exp_kernel(obs[i],obs[j])
		if i==j:
			covar_obs_obs[i,j] += sigma
	for j in xrange(n_samples):
		covar_obs_x[i,j] = exp_kernel(obs[i],x[j])
		if i==j:
			covar_obs_x[i,j] += sigma
plt.figure()
# 3. calculate mean and covariance for the posterior distribution
# and draw samples
mean_posterior = np.dot(np.dot(covar_obs_x.T,
					np.linalg.inv(covar_obs_obs)),obs_y)
covar_posterior = covar_x_x-np.dot(np.dot(covar_obs_x.T,
					np.linalg.inv(covar_obs_obs)),covar_obs_x)
plt.plot(obs,obs_y,marker='o',ms=12.0,ls='')
plt.hold('on')
for i in xrange(n_tests):
	y = np.random.multivariate_normal(mean_posterior,covar_posterior)
	plt.plot(x,y,marker='x',ls='')
	plt.hold('on')
plt.plot(x,mean_posterior)
plt.title('Posterior $\sigma=%.2f$ $\\theta=%.2f$ $\eta_1=%.2f$'%(sigma,default_theta,default_eta))
plt.xlim([-1,11])
plt.savefig('gpr_posterior.eps')
plt.show()