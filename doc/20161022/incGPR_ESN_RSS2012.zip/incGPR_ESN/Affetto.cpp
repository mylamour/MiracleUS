#include "sim_config.h"
#ifdef AFFETTO

#include "Affetto.h"
#include <iostream>
#include <fstream>
#include <boost/thread.hpp>  
#include <boost/date_time.hpp> 
#include "GPR.h"
#include "Eigen/Dense"
#include "InputKinect.h"

#ifdef REALTIME
	#include <rtai.h>
	#include <rtai_lxrt.h>
	#include <rtai_sched.h>
	#include <rtai_msg.h>
	#include <rtai_netrpc.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <sys/time.h>
#endif

using namespace Eigen;

Affetto::Affetto(int delayy, bool feedbackk, int esn_neurons, 
				 double spectral_radius, double input_scale, bool direct, 
				 int esn_step_timee, bool permutation,
				 VectorXd & SORN_params){
	feedback = feedbackk;
	exit_thread = false;
	thread_stopped = false;
	delay = boost::posix_time::microseconds(delayy*1000);
	esn_step_time = boost::posix_time::microseconds(esn_step_timee*1000);
	esn_timer.start();

	relaxing = false;

	int esn_input_dim = num_sensors;
	if(feedback) esn_input_dim += num_actuators;
	if(SORN_params.size() == 7){
		esn = new SORN(esn_neurons, spectral_radius, esn_input_dim, 
					   input_scale, direct, permutation, SORN_params);
	}
	else{
		esn = new ESN(esn_neurons, spectral_radius, esn_input_dim, input_scale, 
					  direct, permutation);
	}
	esn_state = new VectorXd(esn->dim_out());
	last_input = new VectorXd(esn_input_dim);
	#ifdef TWO_ARMS
		user_goal = new VectorXd(6);
		(*user_goal) = VectorXd::Zero(6);
	#else
		user_goal = new VectorXd(3);
		(*user_goal) = VectorXd::Zero(3);
	#endif


	if(logfiles){
		step_logfile.open("log/steptime_affetto.log");
		affetto_pos.open("log/affetto_pos.log");
		delay_log.open("log/delay.log");
	}

	body_color << 1,1,0;
	#ifdef TWO_ARMS
		arm_pos << 0,0,0,0,0,0;
		disp_goal << 0.5,0.5,0.65,0.5,0.5,0.65;
	#else
		arm_pos << 0,0,0;
		disp_goal << 0.5,0.6,0.65;
	#endif
	last_action = VectorXd::Ones(num_actuators)*0.1;
	goal_reached_bool = false;
	(*last_input) = VectorXd::Zero(esn_input_dim);

	affetto_socket.initializeSocket("127.0.0.1",9999);

	// Upper and lower colour bounds for thresholding
	VectorXd lower_bound = Vector3d(20,100,100);
	VectorXd upper_bound = Vector3d(30,255,255);
	kinect = new InputKinect(lower_bound, upper_bound,logfiles);

	posThread = new boost::thread(posLoop);
	simThread = new boost::thread(simLoop);
	#ifdef RELAX
		boost::thread * relaxThread = new boost::thread(relaxLoop);
	#endif

	boost::unique_lock<boost::mutex> lock(mutex_all);
	initialized.wait(lock);
	sim_thread = simThread;
	boost::this_thread::at_thread_exit(stop);
	std::cout << "Thread created" << std::endl;
}

void Affetto::get_actuator_range(MatrixXd &actuator_ranges){
#if defined AFFETTO_LEFT_ARM || defined AFFETTO_RIGHT_ARM
	actuator_ranges.array() *= 0;
	actuator_ranges.col(0).array() += 30;
	actuator_ranges.col(1).array() += 230;
	//actuator_ranges.col(0)(130) = 100;
	//actuator_ranges.col(0)(130) = 100;
#else
	actuator_ranges.array() *= 0;
	actuator_ranges.col(0).array() += 60; //TODO change to 30
	actuator_ranges.col(1).array() += 200;
	//Fixed Neck Values
		actuator_ranges.col(0)(0) = 30;
	actuator_ranges.col(1)(0) = 30;
		actuator_ranges.col(0)(1) = 30;
	actuator_ranges.col(1)(1) = 30;
		actuator_ranges.col(0)(2) = 128;
	actuator_ranges.col(1)(2) = 128;
	//Fixed lower body
			actuator_ranges.col(0)(12) = 128;
	actuator_ranges.col(1)(12) = 128;
		actuator_ranges.col(0)(13) = 128;
	actuator_ranges.col(1)(13) = 128;
	//Fixed Norman Values
	/*
				actuator_ranges.col(0)(10) = 128;
	actuator_ranges.col(1)(10) = 128;
		actuator_ranges.col(0)(11) = 128;
	actuator_ranges.col(1)(11) = 128;
				actuator_ranges.col(0)(5) = 190;
	actuator_ranges.col(1)(5) = 190;
		actuator_ranges.col(0)(6) = 190;
	actuator_ranges.col(1)(6) = 190;
		actuator_ranges.col(0)(3) = 30;
	actuator_ranges.col(1)(3) = 30;
				actuator_ranges.col(0)(4) = 30;
	actuator_ranges.col(1)(4) = 30;
	*/

#endif
	// Normalize so that 0 is at 128 and the range is [-0.5,0.5]
	actuator_ranges.array() -= 128;
	actuator_ranges /= 255.0;
}

int Affetto::get_number_actuators(){
	return num_actuators;
}

int Affetto::get_number_sensors(){
	return esn->dim_out();
}

void Affetto::get_sensors(VectorXd &sensors){
	mutex_all.lock();
	sensors = (*esn_state);
	mutex_all.unlock();
}

void Affetto::get_pos(VectorXd &position){
	mutex_all.lock();
	position = arm_pos;
	mutex_all.unlock();
}

void Affetto::set_actuators(const VectorXd &values){
	mutex_all.lock();
	last_action = values.array()+128.0/255.0;
	VectorXd send_action;
	VectorXd tmpValues = values.array()*255+128;
#ifdef AFFETTO_RIGHT_ARM
	send_action = VectorXd::Ones(24)*128;
	send_action(3) = tmpValues(0);
	send_action(14) = tmpValues(1);
	send_action(15) = tmpValues(2);
	send_action(5) = tmpValues(3);
	send_action(7) = tmpValues(4);
	send_action(0) = 200;
	send_action(1) = 200;
	send_action(2) = 30;
#elif defined AFFETTO_LEFT_ARM
	send_action = VectorXd::Ones(24)*128;
	send_action(4) = tmpValues(0);
	send_action(18) = tmpValues(1);
	send_action(19) = tmpValues(2);
	send_action(6) = tmpValues(3);
	send_action(8) = tmpValues(4);
	send_action(0) = 170;
	send_action(1) = 170;
	send_action(2) = 170;
#else
	send_action = tmpValues;
#endif
	action_queue.push(send_action);
	delay_queue.push(boost::posix_time::microsec_clock::universal_time());
	mutex_all.unlock();
	while(relaxing){
		boost::this_thread::sleep(boost::posix_time::seconds(1));
	}
}

void Affetto::display_goal(VectorXd &goal){
	mutex_all.lock();
	disp_goal = goal;
	mutex_all.unlock();
}

void Affetto::set_color(VectorXd &color){
	mutex_all.lock();
	body_color = color;
	mutex_all.unlock();
}

bool Affetto::goal_reached(){
	mutex_all.lock();
	bool reached = goal_reached_bool;
	if(reached){
		goal_reached_bool = false;
	}
	mutex_all.unlock();
	return reached;
}

ESN & Affetto::get_esn(){
	return (*esn);
}

boost::thread * Affetto::get_thread(){
	return sim_thread;
}

void Affetto::stop_sim(){
	exit_thread = true;
}

bool Affetto::stopped(){
	return thread_stopped;
}

void Affetto::pause(bool pause){
	paused = pause;
}

void Affetto::get_goal(VectorXd &goal){
	goal = (*user_goal);	
}

#endif