#include "GPR_inc_Group.h"
#include "GPR_inc.h"
#include "Eigen/Dense"
#include <boost/timer/timer.hpp>
#include <boost/date_time.hpp>

using namespace Eigen;

GPR_inc_Group::GPR_inc_Group(int max_GPRss, int max_sizee, double max_distt, 
							 VectorXd *hyperr,int num_pred) : 
							 max_GPRs(max_GPRss), max_size(max_sizee),
							 max_dist(max_distt), hypers(hyperr),GPRs_number(0),
							 num_predictions(num_pred){}

void GPR_inc_Group::inc_learn(const VectorXd &observation, const double target, 
							  bool substitute){
	if(GPRs_number == 0){
		GPRs_number++;
		GPRs.push_back(GPR_inc(hypers,max_size));
		GPRs[GPRs_number-1].inc_learn(observation, target);
		return;
	}
	
	VectorXd distances(GPRs_number);
	// The higher the distance measure, the closer the model
	for(int i=0; i<GPRs_number; i++){
		VectorXd center;
		GPRs[i].get_center(center);
		distances(i) = GPR::kernel(observation,center,hypers);
	}

	if(distances.maxCoeff() < max_dist){
		if(GPRs_number < max_GPRs){
			GPRs_number++;
			GPRs.push_back(GPR_inc(hypers,max_size));
			GPRs[GPRs_number-1].inc_learn(observation, target);
			
			return;
		}
		else{
			int debugMarker = 0;
			// if model too far away but max_GPRs reached, 
			// learn with closest model
		}
	}
	// Closest local model
	int max_index;
	double max_value = 1;
	distances.maxCoeff(&max_index);

	if(substitute){
		if(GPRs[max_index].full()){
			int del_obs = GPRs[max_index].max_covar_obs();
			GPRs[max_index].substitute(observation,target,del_obs);
		}
		else{
			GPRs[max_index].inc_learn(observation,target);
		}
	}
	else{
		while((max_value > 0) && (GPRs[max_index].full())){
			distances(max_index) = 0;
			max_value = distances.maxCoeff(&max_index);
		}
		GPRs[max_index].inc_learn(observation,target);
	}
}

double GPR_inc_Group::predict(const VectorXd &observation){
	int num_pred;
	if(GPRs_number < num_predictions){
		num_pred = GPRs_number;
	}
	else{
		num_pred = num_predictions;
	}
	VectorXd predictions(num_pred);
	VectorXd distances_all(GPRs_number);
	VectorXd distances_pred(num_pred);
	for(int i=0; i<GPRs_number; i++){
		VectorXd center;
		GPRs[i].get_center(center);
		distances_all(i) = GPR::kernel(observation,center,hypers);		
	}
	for(int i=0; i<num_pred; i++){
		int max_index;
		distances_pred(i) = distances_all.maxCoeff(&max_index);
		predictions(i) = GPRs[max_index].predict(observation);
		distances_all(max_index) = 0;
	}
	return (predictions.array()*distances_pred.array()).sum()
			/distances_pred.sum();
}

void GPR_inc_Group::estimate_pred_time(boost::posix_time::microseconds &time){
	boost::timer::cpu_timer timer;
	int times = 10;
	std::vector<MatrixXd> inv(times*num_predictions);
	std::vector<VectorXd> c1(times*num_predictions);
	std::vector<VectorXd> c2(times*num_predictions*max_size);
	for(int i=0; i<times*num_predictions; i++){
		inv[i] = MatrixXd::Random(max_size,max_size);
		c1[i] = VectorXd::Random((*hypers).size()-3);
		for(int j=0; j<max_size; j++){
			c2[i*j] = VectorXd::Random((*hypers).size()-3);
		}
	}
	timer.start();
	for(int i=0; i<times*num_predictions; i++){
		VectorXd covar(max_size);		
		for(int j=0; j<max_size; j++){
			covar(j) = GPR::kernel(c1[i],c2[i*j],hypers);
		}
		RowVectorXd tmp = covar.transpose()*VectorXd::Random(max_size);
	}
	boost::posix_time::microseconds tmp((timer.elapsed().wall/1000)/times);
	time = tmp;
}