#ifndef CONTROLLER_H
#define CONTROLLER_H

#include "sim_config.h"
#include "ESN.h"
#include "GPR.h"
#include "Online_Learner.h"
#include "boost/thread.hpp"
#include "boost/date_time.hpp"

#ifdef REALTIME
	#include <rtai.h>
	#include <rtai_lxrt.h>
	#include <rtai_sched.h>
	#include <rtai_msg.h>
	#include <rtai_netrpc.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <sys/time.h>
#endif

#ifdef REALTIME
	static RT_TASK *rt_task2;
#endif

class IRobot;

using Eigen::VectorXd;
using Eigen::MatrixXd;
using std::string;


/// <summary>The controller is the core of this project. 
/// It interconnects the robot, and the GPR online learner.
/// It also performs the Automatic Relevance Determination and can later be 
/// used to follow a trajectory.</summary>
class Controller{
	Online_Learner ol;
	IRobot &robo;
	std::vector<VectorXd> *actuator_hypers;
	// used to scale distance to next goal
	double speed;
	double rand_exploration;
	// number of steps with zero activation after relaxation of muscles
	int relax_steps;
	boost::posix_time::microseconds step_time;
	boost::posix_time::microseconds max_pred_time;
	bool feedback;
	int esn_input_dim;
	int delay_steps;
	int rand_sparse;
	int rand_len;
	double perturbation;
	double min_var;
	/// <summary>Generates a random action part with a mean of 
	/// (range(1)-range(0))/2 that can be added to another action</summary>
	void random_action_add(VectorXd &action_add) const;
	/// <summary>Makes sure that the action is in the allowed range</summary>
	void check_action(VectorXd &action) const;
	#ifdef REALTIME
		void create_rt_task();
	#endif
public:
	/// <param name="GPRs_max">Max number of GPRs per actuator</param>
	/// <param name="GPRs_size">Max number of observations per GPR</param>
	/// <param name="GPRS_max_dist">Maximal distance between center of GPR and 
	/// new observation</param>
	/// <param name="ESN_units">Units of the ESN</param>
	/// <param name="ESN_radius">Spectral Radius of the ESN</param>
	/// <param name="actuator_hypers">Hyperparameters for the covar.
	/// function. Each row corresponds to hyperparameters for one actuator.
	/// (0): sigma = assumed noise in input
	/// (1): theta = "heightscale" of exponential kernel
	/// (2-end): Lengthscales for exp. kernel. 
	/// They are used as an initial guess when performing ARD.</param>
	/// <param name="goal_set">Each row corresponds to a goal for goal 
	/// babbling</param>
	/// <param name="robo">The robot</param>
	/// <param name="step_time">(in milliseconds)</param>
	/// <param name="delay_steps">Number of delay steps assumed for delay 
	/// learning</param>
	/// <param name="num_pred">Number of parallel predictions from local GPRs
	/// </param>
	/// <param name="multi">True: same hyperparameters for all GPRs</param>
	/// <param name="rand_sparse">Int between 0,10 which determines the mean 
	/// amount of actuators affected by each random action (0 - all, 10 - none)
	/// </param>
	/// <param name="perturbation">Double between 0,1. Determines the amount 
	/// perturbation in goal babbling</param>
	/// <param name="rand_lenn">number of steps with constant noise</param>
	/// <param name="min_var">minimal uncertainty in prediction to include new 
	/// data point in the covariance matrix</param>
	Controller(int GPRs_max, int GPRs_size, 
			   double GPRs_max_dist,std::vector<VectorXd> *actuator_hypers, 
			   std::vector<VectorXd> goal_set, IRobot &robo, int step_time, 
			   int delay_steps, int num_pred, bool multi,
			   int rand_sparse, double perturbation, int rand_lenn,
			   double min_var);
	/// <summary> Randomly activates the robot to get sensory information for 
	/// the reservoir-warmup </summary>
	/// <param name="esn_file">Load a previous ESN from this file<\param>
	void ESN_warmup(int warmup_steps, std::string esn_file="", 
					bool use_ip=true);
	/// <summary> Performs Automatic Relevance Determination of each input
	/// dimension for one actuator. The necesary data is sampled by randomly
	/// moving the robot. Results are saved in the corresponding
	/// lscales-row</summary>
	/// <param name="max_step">Number of samples</param>
	/// <param name="global">ARD only on sigma and theta</param>
	void ARD(int max_step, bool global);
	/// <summary> Learns for some steps the desired goals.</summary>
	/// <param name="rand_exploration">Amount of initial steps of random 
	/// exploration. Range: [0,1]</param>
	/// <param name="substitute">True->Old observation may be subsituted by new
	/// one</param>
	void learn(int steps, double rand_exploration, bool substitute);
	/// <summary> Follows a given trajectory with the learnt models.
	/// Matrix set up similar to goals.</summary>
	/// <param name="trajectory">Vector of goals to follow</param>
	/// <param name="times">Number of times the trajectory should be repeated
	/// </param>
	/// <param name="filename">File to save trajectory in</param>
	/// <param name="infostring">File starts with this string</param>
	/// <param name="interaction">Follow user-given trajectory</param>
	/// <param name="perturb">At the beginning of each trajectory, a 
	/// perturbation is applied</param>
	/// <returns>Root mean squared error</returns>
	double follow(const std::vector<VectorXd> &trajectory, int times, 
				  std::string filename="", std::string infostring="", 
				  bool interaction=false, bool perturb=false);
};

#endif
