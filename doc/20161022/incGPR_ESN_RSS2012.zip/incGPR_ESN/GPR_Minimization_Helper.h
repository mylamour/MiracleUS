#ifndef GPR_MINIMIZATION_HELPER_H
#define GPR_MINIMIZATION_HELPER_H

#include "GPR.h"

using Eigen::VectorXd;
using Eigen::MatrixXd;

/// <summary>This class acts as a kind of wrapper for the GPR-Class so
/// it can be used by the Conjugate Gradient Descent algorithm. </summary>
class GPR_Minimization_Helper : public GPR{
	// Backups of the data to learn on, because the covariance matrix has 
	// to be computed from scratch every time the parameters change
	std::vector<VectorXd> & backup_obs;
	VectorXd & backup_tar;
public:
	/// <summary>See the GPR-Constructor for parameter-details</summary>
	GPR_Minimization_Helper(VectorXd *hypers, VectorXi obs_params,
							std::vector<VectorXd> &observations, 
							VectorXd &target);
	/// <summary>Wrapper for ll used by cg-descent</summary>
	/// <param name="params">Rowvector of hyperparameters</param>
	/// <returns>Returns log likelihood of lengthscales</param>
	double operator() (VectorXd &params);
	/// <summary>Wrapper for llp used by cg-descent</summary>
	/// <param name="params">Rowvector of hyperparameters</param>
	/// <param name="deriv">Rowvector for the computed ll-derivative</param>
	void df(VectorXd &params, VectorXd &deriv);
};

#endif