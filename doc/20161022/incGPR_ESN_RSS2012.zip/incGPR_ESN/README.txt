This program is a modular implementation written by Christoph Hartmann of the learning architecture described in the paper "Real Time Inverse Dynamics Learning based on Echo State Gaussian Process Regression" to be published in the proceedings of the RSS 2012.

Disclaimer: This project is not always well-documented, suffers from an incremental coding process and some modules have not been tested thoroughly. 

For any questions, please contact: chrhartm@uos.de

To get the program running, please follow these steps:
1. Install boost [1] (1.48 or higher) for threads and timers
2. Install ode [2] (0.11.1 or higher) for the physics simulation and visualization
2.1 enable double precision
2.2 also create demos to get the drawstuff library for visualization
3. To use the Kinect implementation, install:
3.1 OpenCV [3]
3.2 OpenNI [4]
4. Fix the dependencies in the CMakeList.txt by resetting all paths
4.1 Also make sure that the fn.path_to_textures variable in Sim_Arm.cpp is set correctly (default = "../ode-0.12/drawstuff/textures")
5. Use CMake to generate makefiles or project files (I use Visual Studio)
6. If using Windows, make sure that the PATH-variable contains the path to your boost and ode (ode_double[d], drawstuff[d] [d for debug]) libs or copy them to your make directory
7. Build the project
8. Run the project with the first command line argument being a parameter file

Some Notes:
- Each parameter is shortly characterized at the beginning of the main.cpp
- The file sim_config.h provides some parameters that determine which platform is used, if data should be logged and if there should be some visualization. This always requires a rebuild.
- The SORN and variance integration (min_var) parts were never extensively tested and not used
- The CSockClient was written by Shuhei Ikemoto
- The basics of the InputKinect-Class (without the tracking algorithm) were written by Norman Link

[1] http://www.boost.org/doc/libs/1_49_0/doc/html/bbv2/installation.html
[2] http://ode-wiki.org/wiki/index.php?title=Manual:_Install_and_Use
[3] http://opencv.willowgarage.com/wiki/InstallGuide
[4] https://github.com/OpenNI/OpenNI