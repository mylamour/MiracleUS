#include "Eigen/Dense"
#include "GPR.h"
#include <iostream>

using namespace Eigen;

double GPR::kernel(const VectorXd &x1, const VectorXd &x2) const {
	return kernel(x1, x2, hypers);
}

GPR::GPR(VectorXd *hyperr) : hypers(hyperr){
	opt_parameters = VectorXi::Zero(0);
	init();
}

GPR::GPR(VectorXd *hyperr, VectorXi &opt_parameterss) : hypers(hyperr), 
										opt_parameters(opt_parameterss) {
	init();
}

void GPR::init(){
	last_llp = VectorXd::Zero(opt_parameters.size());
	last_llp_hyper = VectorXd::Zero((*hypers).size());
	last_ll_hyper = VectorXd::Zero((*hypers).size());
}

GPR::~GPR() {}

void GPR::batch_learn(const std::vector<VectorXd> &obs, 
					  const VectorXd &target){
	this->obs = obs;
	this->target = MatrixXd(target);

	int size = obs.size();
	covar.resize(size,size);

	// Compute covariances for all observations
	for(int i=0; i<size; i++){
		// Covariances are symetric -> save loop time
		for(int j=i; j<size; j++){
			covar(i,j) = kernel(obs[i],obs[j]);
			// Add noise term for identical observations
			if (i==j){
				// hyper(0) is sigma
				covar(i,j) += (*hypers)(0);
			}
			else{
				covar(j,i) = covar(i,j); 
			}
		}
	}
	inv = covar.topLeftCorner(size,size).inverse();
	pre_predict = inv.topLeftCorner(size,size)*target;
}

double GPR::predict(const VectorXd &obsNew) const{
	int size = obs.size();
	RowVectorXd covarObsNew(size);

	for(int i=0; i<size; i++){
		covarObsNew(i) = kernel(obsNew, obs[i]);
	}
	return covarObsNew*pre_predict;
}

double GPR::log_likelihood(){
	last_ll = -0.5*target.transpose()*inv.topLeftCorner(obs.size(),
														obs.size())*target
		   -0.5*log(covar.topLeftCorner(obs.size(),obs.size()).determinant()); 
	last_ll_hyper = (*hypers);
	return last_ll; 
	// Constant -N/2*ln(2*M_PI) left out as its irrelevant for minimization
}

void GPR::log_likelihood_prime(VectorXd &llp){
	int size = obs.size();
	int param_size = opt_parameters.size();
	double tmp;
	double square;
	MatrixXd alpha = inv.topLeftCorner(size,size)*target;
	MatrixXd dK = MatrixXd::Zero(size,size);
	MatrixXd tmpM;
	for(int pp=0; pp<param_size; pp++){
		// Get derivative only for parameters to be optimized
		int p = opt_parameters(pp);
		// p is sigma
		if(p==0){
			dK = MatrixXd::Identity(size,size);
		}
		else{
			for(int i=0; i<size; i++){
				for(int j=i; j<size; j++){
					tmp = covar(i,j);
					if (j==i){
						tmp -= (*hypers)(0);
					}
					// p is heightscale
					if(p==1){
						dK(i,j) = dK(j,i) = tmp / (*hypers)(1);
					}
					// p is a lengthscale
					else{
						square = obs[i](p-2)-obs[j](p-2);
						dK(i,j) = dK(j,i) = tmp*(-0.5)*square*square;
					}
				}
			}
		}
		llp(pp) = ((alpha*alpha.transpose()-inv.topLeftCorner(size,size))
					*dK).trace()*0.5;
		last_llp(pp) = llp(pp);
	}
	last_llp_hyper = (*hypers);
}

double GPR::kernel(const VectorXd &x1, const VectorXd &x2, 
					   const VectorXd *hyperr){
	if((*hyperr).tail(1)(0) == 1){ // -> exp. kernel
		//     -theta-            -----lengthscales-----------
		return (*hyperr)(1)*exp(-0.5*((*hyperr).segment(2,
				(*hyperr).size()-3).array()*(x1-x2).array().square()).sum());
	}
	else if((*hyperr).tail(1)(0) == 0){ // -> linear kernel
		return x1.transpose()*x2;
	}
	else{
		std::cout << "Last hyperparameter wrong (1:expKernel, 0:linKernel)" 
				  << std::endl;
		return 0;
	}
}

int GPR::size(){
	return target.size();
}
