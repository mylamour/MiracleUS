#ifndef HOSODA_ARM_H
#define HOSODA_ARM_H

#include "sim_config.h"
#include "Eigen/Dense"
#include <iostream>
#include <fstream>
#include "ESN.h"
#include "IRobot.h"
#include <boost/thread.hpp>  
#include <boost/timer/timer.hpp>
#include <queue>
#include "CSockClient.h"
#ifdef HOSODA_KINECT
	#include "InputKinect.h"
#endif
#ifdef REALTIME
	#include <rtai.h>
	#include <rtai_lxrt.h>
	#include <rtai_sched.h>
	#include <rtai_msg.h>
	#include <rtai_netrpc.h>
	#include <netinet/in.h>
	#include <arpa/inet.h>
	#include <sys/time.h>
#endif


#include <stdio.h>
#include <stdlib.h>

#include <sstream>
#include <fstream>

using Eigen::VectorXd;
using Eigen::MatrixXd;
using Eigen::Matrix;

// Sockets
static CSockClient arm_sock;
static CSockClient vision_sock;

static const int num_sensors = 17+17;
static const int num_actuators = 17;
static const double loop_step = 0.005;
#ifdef HOSODA_KINECT
	static const double min_goal_dist = 0.005;
#else
	static const double min_goal_dist = 0.05*100;
#endif

// global variables for thread communication
static boost::mutex mutex_all;
static boost::condition_variable initialized;
static bool goal_reached_bool;
static Matrix<double,3,1> disp_goal;
static Matrix<double,3,1> body_color;
static Matrix<double,3,1> arm_pos;
static Matrix<double,num_actuators,1> last_action;
static std::queue<VectorXd> action_queue;
static std::queue<boost::posix_time::ptime> delay_queue;
static boost::posix_time::microseconds delay(0);
static ESN *esn;
static boost::posix_time::microseconds esn_step_time(0);
static boost::timer::cpu_timer esn_timer;
static bool feedback;
static VectorXd * esn_state;
static VectorXd * last_input;
static boost::thread * sim_thread;
static bool exit_thread(false);
static bool thread_stopped(false);
static boost::timer::cpu_timer step_timer;
static std::ofstream step_logfile;
static std::ofstream hosoda_pos;
static boost::timer::cpu_timer socket_timer;
static Matrix<double,num_actuators,1>  sensorSave;
static int counterInt(0);
static bool paused;
static std::ofstream delay_log;
static boost::timer::cpu_timer global_timer;
#ifdef HOSODA_KINECT
	static InputKinect * kinect;
#endif

#ifdef REALTIME
	static RT_TASK *rt_task;
#endif

using namespace Eigen;

static void simStep (int pause, int step)
{
	//Check Delay
	/*
	if(counterInt%100 == 0 && counterInt <=1000){
		if(counterInt == 0)
			sensorSave = VectorXd::Zero(num_actuators);
		mutex_all.lock();
		action_queue.push(VectorXd::Ones(num_actuators)*0.3);
		delay_queue.push(boost::posix_time::microsec_clock::universal_time());	
		mutex_all.unlock();	
	}
	*/

	unsigned int time = 0;
	#ifdef REALTIME
		rt_task_wait_period();
	#else
		time = step_timer.elapsed().wall/1000;
		boost::this_thread::sleep(
			boost::posix_time::microseconds(loop_step*1000*1000-time));
	#endif
	if(logfiles){
		time = step_timer.elapsed().wall/1000;
		step_timer.start();
		if(esn->get_ip()){
			step_logfile << time << std::endl;
		}
		hosoda_pos << arm_pos[0] << " " << arm_pos[1] << " " << disp_goal[0] 
		<< " " << disp_goal[1] << std::endl;
	}
	else{
		step_timer.start();
	}
	if(!pause){
		// Read and write to global vars
		int input_size = num_sensors;
		if(feedback){
			input_size += num_actuators;
		}
		VectorXd input(input_size);
		if((!(action_queue.empty())) && 
			(boost::posix_time::microsec_clock::universal_time()
			 -delay_queue.front() >= delay)){
			if(logfiles){
				delay_log << global_timer.elapsed().wall/(1000.0*1000.0*1000.0) 
						  << " " << last_action.transpose() << " " 
						  << (*last_input).transpose() << std::endl;	
			}
			mutex_all.lock();
			VectorXd action = action_queue.front();
			action_queue.pop();
			delay_queue.pop();
			mutex_all.unlock();

			// Make actionstring and send
			std::stringstream action_message("");
			action_message << "p(";
			for(int i=0; i<num_actuators; i++){
				action_message << action(i);
				if(i!=num_actuators-1){
					action_message << ",";
				}
			}
			action_message << ")";
			std::string action_string;
			action_message >> action_string;
			// Send actionstring to Robot
			socket_timer.start();
			int msg = arm_sock.writeToSock(action_string.c_str(),
										   action_string.size());
			//std::cout << "Send Action: " << socket_timer.elapsed().wall/1000 << "microsec." << std::endl;

			// Read sensor message reply from action message
			double tmp = 0;
			char sep = ',';
			int inputindex = 0;
			char message[1000];
			socket_timer.start();
			int read_size = arm_sock.readFromSockWithSelect(message, 999);
			//std::cout << "Read Sensor " << socket_timer.elapsed().wall/1000 << "microsec." << std::endl;	
			if(read_size > 0){
				std::stringstream tmp_ss;
				for(int i=0;i<read_size;i++){
					char tmpchar = message[i];
					if(tmpchar == 'o'){
						inputindex = 0;
					}
					if(tmpchar == 'r'){
						inputindex = 17;
					}
					else if(tmpchar == '('){
						//pass
					}
					else if(tmpchar != sep){
						tmp_ss << message[i];
					}
					else if((tmpchar == sep) || (tmpchar == ')')){
						tmp_ss >> tmp;
						tmp_ss.str(std::string());
						tmp_ss.clear();
						input(inputindex) = tmp;
						inputindex++;				
					}
				}

					if(feedback){
						input.tail(num_actuators) = last_action;
					}
					(*last_input) = input;
				}
		}

		// Read vision information
		#ifdef HOSODA_KINECT
			VectorXd position = VectorXd::Ones(3);
			VectorXd goal = disp_goal;
			goal(0) *= 640;
			goal(1) *= 480;
			VectorXd goal_color = body_color*255;
			VectorXd tmp_usr_goal = VectorXd::Zero(3);
			kinect->get_position(position,goal,goal_color,tmp_usr_goal);
			tmp_usr_goal(0) /= 640.0;
			tmp_usr_goal(1) /= 480.0;
			mutex_all.lock();
			position(0) /= 640.0;
			position(1) /= 480.0;
			//(*user_goal) = tmp_usr_goal;
			arm_pos = position;
			mutex_all.unlock();
		#else
			char message[1000];
			socket_timer.start();
			int read_size = vision_sock.readFromSockWithSelect(message, 999);
			//std::cout << "Read Vision: " << socket_timer.elapsed().wall/1000 << "microsec." << std::endl;
			std::stringstream tmp_ss;
			for(int i=0; i<read_size; i++){
				tmp_ss << message[i];
			}
			//Format: "@client % x y points"
			std::string tmpstring;
			tmp_ss >> tmpstring >> tmpstring;
			mutex_all.lock();
			tmp_ss >> arm_pos[0];
			tmp_ss >> arm_pos[1];
			mutex_all.unlock();
			tmp_ss >> tmpstring;
		#endif

		if((disp_goal-arm_pos).norm() < min_goal_dist){
			goal_reached_bool = true;
		}
		boost::posix_time::microseconds timer_time(esn_timer.elapsed().wall
												   /1000);
		#ifdef REALTIME
			if(step%(esn_step_time.total_microseconds()
				/(int)(loop_step*1000*1000)) == 0){
		#else
			if((esn_step_time - timer_time).is_negative()){
		#endif	
				esn_timer.start();	
				mutex_all.lock();
				esn->step(*last_input);
				esn->get_state((*esn_state));
				mutex_all.unlock();
			}

		//measure delay
		/*
		if(counterInt != -1){
			counterInt ++;
			if(counterInt % 10 == 0)
				std::cout <<  counterInt/10 << " " << (*last_input).transpose() 
						  << std::endl;
			if(counterInt == 2000) counterInt = -1;
		}
		*/
	}
}

static void stop(){
	if(thread_stopped) return;
	std::cout << "Destroy Simulation" << std::endl;
	if(logfiles){
		step_logfile.close();
		hosoda_pos.close();
		delay_log.close();
	}
	// close socket
	int msg = arm_sock.writeToSock( ":", 1);
	arm_sock.terminateSocket();
	delete esn;
	delete esn_state;
	delete last_input;
	#ifdef HOSODA_KINECT
		delete kinect;
	#else
		msg = vision_sock.writeToSock("b.r -;", 6);
		vision_sock.terminateSocket();
	#endif
}

static void simLoop(){
	boost::this_thread::at_thread_exit(stop);
	#ifdef REALTIME
		double d = loop_step*1e+9;
		// Enable non-root hrt
		rt_allow_nonroot_hrt();
		// Create realtime task
		if( (rt_task=rt_task_init_schmod(nam2num("ARMTH"),1,1024,1024,
										 SCHED_FIFO, 2)) == NULL ){
			fprintf(stderr,"Failed to create the realtime task.\n");
			fprintf(stderr,"Make sure RTAI modules are inserted\n");
			return;
		}    
		rt_set_runnable_on_cpuid(rt_task,1);
		// Start a timer anyhow
		rt_set_oneshot_mode();
		//rt_set_periodic_mode();
		if(!rt_is_hard_timer_running()){
			start_rt_timer( 0 );
			std::cout << "start_rt_timer" << std::endl;
		}
		// Configure the details of the timer
		if( rt_task_make_periodic_relative_ns(rt_task, 0, d) != 0 ){
			fprintf(stderr,"Failed to configure the timer\n");
		}
	#endif
	global_timer.start();
	step_timer.start();
	
	initialized.notify_all();
	for(int i=0; !exit_thread; i++){
		simStep(paused, i);		
	}
	stop();
	#ifdef REALTIME
		rt_task_delete(rt_task);
	#endif
	thread_stopped = true;
}

class Hosoda_Arm : public IRobot{
public:
	Hosoda_Arm(int delay, bool feedback, int esn_neurons, 
			   double spectral_radius, double input_scale, bool direct, 
			   int esn_step_timee, bool permutation);
	void get_actuator_range(MatrixXd &actuator_ranges);
	int get_number_actuators();
	int get_number_sensors();
	void get_sensors(VectorXd &sensors);
	void get_pos(VectorXd &position);
	void get_goal(VectorXd & user_goal);
	void set_actuators(const VectorXd &values);
	void display_goal(VectorXd &goal);
	void set_color(VectorXd &color);
	bool goal_reached();
	boost::thread * get_thread();
	ESN & get_esn();
	void stop_sim();
	bool stopped();
	void pause(bool paused);
};

#endif
