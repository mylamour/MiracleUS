#ifndef IROBOT_H
#define IROBOT_H

#include "Eigen/Dense"
#include "ESN.h"

using Eigen::VectorXd;
using Eigen::MatrixXd;

/// <summary>Abstract Base Class for the robot used by the controller. </summary>
class IRobot{
public:
	/// <returns>Each row of the matrix should correspond to one actuator.
	/// First column: min actuator values. Second: max.</returns>
	virtual void get_actuator_range(MatrixXd &actuator_ranges) = 0;
	virtual int get_number_actuators() = 0;
	virtual int get_number_sensors() = 0;
	/// <returns>Row vector of all sensor values</returns>
	virtual void get_sensors(VectorXd &sensors) = 0;
	virtual void get_goal(VectorXd &goal) = 0;
	/// <param name="values">Row vector of actuator values</param>
	virtual void set_actuators(const VectorXd &values) = 0;
	virtual void get_pos(VectorXd &position) = 0;
	virtual void display_goal(VectorXd &goal) = 0;
	virtual void set_color(VectorXd &color) = 0;
	virtual bool goal_reached() = 0;
	virtual ESN & get_esn() = 0;
	virtual void pause(bool pause) = 0;
};

#endif