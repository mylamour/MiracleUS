/*
 * <class CSockClient>
 *
 * 2007/04/05 Shuhei IKEMOTO
 *
 * Modified to work on both Linux and Windows by Christoph Hartmann
 */

#ifndef _CSOCKCLIENT_H
#define _CSOCKCLIENT_H

// for socket
#ifdef WIN32
#pragma comment(lib, "Ws2_32.lib")
#include <WinSock2.h>
#else
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <unistd.h>
#endif
#include <stdio.h>
#include <stdlib.h>

#define DEFAULT_IP "localhost"
#define DEFAULT_PORT 10000

class CSockClient
{
  protected:
	// for socket
	int sockfd;
	int len;
	struct sockaddr_in address;
	// for select
	fd_set fds;
	struct timeval tv;

  public:
	CSockClient();
	virtual ~CSockClient();

	int initializeSocket(char* server_ip = DEFAULT_IP, 
						 int port = DEFAULT_PORT);
	int terminateSocket();

	int writeToSock(const char* writeBuf, int size);
	int readFromSock(char* readBuf, int size);
	int readFromSockWithSelect(char* readBuf, int size);
};

#endif //_CSOCKCLIENT_H
