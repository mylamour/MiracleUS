#include "sim_config.h"

#if defined AFFETTO || defined HOSODA_KINECT
#pragma once

//#pragma warning(disable:4005)
#include <XnCppWrapper.h>
//#pragma warning(default:4005)
#include <opencv2\opencv.hpp>

#include "Eigen/Dense"

using Eigen::VectorXd;
using Eigen::MatrixXd;

/// <summary>This class preprocesses Kinect-data and performs simple tracking
/// of markers on the robot end-effectors</summary>
class InputKinect
{
public:
	/// <param name="lower">Lower bound for thresholding the hsv-image 
	/// (3d-vector)</param>
	/// <param name="upper">Upper bound for thresholding the hsv-image</param>
	InputKinect(VectorXd & lower, VectorXd & upper, bool videoo);

	~InputKinect(void);

	bool isInit() const;

	// public interface
	void setDeviceIndex(int);
	void setRegisterDepth(bool);
	int getDeviceIndex() const;
	bool getRegisterDepth() const;

	/// <param name="position">Position of the end-effector</param>
	/// <param name="goal">Position of goal (for visualization)</param>
	/// <param name="goal_color">Color of the goal-visualization</param>
	/// <param name="user_goal">Position of goal-marker</param>
	void get_position(VectorXd & position, VectorXd & goal, 
					  VectorXd & goal_color, VectorXd & user_goal);

protected:
	void iInit();
	void iGrabImages();

private:
	void createDepthGenerator();
	void createImageGenerator();
	void createMapGeneratorNode(xn::MapGenerator& generator, 
								const xn::NodeInfoList& list);
	void update();
		
	bool m_isInit;

	xn::Context			m_context;
	xn::DepthGenerator	m_depthGenerator;
	xn::DepthMetaData	m_depthMetaData;
	xn::ImageGenerator	m_imageGenerator;
	xn::ImageMetaData	m_imageMetaData;
	xn::UserGenerator	m_userGenerator;
	int					m_maxDepth;
	cv::Size			m_size;
	XnPoint3D*			m_imgPoints;
	XnPoint3D*			m_worldPoints;

	//NEW
	cv::Mat m_img3d;//(480, 640, CV_32FC3)
	cv::Mat m_imgColor;//(480, 640, CV_8UC3);
	cv::Mat m_imgDepth;//(480, 640, CV_32FC1);
	cv::Scalar lower_bound;
	cv::Scalar upper_bound;
	cv::Scalar lower_bound_goal;
	cv::Scalar upper_bound_goal;
	VectorXd last_pos;
	VectorXd last_goal;
	bool video;
	bool skipped;
	bool skipped_goal;
	cv::VideoWriter video_writer;
	cv::Size small_size;

	// parameters
	int					m_deviceIndex;
	bool				m_registerDepth;
};
#endif
