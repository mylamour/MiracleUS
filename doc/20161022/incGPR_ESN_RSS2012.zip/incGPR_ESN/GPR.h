#ifndef GPR_H
#define GPR_H

#include "Eigen/Dense"
#include <vector>

using Eigen::VectorXd;
using Eigen::MatrixXd;
using Eigen::VectorXi;

/// <summary>Base class for Gaussian Process Regression.</summary>
class GPR{
protected:
	MatrixXd covar;
	MatrixXd inv;
	std::vector<VectorXd> obs;
	VectorXd target;
	VectorXd pre_predict;
	/// <summary>Private wrapper of the kernel for computing internal 
	///	lengthscales</summary>
	double kernel(const VectorXd &x1, const VectorXd &x2) const;
	double last_ll;
	VectorXd last_llp;
	VectorXd *hypers;
	VectorXd last_ll_hyper;
	VectorXd last_llp_hyper;
	VectorXi opt_parameters;
	void init();
public:
	/// <param name="hyper">Hyperparameters for covariance function.
	/// See Controller.h for details.</param>
	GPR(VectorXd *hypers);
	/// <param name="opt_parameters"> Vector of numbers of parameters to be
	/// optimized. See controller for usage. </param>
	GPR(VectorXd *hypers, VectorXi &opt_parameters);
	~GPR();
	/// <summary>Creates the covariance matrix and the inverse for the
	/// given observations and targets.</summary>
	/// <param name="obs">Observations. row = single observation. 
	/// column = observation values.</param>
	/// <param name="target">Rowvector with targets for each obs-row</pram>
	void batch_learn(const std::vector<VectorXd> &obs, const VectorXd &target);
	/// <summary>Returns most likely prediction for new observation</summary>
	/// <param name="obsNew">Rowvector with one new observation</param>
	double predict(const VectorXd &obsNew) const;
	/// <summary>Returns the log likelihood of the lengthscales given the
	/// observations and targets accumulated so far.</summary>
	double log_likelihood();
	/// <summary>Computes the first derivative of the log likelihood.
	/// Formulas for ll and llp adapted from RasmussenWilliamsGP2006</summary>
	/// <param name="llp">Rowvector for the results</param>
	void log_likelihood_prime(VectorXd &llp);
	/// <summary>Static exponential kernel that returns the distance 
	/// between the rowvectors x1 and x2 given hyper with heightscale and
	/// the lengthscales.</summary>
	double static kernel(const VectorXd &x1, const VectorXd &x2, 
							 const VectorXd *hypers);
	int size();
};

#endif