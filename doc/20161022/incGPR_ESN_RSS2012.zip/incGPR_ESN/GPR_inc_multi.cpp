#include "GPR_inc_multi.h"
#include "GPR_inc.h"
#include <iostream>

using namespace Eigen;

GPR_inc_multi::GPR_inc_multi(VectorXd *hypers, int max_sizee, 
							 int num_actuators, bool comp_var):
	GPR_inc(hypers, max_sizee), compute_variance(comp_var){
	for(int i=0; i<num_actuators; i++){
		targets.push_back(VectorXd::Zero(0));
	}
}

void GPR_inc_multi::inc_learn(const VectorXd &obss, const VectorXd & target){
	int oldsize = obs.size();
	if(oldsize >= max_size){
		return;
	}
	int size = targets[0].size();
	for(unsigned int i=0; i<targets.size(); i++){
		targets[i].conservativeResize(size+1);
		targets[i](size) = target(i);
	}
	GPR_inc::inc_learn(obss,target[0]);
}

void GPR_inc_multi::substitute(const VectorXd &obss, const VectorXd &target, 
							   int del_obs){
	for(unsigned int i=0; i<targets.size(); i++){
		targets[i](del_obs) = target(i);
	}
	GPR_inc::substitute(obss,target[0],del_obs);
}

double GPR_inc_multi::predict(const VectorXd & obsNew, VectorXd & prediction){
	unsigned int size= obs.size();
	RowVectorXd covarObsNew(size);
	for(unsigned int i=0; i<size; i++){
		covarObsNew(i) = kernel(obsNew, obs[i]);
	}
	prediction = VectorXd::Zero(targets.size());
	RowVectorXd tmp = covarObsNew*inv.topLeftCorner(size,size);
	for(unsigned int i=0; i<targets.size(); i++){
		prediction(i) = tmp*targets[i];
	}
	if(compute_variance){
		return (kernel(obsNew,obsNew)+(*hypers)(0))
				-tmp*covarObsNew.transpose();
	}
	else{
		return 0;
	}
}