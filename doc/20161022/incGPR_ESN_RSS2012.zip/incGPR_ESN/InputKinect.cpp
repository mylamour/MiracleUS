#include "sim_config.h"
#if defined AFFETTO || defined HOSODA_KINECT
#include "InputKinect.h"
#include <iostream>

InputKinect::InputKinect(VectorXd & lower, VectorXd & upper, bool videoo): 
	m_isInit(false), m_imgPoints(0), m_worldPoints(0)
{
	// hue from 0-180, i.e. multiply by 0.5
	//Yellow Marker = ca.20 in HSV
	lower_bound = cv::Scalar(20,100,100);
	upper_bound = cv::Scalar(30,255,255);
	//Green Marker = ca.120 in HSV
	lower_bound_goal = cv::Scalar(60,50,50);
	upper_bound_goal = cv::Scalar(80,255,255);
	//200.200.200
	for(int i=0; i<3; i++){
		lower_bound(i) = lower(i);
		upper_bound(i) = upper(i);
	}

	video = videoo;

	last_pos = VectorXd::Ones(3);
	last_goal = VectorXd::Ones(3);
	//cv::namedWindow("Threshold");
	m_deviceIndex = 0;
	m_registerDepth = true;
	skipped = false;
	iInit();
}

InputKinect::~InputKinect(void)
{
	delete[] m_imgPoints;
	m_imgPoints = 0;
	delete[] m_worldPoints;
	m_worldPoints = 0;
	m_context.Release();
	m_depthGenerator.Release();
	m_imageGenerator.Release();
	video_writer.~VideoWriter();
	m_imgColor.release();
	m_imgDepth.release();
	m_img3d.release();
}
	
void InputKinect::setDeviceIndex(int index)
{
	if (isInit())
		std::cout << "already init" << std::endl;

	m_deviceIndex = index;
}

void InputKinect::setRegisterDepth(bool registerDepth)
{
	m_registerDepth = registerDepth;
}

int InputKinect::getDeviceIndex() const
{
	return m_deviceIndex;
}

bool InputKinect::getRegisterDepth() const
{
	return m_registerDepth;
}

void InputKinect::iInit()
{
	if (isInit())
		std::cout << "already init" << std::endl;

	XnStatus rc = XN_STATUS_OK;

	// get OpenNI version
	std::cout << "using OpenNI " << XN_BRIEF_VERSION_STRING << std::endl;

	// init
	rc = m_context.Init();
	if (rc != XN_STATUS_OK) {
		std::cout << xnGetStatusName(rc) << ": " << xnGetStatusString(rc) 
				  << std::endl;
		std::cout << "could not init" << std::endl;
	}

	// create generator nodes
	createDepthGenerator();
	createImageGenerator();
	
	// register depth to color image
	if (m_registerDepth)
		m_depthGenerator.GetAlternativeViewPointCap().SetViewPoint(m_imageGenerator);

	// check sizes
	//if (!areSizesEq(m_imgDepth, m_imgColor))
	//	std::cout << "image sizes are not equal" << std::endl;
		
	m_size = cv::Size(m_imgDepth.cols, m_imgDepth.rows);
	
	// start generating
	rc = m_context.StartGeneratingAll();
	if (rc != XN_STATUS_OK) {
		std::cout << xnGetStatusName(rc) << ": " << xnGetStatusString(rc) 
				  << std::endl;
		std::cout << "could not init" << std::endl;
	}
	std::cout << video << std::endl;
	if(video){
		double scale = 2.0;
		small_size = cv::Size((int)(m_size.width/scale),
							  (int)(m_size.height/scale));
		//PIM1
		video_writer = cv::VideoWriter("/log/affetto.mpeg",
								CV_FOURCC('P','I','M','1'),10,small_size,true);
	//	video_writer.open("./log/affetto.mpeg",CV_FOURCC('M','P','E','G'),10,small_size,true);
		std::cout << video_writer.isOpened() << std::endl;
	}
	m_isInit = true;
}

bool InputKinect::isInit() const
{
	return m_isInit;
}
	
void InputKinect::createDepthGenerator()
{
	XnStatus rc = XN_STATUS_OK;
	xn::NodeInfoList depthNodes;
	int i = 0;

	// get list of depth nodes
	rc = m_context.EnumerateProductionTrees(XN_NODE_TYPE_DEPTH, NULL, 
											depthNodes, NULL);
	if (rc != XN_STATUS_OK) {
		std::cout << xnGetStatusName(rc) << ": " << xnGetStatusString(rc) 
				  << std::endl;
		std::cout << "could not init" << std::endl;
	}
	
	// iterate over nodes
	for (xn::NodeInfoList::Iterator nodeIt = depthNodes.Begin(); nodeIt != 
		 depthNodes.End(); ++nodeIt) { 
		const xn::NodeInfo& info = *nodeIt; 
		const XnProductionNodeDescription& desc = info.GetDescription();

		std::cout << "found device " << i << ": " << desc.strVendor << " " 
				  << desc.strName << std::endl;
		i++;
	}
		
	if (i == 0)
		std::cout << "no modules found" << std::endl;
	
	// create node
	createMapGeneratorNode(m_depthGenerator, depthNodes);

	// set output mode
	XnMapOutputMode depthOutputMode;
	depthOutputMode.nXRes = XN_VGA_X_RES;
	depthOutputMode.nYRes = XN_VGA_Y_RES;
	depthOutputMode.nFPS = 30;
	rc = m_depthGenerator.SetMapOutputMode(depthOutputMode);
	if (rc != XN_STATUS_OK) {
		std::cout << xnGetStatusName(rc) << ": " << xnGetStatusString(rc) 
				  << std::endl;
		std::cout << "could not init" << std::endl;
	}
	
	// get additional meta data
	m_depthGenerator.GetMetaData(m_depthMetaData);
	
	// get size
	cv::Size depthSize(m_depthMetaData.XRes(), m_depthMetaData.YRes());
	std::cout << "Size: " << depthSize.width << "x" << depthSize.height 
			  << std::endl;;
	m_maxDepth = m_depthMetaData.ZRes();
	
	// create images
	m_imgDepth = cv::Mat(depthSize, CV_32FC1);
	m_img3d = cv::Mat(depthSize, CV_32FC3);
	
	// create conversion tables
	m_imgPoints = new XnPoint3D[depthSize.width * depthSize.height];
	m_worldPoints = new XnPoint3D[depthSize.width * depthSize.height];
}

void InputKinect::createImageGenerator()
{
	XnStatus rc = XN_STATUS_OK;

	xn::NodeInfoList imageNodes;
	rc = m_context.EnumerateProductionTrees(XN_NODE_TYPE_IMAGE, NULL, 
											imageNodes, NULL);
	if (rc != XN_STATUS_OK) {
		std::cout << xnGetStatusName(rc) << ": " << xnGetStatusString(rc) 
				  << std::endl;
		std::cout << "could not init" << std::endl;
	}
		
	// create nodes
	createMapGeneratorNode(m_imageGenerator, imageNodes);

	// set color output mode
	XnMapOutputMode colorOutputMode;
	colorOutputMode.nXRes = XN_VGA_X_RES;
	colorOutputMode.nYRes = XN_VGA_Y_RES;
	colorOutputMode.nFPS = 30;
	rc = m_imageGenerator.SetMapOutputMode(colorOutputMode);
	if (rc != XN_STATUS_OK) {
		std::cout << xnGetStatusName(rc) << ": " << xnGetStatusString(rc) 
				  << std::endl;
		std::cout << "could not init" << std::endl;
	}

	// get additional data
	m_imageGenerator.GetMetaData(m_imageMetaData);
	
	cv::Size imageSize = cvSize(m_imageMetaData.XRes(), 
								m_imageMetaData.YRes());

	if (m_imageMetaData.PixelFormat() != XN_PIXEL_FORMAT_RGB24)
		std::cout << "pixel format is not RGB24" << std::endl;
	
	// create image
	m_imgColor = cv::Mat(imageSize, CV_8UC3);
}

void InputKinect::createMapGeneratorNode(xn::MapGenerator& generator, 
										 const xn::NodeInfoList& list)
{
	XnStatus rc = XN_STATUS_OK;
	int i = 0;
	bool created = false;
	for (xn::NodeInfoList::Iterator nodeIt = list.Begin(); 
		 nodeIt != list.End(); ++nodeIt) { 
		const xn::NodeInfo& info = *nodeIt; 
		const XnProductionNodeDescription& desc = info.GetDescription();

		if (i == m_deviceIndex) {
			xn::ProductionNode node;
			rc = m_context.CreateProductionTree(const_cast<xn::NodeInfo&>(info), 
												node);
			if (rc != XN_STATUS_OK) {
				std::cout << xnGetStatusName(rc) << ": " 
						  << xnGetStatusString(rc) << std::endl;
				std::cout << "could not init" << std::endl;
			}

			rc = info.GetInstance(generator);
			if (rc != XN_STATUS_OK) {
				std::cout << xnGetStatusName(rc) << ": " 
						  << xnGetStatusString(rc) << std::endl;
				std::cout << "could not init" << std::endl;
			}

			std::cout << "created [generator] " << generator.GetName() 
					  << std::endl;

			created = true;
		}

		i++;
	}

	if (!created || !generator.IsValid())
		std::cout << "no generator created" << std::endl;
}

void InputKinect::update()
{
	m_context.WaitAnyUpdateAll();
	m_depthGenerator.GetMetaData(m_depthMetaData);
	m_imageGenerator.GetMetaData(m_imageMetaData);
		
	// get depth map
	const XnDepthPixel* pDepth = m_depthMetaData.Data();
	const XnUInt8* pImage = m_imageMetaData.Data();

	for (int i = 0; i < m_size.height; i++) {
		for (int j = 0; j < m_size.width; j++) {
			
			// get depth pixel
			XnDepthPixel pix = *(pDepth++);
			float dist = pix / 1000.0f;
			m_imgDepth.ptr<float>(i)[j] = dist;

			m_imgPoints[i * m_size.width + j].X = (XnFloat)j;
			m_imgPoints[i * m_size.width + j].Y = (XnFloat)i;
			m_imgPoints[i * m_size.width + j].Z = (XnFloat)dist;

			// get color pixel
			XnUInt8 pixR = *(pImage++);
			XnUInt8 pixG = *(pImage++);
			XnUInt8 pixB = *(pImage++);

			uchar* row = m_imgColor.ptr<uchar>(i);
			row[j * 3 + 0] = pixB;
			row[j * 3 + 1] = pixG;
			row[j * 3 + 2] = pixR;
		}
	}

	// get 3d image
	m_depthGenerator.ConvertProjectiveToRealWorld(m_size.width * m_size.height,
		m_imgPoints, m_worldPoints);
	for (int i = 0; i < m_size.height; i++) {
		for (int j = 0; j < m_size.width; j++) {
			// NOTE: there seems to be an std::coutor with 3d coordinates here

			XnPoint3D worldPoint = m_worldPoints[i * m_size.width + j];
			float* row = m_img3d.ptr<float>(i);
			row[j * 3 + 0] = worldPoint.X;
			row[j * 3 + 1] = -worldPoint.Y;
			row[j * 3 + 2] = worldPoint.Z;
		}
	}
}

void InputKinect::get_position(VectorXd & position, VectorXd & goal, 
							   VectorXd & goal_color, VectorXd & user_goal){
	update();
	// Resize image
	cv::Mat small_imgColor = cv::Mat(small_size,CV_32FC3);
	cv::resize(m_imgColor,small_imgColor,small_size);
	// Threshold
	cv::Mat hsv_imgColor = cv::Mat(small_size,CV_32FC3);
	cv::cvtColor(small_imgColor,hsv_imgColor,CV_BGR2HSV);
	cv::Mat thresh = cv::Mat(small_size, CV_8U);
	/*
	if(lower_bound(0) > upper_bound(0)){
		uchar dist = 360-lower_bound(0);
		lower_bound(0) = 0;
		upper_bound(0) += dist;
		for(int i=0; i<hsv_imgColor.cols;i++){
			for(int j=0; j<hsv_imgColor.rows; j++){
				small_imgColor.ptr<uchar>(j)[i*3+0] += (small_imgColor.ptr<uchar>(j)[i]+dist)%400;
			}
		}
	}
	*/

	// Find Arm Marker
	cv::inRange(hsv_imgColor,lower_bound,upper_bound,thresh);
	// Find std	Contours
	std::vector<std::vector<cv::Point> > contours;
	cv::findContours(thresh,contours,cv::RETR_EXTERNAL,cv::CHAIN_APPROX_NONE);
	// Fill largest contour
	int maxlen = 0;
	int maxindex = 0;
	for(int i=0; i<contours.size(); i++){
		if(contours[i].size() > maxlen){
			maxlen = contours[i].size();
			maxindex = i;
		}
	}
	thresh.setTo(0);
	cv::drawContours(thresh,contours,maxindex,cv::Scalar(255),-1,8);
	// Get moments
	float m00 = cv::moments(thresh,true).m00;
	float m01 = cv::moments(thresh,true).m01;
	float m10 = cv::moments(thresh,true).m10;
	double scale = m_size.width/small_size.width;
	// Calculate Center
	float x = m10/m00*scale;
	float y = m01/m00*scale;
	// Get depth information
	float z = m_img3d.ptr<float>((int)y)[(int)x*3+2];

	// Find Goal Marker
	#ifdef AFFETTO
		thresh.setTo(0);
		cv::inRange(hsv_imgColor,lower_bound_goal,upper_bound_goal,thresh);
		// Find std	Contours
		std::vector<std::vector<cv::Point> > contours_goal;
		cv::findContours(thresh,contours_goal,cv::RETR_EXTERNAL,
						 cv::CHAIN_APPROX_NONE);
		// Fill largest contour
		maxlen = 0;
		maxindex = 0;
		for(int i=0; i<contours_goal.size(); i++){
			if(contours_goal[i].size() > maxlen){
				maxlen = contours_goal[i].size();
				maxindex = i;
			}
		}
		thresh.setTo(0);
		cv::drawContours(thresh,contours_goal,maxindex,cv::Scalar(255),-1,8);
		// Get moments
		m00 = cv::moments(thresh,true).m00;
		m01 = cv::moments(thresh,true).m01;
		m10 = cv::moments(thresh,true).m10;
	#endif
	VectorXd goal_marker = VectorXd::Zero(3);
	// Calculate Center
	goal_marker(0) = m10/m00*scale;
	goal_marker(1) = m01/m00*scale;
	// Get depth information
	goal_marker(2) = m_img3d.ptr<float>((int)goal_marker(1))[(int)goal_marker(0)
																		*3+2];

	// Write Positions into variables to return and adjust if necessary
	position(0) = x;
	position(1) = y;
	position(2) = z;

	for(int i=0; i<3; i++){
		if((x<=0) || (y <= 0)){
			position.head(3) = last_pos;
		}
		if((goal_marker(0)<=0) || (goal_marker(1) <= 0)){
			goal_marker = last_goal;
		}
		//TODO make threshold nicer
		if(z <= 0
		#if defined AFFETTO || defined HOSODA_KINECT
			|| z>1
		#endif
		){
			position(2) = last_pos(2);
		}
		if(goal_marker(2) <= 0
		#if defined AFFETTO || defined HOSODA_KINECT
			|| goal_marker(2)>1
		#endif
		){
			goal_marker(2) = last_goal(2);
		}
	}
	if((position.head(3)-last_pos).norm() > 100 && !skipped){
		skipped = true;
		position.head(3) = last_pos;
		x = position(0);
		y = position(1);
	}
	else{
		skipped = false;
	}
	if((goal_marker-last_goal).norm() > 100 && !skipped_goal){
		skipped_goal = true;
		goal_marker = last_goal;
	}
	else{
		skipped_goal = false;
	}
	if(position.size() == 6){
		position.tail(3) = goal_marker;
	}
	last_goal = goal_marker;
	last_pos = position.head(3);
	user_goal = goal_marker;
	#ifdef VISUALIZE
		//cv::line(thresh,cvPoint(x,y-20/(0.1+position(2))),cvPoint(x,y+20/(0.1+position(2))),cv::Scalar(255),2,8);
		//cv::line(thresh,cvPoint(x-20/(0.1+position(2)),y),cvPoint(x+20/(0.1+position(2)),y),cv::Scalar(255),2,8);

		// Draw Arm Pos
		cv::Scalar pos_color(0,255,255);
		cv::line(small_imgColor,cvPoint(x/scale,y/scale-20/(0.1+position(2))),
				 cvPoint(x/scale,y/scale+20/(0.1+position(2))),pos_color,2,8);	
		cv::line(small_imgColor,cvPoint(x/scale-20/(0.1+position(2)),y/scale),
				 cvPoint(x/scale+20/(0.1+position(2)),y/scale),pos_color,2,8);

		// Draw Goal Pos
		// Fit to new resolution
		goal(0) /= scale;
		goal(1) /= scale;
		cv::Scalar g_color(goal_color(0),goal_color(1),goal_color(2));
		cv::line(small_imgColor,cvPoint(goal(0),goal(1)-20/(0.1+goal(2))),
				 cvPoint(goal(0),goal(1)+20/(0.1+goal(2))),g_color,2,8);	
		cv::line(small_imgColor,cvPoint(goal(0)-20/(0.1+goal(2)),goal(1)),
				 cvPoint(goal(0)+20/(0.1+goal(2)),goal(1)),g_color,2,8);
		if(goal.size() == 6){
			goal(3) /= scale;
			goal(4) /= scale;
			cv::Scalar g_color(goal_color(0),goal_color(1),goal_color(2));
			cv::line(small_imgColor,cvPoint(goal(3),goal(4)-20/(0.1+goal(5))),
					 cvPoint(goal(3),goal(4)+20/(0.1+goal(5))),g_color,2,8);	
			cv::line(small_imgColor,cvPoint(goal(3)-20/(0.1+goal(5)),goal(4)),
					 cvPoint(goal(3)+20/(0.1+goal(5)),goal(4)),g_color,2,8);
		}

		// Draw Goal Marker
		goal_marker(0) /=scale;
		goal_marker(1) /= scale;
		cv::line(small_imgColor,cvPoint(goal_marker(0),
				 goal_marker(1)-20/(0.1+goal_marker(2))),
				 cvPoint(goal_marker(0),
				 goal_marker(1)+20/(0.1+goal_marker(2))),
				 cv::Scalar(0,100,0),2,8);	
		cv::line(small_imgColor,cvPoint(goal_marker(0)-20/(0.1+goal_marker(2)),
				 goal_marker(1)),
				 cvPoint(goal_marker(0)+20/(0.1+goal_marker(2)),
				 goal_marker(1)),cv::Scalar(0,100,0),2,8);

		cv::imshow("Visualization",small_imgColor);
		video_writer.write(small_imgColor);
		int c=cv::waitKey(10);
	#endif
	thresh.release();
	hsv_imgColor.release();
	small_imgColor.release();
}

void InputKinect::iGrabImages()
{
	if (!isInit())
		std::cout << "not init" << std::endl;

	update();

	/*saveCvMat("ImgDepth.cvm", m_imgDepth);
	saveCvMat("Img3d.cvm", m_img3d);*/
}
#endif