#include "GPR_inc_multi_Group.h"
#include <vector>
#include <iostream>

using namespace Eigen;

GPR_inc_multi_Group::GPR_inc_multi_Group(int dim_outt, int max_GPRss, 
					int max_sizee, double max_distt, VectorXd *hyperr,
					int num_pred,bool predict_variance):
					GPR_inc_Group(max_GPRss, max_sizee, max_distt, hyperr,
					num_pred), dim_out(dim_outt),
					print_full(false){
	for(int i=0; i<max_GPRss; i++){
		GPRs.push_back(GPR_inc_multi(hypers,max_size,dim_out,
									 predict_variance));
	}
}

void GPR_inc_multi_Group::inc_learn(const VectorXd &observation, 
								    const VectorXd &target, bool substitute){
	if(GPRs_number == 0){
		GPRs_number++;
		GPRs[GPRs_number-1].inc_learn(observation, target);
		return;
	}
	
	VectorXd distances(GPRs_number);
	// The higher the distance measure, the closer the model
	for(int i=0; i<GPRs_number; i++){
		VectorXd center;
		GPRs[i].get_center(center);
		distances(i) = GPR::kernel(observation,center,hypers);
	}

	if(distances.maxCoeff() < max_dist){
		if(GPRs_number < max_GPRs){
			GPRs_number++;
			GPRs[GPRs_number-1].inc_learn(observation, target);
			return;
		}
		else{
			int debugMarker = 0;
			// if model too far away but max_GPRs reached, 
			// learn with closest model
		}
	}
	// Closest local model
	int max_index;
	double max_value = 1;
	distances.maxCoeff(&max_index);
	if(substitute){
		if(GPRs[max_index].full()){
			int del_obs = GPRs[max_index].max_covar_obs();
			GPRs[max_index].substitute(observation,target,del_obs);
		}
		else{
			GPRs[max_index].inc_learn(observation,target);
		}
	}
	else{
		while((max_value > 0) && (GPRs[max_index].full())){
			distances(max_index) = 0;
			max_value = distances.maxCoeff(&max_index);
		}
		if(max_value != 0){
			GPRs[max_index].inc_learn(observation,target);
		}
		if(max_value == 0){
			//std::cout << "Current GPRs Full" << std::endl;
		}
	}

	if(!print_full){
		RowVectorXi sizes(GPRs_number);
		for(int i=0; i<GPRs_number; i++){
			sizes(i) = GPRs[i].size();
			if(GPRs[i].full()){
				print_full = true;
			}
		}
		if(print_full){
			std::cout << std::endl << "First GPR full: "
					<< sizes << std::endl;
		}
	}
}

double GPR_inc_multi_Group::predict(const VectorXd &observation, 
								  VectorXd &prediction){
	int num_pred;
	if(GPRs_number < num_predictions){
		num_pred = GPRs_number;
	}
	else{
		num_pred = num_predictions;
	}
	std::vector<VectorXd> predictions(num_pred);
	VectorXd distances_all(GPRs_number);
	VectorXd distances_pred(num_pred);
	for(int i=0; i<GPRs_number; i++){
		VectorXd center;
		GPRs[i].get_center(center);
		distances_all(i) = GPR::kernel(observation,center,hypers);		
	}
	double variance = 0;
	for(int i=0; i<num_pred; i++){
		int max_index;
		distances_pred(i) = distances_all.maxCoeff(&max_index);
		variance += GPRs[max_index].predict(observation, predictions[i]) 
					* distances_pred(i);
		distances_all(max_index) = 0;
	}
	prediction = VectorXd::Zero(dim_out);
	for(int j=0; j<num_pred; j++){
		prediction += predictions[j]*distances_pred(j);
	}

	prediction.array() /= distances_pred.sum();
	variance /= distances_pred.sum();
	return variance / 3.0;
}

void GPR_inc_multi_Group::estimate_pred_time(
										boost::posix_time::microseconds &time){
	boost::timer::cpu_timer timer;
	int times = 10;
	std::vector<MatrixXd> inv(times*num_predictions);
	std::vector<VectorXd> c1(times*num_predictions);
	std::vector<VectorXd> c2(times*num_predictions*max_size);
	for(int i=0; i<times*num_predictions; i++){
		inv[i] = MatrixXd::Random(max_size,max_size);
		c1[i] = VectorXd::Random((*hypers).size()-3);
		for(int j=0; j<max_size; j++){
			c2[i*j] = VectorXd::Random((*hypers).size()-3);
		}
	}
	timer.start();
	for(int i=0; i<times*num_predictions; i++){
		VectorXd covar(max_size);		
		for(int j=0; j<max_size; j++){
			covar(j) = GPR::kernel(c1[i],c2[i*j],hypers);
		}
		RowVectorXd tmp = covar.transpose()*inv[i];
		for(int j=0; j<dim_out; j++){
			VectorXd mult = VectorXd::Random(max_size);
			tmp*mult;
		}
	}
	boost::posix_time::microseconds tmp((timer.elapsed().wall/1000)/times);
	time = tmp;
}

void GPR_inc_multi_Group::print_GPR_sizes(std::string str){
		RowVectorXi sizes(GPRs_number);
		for(int i=0; i<GPRs_number; i++){
			sizes(i) = GPRs[i].size();
		}
		std::cout << std::endl << str
			<< sizes <<  " Sum: " << sizes.sum() << std::endl;
}
