#ifndef GPR_INC_H
#define GPR_INC_H

#include "Eigen/Dense"
#include "GPR.h"

using Eigen::VectorXd;

/// <summary>GPR with incremental learning</summary>
class GPR_inc : public GPR{
	void sherman_morrison(const VectorXd &u, const VectorXd &v);
protected:
	int max_size;
	VectorXd center;
public:
	/// <param name="max_size">Maximal number of observations</param>
	GPR_inc(VectorXd *hypers, int max_size);
	/// <summary>Updates covariance matrix and inverse with the new 
	/// observation. Runtime for inversion is O(N^2)</summary>
	/// <param name="obs">Rowvector with the new observation</param>
	/// <param name="target">Targetvalue for the observation</param>
	void inc_learn(const VectorXd &obs, const double target);
	/// <param name="center">Return value: mean of all observations</param>
	void get_center(VectorXd &center) const;
	/// <returns>Max_size reached</returns>
	bool full() const;
	/// <returns>The observation with highest covariances</returns>
	int max_covar_obs() const;
	/// <summary>Substitutes and old observation with a new one according to
	/// the covariance of the old one</summary>
	/// <param name="del_obs">The index of the observation to be deleted.
	/// max_covar_obs can be used to obtain such an index</param>
	void substitute(const VectorXd &obs, const double target, int del_obs);
};

#endif