/* -*- Mode: C++ -*- */
/* shared/parse.h
 * CMUnited99 (shared code for on-line coach, off-line coach, and off-line trainer)
 * Patrick Riley <pfr+@cs.cmu.edu>
 * Computer Science Department
 * Carnegie Mellon University
 * Copyright (C) 1999 Patrick Riley
 *
 * CMUnited-99 was created by Peter Stone, Patrick Riley, and Manuela Veloso
 *
 * You may copy and distribute this program freely as long as you retain this notice.
 * If you make any changes or have any comments we would appreciate a message.
 */

/* shared/parse.h contains definitions for the parsing routines.
   These routines parse messages passed to the coach/trainer, not to clients
   The information is put into a PositionInfo structure */

#ifndef _PARSE_H_
#define _PARSE_H_

#include "MemPosition.h"

SenseType Parse (char *SensoryInfo, PositionInfo* MemPos);

#endif
