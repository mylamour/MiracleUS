/* -*- Mode: C++ -*- */

/* coach/MemSetplay.h
 * CMUnited99 (code for on-line/off-line coach)
 * Patrick Riley <pfr+@cs.cmu.edu>
 * Computer Science Department
 * Carnegie Mellon University
 * Copyright (C) 1999 Patrick Riley
 *
 * CMUnited-99 was created by Peter Stone, Patrick Riley, and Manuela Veloso
 *
 * You may copy and distribute this program freely as long as you retain this notice.
 * If you make any changes or have any comments we would appreciate a message.
 */

/* this file contains definitions for the on-line coaching of set-plays */

#ifndef _SETPLAY_H_
#define _SETPLAY_H_

#include <ostream.h>
#include "MemPosition.h"

class SetplayInfo : public PositionInfo
{
 public:

  Bool Initialize();
  
  void SetplaySightHandler(void);
  void SetplayPlayerSoundHandler(void);

  TeamSide MySide;

private:

};


#endif



