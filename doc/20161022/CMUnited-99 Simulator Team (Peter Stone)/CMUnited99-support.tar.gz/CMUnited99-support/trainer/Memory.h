/* -*- Mode: C++ -*- */

/* trainer/MemOption.h
 * CMUnited99 (code for off-line trainer)
 * Patrick Riley <pfr+@cs.cmu.edu>
 * Computer Science Department
 * Carnegie Mellon University
 * Copyright (C) 1999 Patrick Riley
 *
 * CMUnited-99 was created by Peter Stone, Patrick Riley, and Manuela Veloso
 *
 * You may copy and distribute this program freely as long as you retain this notice.
 * If you make any changes or have any comments we would appreciate a message.
 */

/* this file contains the top level Memory structure */

#ifndef _MEMORY_H_
#define _MEMORY_H_

#include "MemTrain.h"

class Memory : public TrainingInfo 
{
public:
  Bool Initialize();
} ;


#endif
