/* -*- Mode: C++ -*- */

/* trainer/TMshot.h
 * CMUnited99 (code for off-line trainer)
 * Patrick Riley <pfr+@cs.cmu.edu>
 * Computer Science Department
 * Carnegie Mellon University
 * Copyright (C) 1999 Patrick Riley
 *
 * CMUnited-99 was created by Peter Stone, Patrick Riley, and Manuela Veloso
 *
 * You may copy and distribute this program freely as long as you retain this notice.
 * If you make any changes or have any comments we would appreciate a message.
 */

/* this is a sample training module. See the README for details about this program */


/* this is the training module for the shot behavior*/

#ifndef _TMSHOT_H_
#define _TMSHOT_H_

#include "types.h"
#include "data.h"
#include "MemTrain.h"

class TMShot : public TrainingModule
{
 public:
  static const char* Name;
  
  Bool Initialize();
  void InitializeEpochController(EpochController* pEC);
  void NewSightHandler();

  void LogHeader(EpochController* pEC);
  void LogPerformance(EpochController* pEC);
  void ResetForEpoch();

private:
  int num_shots;
  int num_goals;
  int num_saves;
  int num_failed;

  float starting_dist;

  int curr_shot_time;
  int time_not_kickable;
  
  Bool should_reset;
  
  //void ResetBallAndPlayers();
  void IncrementDist();
  
} ;

#endif
