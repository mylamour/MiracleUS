/* -*- Mode: C++ -*- */

/* trainer/TMgame.h
 * CMUnited99 (code for off-line trainer)
 * Patrick Riley <pfr+@cs.cmu.edu>
 * Computer Science Department
 * Carnegie Mellon University
 * Copyright (C) 1999 Patrick Riley
 *
 * CMUnited-99 was created by Peter Stone, Patrick Riley, and Manuela Veloso
 *
 * You may copy and distribute this program freely as long as you retain this notice.
 * If you make any changes or have any comments we would appreciate a message.
 */

/* this is a sample training module. See the README for details about this program */

/* this is the training module for the game behavior- just makes sure the ball
   doesn't get stuck, not moving for long periods of time
   This is useful for running unattneded games */

#ifndef _TMGAME_H_
#define _TMGAME_H_

#include "types.h"
#include "data.h"
#include "MemTrain.h"

class TMGame : public TrainingModule
{
 public:
  static const char* Name;
  
  Bool Initialize();
  void InitializeEpochController(EpochController* pEC);
  void NewSightHandler();
  void ShutdownNotification();

  void LogHeader(EpochController* pEC);
  void LogPerformance(EpochController* pEC);
  void ResetForEpoch();

private:
  int time_ball_not_moving;
  
} ;

#endif
