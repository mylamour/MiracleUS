/* -*- Mode: C++ -*- */

/* trainer/Memory.C
 * CMUnited99 (code for off-line trainer)
 * Patrick Riley <pfr+@cs.cmu.edu>
 * Computer Science Department
 * Carnegie Mellon University
 * Copyright (C) 1999 Patrick Riley
 *
 * CMUnited-99 was created by Peter Stone, Patrick Riley, and Manuela Veloso
 *
 * You may copy and distribute this program freely as long as you retain this notice.
 * If you make any changes or have any comments we would appreciate a message.
 */

/* this file contains the top level Memory structure */

#include "Memory.h"

Bool Memory::Initialize()
{
  return (Bool)
    (PositionInfo::Initialize() &&
    TrainingInfo::Initialize());
}
