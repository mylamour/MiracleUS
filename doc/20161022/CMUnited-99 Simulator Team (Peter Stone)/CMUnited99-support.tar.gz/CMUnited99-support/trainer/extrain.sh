#! /bin/csh -f

set num_epochs = 70
set count = 0
while ($count < $num_epochs)
  echo Beginning epoch $count
  #start server
  echo Starting Server....
  (cd sserver-5.18/server; soccerserver -file server.conf -coach_w_referee &)
  sleep 2
  #start client
  echo Starting Client....
  (cd peterclient; peterclient -file server.conf -file client.conf &)
  sleep 3
  #start trainer in foreground!
  echo Starting Trainer....
  (cd trainer; trainer -file server.conf -file trainer.conf -epochs_to_run 1 -ep
och_start $count)
  #kill server
  echo Trainer Exited, Killing Server....
  kill `ps ax | grep soccerserver | grep -v grep | awk '{print $1}'`

  #wait for client to die
  sleep 5
  echo Client should have exited
  
  @ count = $count + 1
end
