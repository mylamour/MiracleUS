/* -*- Mode: C++ -*- */

/* trainer/TMhardkick2.C
 * CMUnited99 (code for off-line trainer)
 * Patrick Riley <pfr+@cs.cmu.edu>
 * Computer Science Department
 * Carnegie Mellon University
 * Copyright (C) 1999 Patrick Riley
 *
 * CMUnited-99 was created by Peter Stone, Patrick Riley, and Manuela Veloso
 *
 * You may copy and distribute this program freely as long as you retain this notice.
 * If you make any changes or have any comments we would appreciate a message.
 */

/* this is a sample training module. See the README for details about this program */

/* this is the training module for the hardkick2 behavior */

#include <unistd.h>
#include <iostream.h>
#include <fstream.h>
#include <iomanip.h>
#include "client.h"
#include "utils.h"
#include "TMhardkick2.h"
#include "MemPosition.h"

/* epochs for this behavior are where the ball starts around the players so
   that we can identify where the absolute best kicking location is around a
   player */

const char* TMHardKick2::Name = "HardKick2";

Bool TMHardKick2::Initialize()
{
  ChangeMode(PM_Play_On);
  MoveBall(10, 10); /* so we can move the player to middle */

  time_out_of_range = Mem->TP_hardkick_max_time_out+1;
  curr_kick_time = 0;

  starting_angle = -180;
  starting_per   = 0.0;
  /* now we need to adavance our values to the correct place for the
     given epoch start */
  for (int i = 0; i < Mem->TP_epoch_start; i++)
    IncrementPlace();


  sdsKickVel.SetPrecision(4);
  sdsKickTime.SetPrecision(4);
  sdsKickAngle.SetPrecision(4);

  cout << "HardKick2 Training module" << endl;
  
  return TRUE;
}

/* ranges to check:
   The ranges to check are where the trainer starts the ball
   And player ang 0-180, by 20
   */
void TMHardKick2::InitializeEpochController(EpochController* pEC)
{
  pEC->num_vars = 1;
  strcpy(pEC->option_names[0], "hardest_kick_player_ang");
  pEC->option_types[0] = TVT_Int;

  int epochs_for_place = RoundToInt(ceil((360 / Mem->TP_hardkick_start_ang_inc)) *
				    ((1.0 / Mem->TP_hardkick_start_per_inc) + 1));
  pEC->num_epochs = 0;
  for (int ang=0;
       ang <=180;
       ang += Mem->TP_hardkick_player_ang_inc) {
    for (int i=0;
	 i < epochs_for_place;
	 i++) {
      if (pEC->num_epochs >= pEC->MAX_NUM_EPOCHS) {
	my_error("Too many epochs wanted for hardkick!");
	return;
      }
      pEC->training_epochs[pEC->num_epochs][0].i = ang;
      pEC->num_epochs++;
    }
  }


}


/* Does the following:
   -insures the player is at (0,0)
   -if the ball is out of kickable range for xx cycles,
     puts it next to player, at an angle determined by starting_angle, which
     goes around player
   -records angle of kicked ball
   -records velocity immediately on leaving kickable area
   -records angle just before reset
   */
/* Assumes: -The relevant player is the first one on the left team */
void TMHardKick2::NewSightHandler()
{
  
  pPlayerInfo pPI = Mem->GetPlayer(TS_Left, 1);
  if (pPI == NULL) {
    cout << "Trainer: Waiting for player to connect" << endl;
    return; /* no player yet */
  }

  if (Mem->GetPlayMode() != PM_Play_On)
    ChangeMode(PM_Play_On);
  
  if (pPI->pos != Vector(0,0)) {
    MovePlayer(TS_Left, 1, 0, 0);
  }

  
  pBallInfo pBI = Mem->GetBall();
  if (pBI->pos.dist(pPI->pos) > Mem->SP_kickable_area) {
    /* out of kickable range */
    time_out_of_range++;
    if (time_out_of_range == 1) {
      /* this is the first cycle out, so record the velocity and time */
      if (!Mem->TP_use_epochs)
	cout << "Kick with vel: " << pBI->vel.mod()
	     << "\ttime: " << curr_kick_time << endl;
      sdsKickVel.AddPoint(pBI->vel.mod());
      sdsKickTime.AddPoint((float)curr_kick_time);

    }
    if (time_out_of_range >= Mem->TP_hardkick_max_time_out) {
      /* about to reset, so record angle */
      sdsKickAngle.AddPoint(pBI->pos.dir());
      ResetBall();
    }
  } else {
    if (++curr_kick_time > Mem->TP_hardkick_max_kick_time) {
      /* player has been trying to kick for a long time, give up */
      ChangeMode(PM_Play_On); /* make sure we're in the right mode */
      ResetBall();
    }
    
  }
  
}

void TMHardKick2::ResetBall()
{
  time_out_of_range = 0;
  curr_kick_time = 0;

  float dist = Mem->SP_player_size + Mem->SP_ball_size +
    starting_per * Mem->SP_kickable_margin;
  MoveBall(dist * Cos(starting_angle), dist * Sin(starting_angle));
  //cout << "Moving ball to ang: " << starting_angle << "\tper: " << starting_per << endl;
  time_out_of_range = 0;
  curr_kick_time = 0;
}

void TMHardKick2::LogHeader(EpochController* pEC)
{
  ofstream outfile;

  outfile.open(Mem->TP_training_log_fn, ios::out);
  if (!outfile) {
    my_error("Could not open data file: %s", Mem->TP_training_log_fn);
    return;
  }
    
  /* write header */
  outfile << "Training Info for HardKick2 behavior" << endl;
  outfile << "Format: ";
  pEC->WriteOptionNames(outfile);
  outfile << "starting_angle starting_per ";
  outfile << "num_kicks ";
  outfile << "KickVel: mean var stdev ";
  outfile << "KickTime: mean var stdev ";
  outfile << "KickAngle: mean var stdev " << endl;
  outfile << "Epoch Length is: " << Mem->TP_epoch_length << endl;
}


void TMHardKick2::LogPerformance(EpochController* pEC)
{
  ofstream outfile;

  outfile.open(Mem->TP_training_log_fn, ios::app);
  if (!outfile) {
    my_error("Could not open data file: %s", Mem->TP_training_log_fn);
    return;
  }

  pEC->WriteCurrentOptionValues(outfile);
  outfile << starting_angle << '\t' << setprecision(1) << starting_per << '\t';
  outfile << '\t' << sdsKickVel.GetNumPoints() << '\t';
  sdsKickVel.WriteCompactInfoToFile(outfile, FALSE);
  outfile << '\t';
  sdsKickTime.WriteCompactInfoToFile(outfile, FALSE);
  outfile << '\t';
  sdsKickAngle.WriteCompactInfoToFile(outfile, FALSE);
  outfile << endl;
  outfile.close();

  // this is a little weird of a place to do this, but hey who cares
  IncrementPlace();
}

void TMHardKick2::ResetForEpoch()
{
  /* reset the counting values */
  sdsKickVel.Reset();
  sdsKickTime.Reset();
  sdsKickAngle.Reset();
  /* reset the ball */
  ResetBall();
}

void TMHardKick2::IncrementPlace()
{
  starting_angle += Mem->TP_hardkick_start_ang_inc;
  if (starting_angle == 180) {
    /* advance starting percent */
    starting_per += Mem->TP_hardkick_start_per_inc;
    if (starting_per > 1.01) /* watch rounding error */
      starting_per = 0.0;
    starting_angle = -180;
  }
  //cout << "Starting angle: " << starting_angle
  //<< "\tper: " << starting_per << endl;  
}

