#!/bin/bash
TEAM=ODENS
AGENT_BINARY="odens3d"
BINARY_DIR="."
NUM_PLAYERS=11
PORT=3100
if [ $# -eq 0 ]
then
  host=localhost
else
  host=$1
fi
log=log
#log=log-$AGENT_BINARY-`date +%m%d%H%M`
#mkdir $log
killall -9 "$AGENT_BINARY" &> /dev/null
for ((i=1;i<=$NUM_PLAYERS;i++)); do
	echo "Running agent No. $i"
	case $i in
	1|2|3|4|8|9) type=3;;
	7|10) type=1;;
	5|6|11) type=0;;
	esac
	echo type=$type
	"$BINARY_DIR/$AGENT_BINARY" --mynum=$i --team=$TEAM  --host=$host --port=$PORT --conf=conf-$type.xml  > $log/stdout$i 2> $log/stderr$i &
	sleep 1
done
