#!/bin/bash

killall -9 ./odens3d &> /dev/null
