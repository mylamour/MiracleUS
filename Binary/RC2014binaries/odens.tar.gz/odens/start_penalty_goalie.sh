#!/bin/bash
TEAM=ODENS
AGENT_BINARY="odens3d"
BINARY_DIR="."
PORT=3100
if [ $# -eq 0 ]
then
  host=localhost
else
  host=$1
fi
log=log
#log=log-$AGENT_BINARY-`date +%m%d%H%M`
#mkdir $log
type=0
i=1
killall -9 "$AGENT_BINARY" &> /dev/null
"$BINARY_DIR/$AGENT_BINARY" --mynum=$i --team=$TEAM  --host=$host --port=$PORT --conf=conf-$type.xml > $log/stdout$i 2> $log/stderr$i&
