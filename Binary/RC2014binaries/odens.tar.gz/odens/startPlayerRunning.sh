#!/bin/bash
TEAM=ODENS
AGENT_BINARY="odens3d"
BINARY_DIR="."
NUM_PLAYERS=11
PORT=3100
host=localhost
if [ $# -ge 2 ]
then
  PORT=$2
fi
if [ $# -ge 1 ]
then
  host=$1
fi
log=log
#log=log-$AGENT_BINARY-`date +%m%d%H%M`
#mkdir $log
type=1
i=11
killall -9 "$AGENT_BINARY" &> /dev/null
"$BINARY_DIR/$AGENT_BINARY" --runchallenge --mynum=$i --team=$TEAM  --host=$host --port=$PORT --conf=conf-$type.xml  > $log/stdout$i 2> $log/stderr$i &
#"$BINARY_DIR/$AGENT_BINARY" --runchallenge --mynum=$i --team=$TEAM  --host=$host --port=$PORT --conf=conf-$type.xml
