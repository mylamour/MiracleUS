#!/bin/bash

killall -9 robocanes


