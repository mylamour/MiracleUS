#!/bin/bash
HOST=$1
PORT=$2
binary="./robocanes"

#-----
#default values
if [ "$HOST" == "" ]; then HOST="127.0.0.1"; fi
if [ "$PORT" == "" ]; then PORT="3100"; fi

#-----
#start agent

#./kill.sh

echo Starting goalie...

$binary -c SimSparkConnection.ip=$HOST \
        -c SimSparkConnection.port=$PORT \
        -c SimSparkConnection.unum=1  \
        -c Goalie.penaltymode=1  \
        -c SimSparkConnection.teamname=RoboCanesGoalie  \
   > /dev/null 2> /dev/null &

echo done.

