#!/bin/bash

source common.sh

BINARY_DIR=$PWD
AGENT_BINARY=rcssagent3d-l3m

TEAM_NAME="l3m-sim"

LOG_ON="0"

#DATE=`date '+%T'`
DATE="NO_DATE"

MY_LOG_DIR=/tmp/$TEAM_NAME-$DATE

FIRST_PLAYER_ID=1
LAST_PLAYER_ID=11
NUM_PLAYERS=$(($LAST_PLAYER_ID - $FIRST_PLAYER_ID + 1))

### !!! SERVER_IP !!!
SERVER_IP=127.0.0.1
#SERVER_IP=192.168.0.13

if [ "$#" = "1" ]; then
  SERVER_IP=$1
fi

if [ $LOG_ON = "1" ]; then
  if [ ! -d "$MY_LOG_DIR" ]; then
    `mkdir $MY_LOG_DIR`
  fi
fi

### !!! if LIBPATH is different !!!
export LD_LIBRARY_PATH=~/lib/simspark:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=~/lib/:$LD_LIBRARY_PATH
#export LD_LIBRARY_PATH=/usr/lib64/simspark:/usr/lib/simspark:$LD_LIBRARY_PATH

for ((i=$FIRST_PLAYER_ID;i<=$LAST_PLAYER_ID;i++)); do
  echo "Running agent No. $i"
  if [ $LOG_ON = "1" ]; then
    ./run.sh $BINARY_DIR/$AGENT_BINARY --host=$SERVER_IP --num=$i --teamsize=$NUM_PLAYERS --team=$TEAM_NAME 2>$MY_LOG_DIR/log-l3m-sim-$i-$DATE &
  fi
  if [ $LOG_ON = "0" ]; then
    ./run.sh $BINARY_DIR/$AGENT_BINARY --host=$SERVER_IP --num=$i --teamsize=$NUM_PLAYERS --team=$TEAM_NAME 2>/dev/null &
  fi
  sleep 3
done
