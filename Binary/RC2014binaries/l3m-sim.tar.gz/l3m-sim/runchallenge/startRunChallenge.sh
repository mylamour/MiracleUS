#!/bin/bash

COMMON_RAND="common_rand"
MIN_RAND=1
MAX_RAND=2
RAND_NUMBER=$[($RANDOM % ($[$MAX_RAND - $MIN_RAND] + 1)) + $MIN_RAND]
echo $RAND_NUMBER > $COMMON_RAND
echo $RAND_NUMBER


BINARY_DIR=$PWD
AGENT_BINARY=rcssagent3d-l3m
#AGENT_BINARY=rcssagent3d-l3m-NAO-std
#AGENT_BINARY=rcssagent3d-l3m-NAO-fwd-opti

TEAM_NAME="l3m-sim"

LOG_ON="1"
#LOG_ON="0"

DATE=`date '+%T'`
#DATE="NO_DATE"

#MY_LOG_DIR=/tmp/$TEAM_NAME-$DATE
#MY_LOG_FILE=/tmp/$TEAM_NAME-$DATE/log-l3m-sim-$DATE
MY_LOG_DIR=/tmp/$TEAM_NAME
MY_LOG_FILE=/tmp/$TEAM_NAME/log-l3m-sim

FIRST_PLAYER_ID=2
LAST_PLAYER_ID=2
NUM_PLAYERS=$(($LAST_PLAYER_ID - $FIRST_PLAYER_ID + 1))

### !!! SERVER_IP !!!
SERVER_IP=127.0.0.1
#SERVER_IP=192.168.0.13

if [ "$#" = "1" ]; then
  SERVER_IP=$1
fi

if [ $LOG_ON = "1" ]; then
  if [ ! -d "$MY_LOG_DIR" ]; then
    `mkdir $MY_LOG_DIR`
  fi
fi

### !!! if LIBPATH is different !!!
export LD_LIBRARY_PATH=/opt/spark-0.6.8.1/lib/simspark:$LD_LIBRARY_PATH
#export LD_LIBRARY_PATH=/usr/lib64/simspark:/usr/lib/simspark:$LD_LIBRARY_PATH

if [ $LOG_ON = "1" ]; then
    $BINARY_DIR/$AGENT_BINARY --host=$SERVER_IP --port=3110 --num=1 --llc=$NUM_PLAYERS --side=0 --team=$TEAM_NAME 2>$MY_LOG_FILE-$i
fi
if [ $LOG_ON = "0" ]; then
    $BINARY_DIR/$AGENT_BINARY --host=$SERVER_IP --port=3110 --num=1 --llc=$NUM_PLAYERS --side=0 --team=$TEAM_NAME 2>/dev/null
fi



