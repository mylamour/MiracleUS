vec2 = {}
vec2.__index = vec2

setmetatable(vec2, {
    __call = function (cls, ...) return cls.new(cls, ...) end,
})

function vec2.new(self, x, y)
  local self = setmetatable({}, vec2)
  self.x = x or 0
  self.y = y or 0
  return self
end

function vec2.__tostring(self)
    return self.x .. " " .. self.y
end

function vec2.__add(self, v)
    return vec2(self.x + v.x, self.y + v.y)
end

function vec2.__sub(self, v)
    return vec2(self.x - v.x, self.y - v.y)
end

function vec2.__mul(self, s)
    return vec2(self.x * s, self.y * s)
end

function vec2.__div(self, s)
    return vec2(self.x / s, self.y / s)
end

function vec2.__unm(self)
    return vec2(-self.x, -self.y)
end

function vec2:copy()
    return vec2(self.x, self.y)
end

function vec2:get()
    return self.x, self.y
end

function vec2:norm()
    return math.sqrt(self.x * self.x + self.y * self.y)
end

function vec2:normalize()
    local n = self:norm()
    self.x = self.x / n
    self.y = self.y / n
    return self
end

function distance(v1, v2)
    local tmp = v1 - v2
    return tmp:norm()
end

function dot(v1, v2)
    return v1.x * v2.x + v1.y * v2.y
end

function global_angle(v)
    local tmp = v:copy()
    tmp:normalize()
    local cos = dot(v, vec2(0, -1))
    local sin = dot(vec2(1, 0), v)
    return -math.atan2(cos, sin) * 180 / math.pi;
end

function rotate(v, o, angle)
    local p = v - o
    local sin = math.sin(angle * math.pi / 180);
    local cos = math.cos(angle * math.pi / 180);
    return vec2(p.x * cos - p.y * sin, p.x * sin + p.y * cos) + o
end

function clamp(p, min, max)
    ret = p:copy()
    if ret.x < min.x then ret.x = min.x end
    if ret.y < min.y then ret.y = min.y end
    if ret.x > max.x then ret.x = max.x end
    if ret.y > max.y then ret.y = max.y end
    return ret
end
