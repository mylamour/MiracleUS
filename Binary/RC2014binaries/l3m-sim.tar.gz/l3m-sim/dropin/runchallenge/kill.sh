#!/bin/bash

killall -9 "rcssagent3d-l3m" 

