--
-- att.lua
-- commmon.xml
--

require "l3mlib-math"

local input = vec2(formation.inputX, formation.inputY)
local ball = vec2(formation.ballX, formation.ballY)
local goal = vec2(15, 0)
local angle = global_angle(goal - input)
local nb = formation.nbPlayers - 1

function progress(k, f)
    return math.exp(k * f - f)
end

function interest(points, ref)
    local d = {}
    for i, p in pairs(points) do
        d[i] = distance(p, ref)
    end
    return math.min(unpack(d))
end

for n = 0, nb do

    local p = vec2(formation["playerX_" .. n], formation["playerY_" .. n])
    local group = p.x

    if group < -13 then

    elseif group < -5 then

    elseif group < 0 then
        local front = (goal.x - p.x)
        p.x =  p.x + front * (progress(1 - math.abs(input.x - goal.x) / 15, 3))
        if p.x > 7 then p.x = 7 end
        p.y = (input - p).y
    else
        p = p + (input - ball)
        p = rotate(p, input, angle)
    end

    p = clamp(p, vec2(-15, -10), vec2(15, 10))
    formation["playerX_" .. n], formation["playerY_" .. n] = p:get()
end
