--
-- att_3_3.lua
-- strategy_3_3.xml
--

function sign(i)
    if i < 0 then return -1 end
    if i > 0 then return 1 end
    return 0
end

ix = formation.inputX
iy = formation.inputY
bx = formation.ballX
by = formation.ballY
vx = ix - bx
vy = iy - by
nb = formation.nbPlayers - 1

for n = 0, nb do
    x = formation["playerX_" .. n] + vx
    y = formation["playerY_" .. n] + vy
    sin = math.sin(vx / 14 * math.pi) * 3
    coef = sign(y - iy)
    formation["playerX_" .. n] = x
    formation["playerY_" .. n] = y
    if coef ~= 0 then
        formation["playerY_" .. n] = y + (sin * coef)
    end
end
