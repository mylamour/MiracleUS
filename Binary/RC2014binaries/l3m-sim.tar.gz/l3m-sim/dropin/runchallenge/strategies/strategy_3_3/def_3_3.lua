--
-- def_3_3.lua
-- strategy_3_3.xml
--

ix = formation.inputX
iy = formation.inputY
bx = formation.ballX
by = formation.ballY
vx = ix - bx
vy = iy - by
d = math.sqrt(vx * vx) / 18
nb = formation.nbPlayers - 1

for n = 0, nb do
    x = formation["playerX_" .. n] + vx
    y = formation["playerY_" .. n] + vy
    formation["playerX_" .. n] = x + (ix - x) * d;
    formation["playerY_" .. n] = y + (iy - y) * d;
end
