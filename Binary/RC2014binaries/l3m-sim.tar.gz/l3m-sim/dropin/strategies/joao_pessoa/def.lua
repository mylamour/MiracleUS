--
-- def.lua
-- commmon.xml
--

require "l3mlib-math"

local input = vec2(formation.inputX, formation.inputY)
local ball = vec2(formation.ballX, formation.ballY)
local goal = vec2(-16, 0)
local angle = global_angle(input - goal)
local input_goal_distance = distance(input, goal)
local nb = formation.nbPlayers - 1

function progress(k, f)
    return math.exp(k * f - f)
end

function interest(points, ref)
    local d = {}
    for i, p in pairs(points) do
        d[i] = distance(p, ref)
    end
    return math.min(unpack(d))
end

for n = 0, nb do

    local p = vec2(formation["playerX_" .. n], formation["playerY_" .. n])
    local group = p.x
    local player_goal_distance = distance(p, goal)
    local player_input_distance = distance(p, goal)

    local rotate_coef = progress(1 - player_goal_distance / 15, 1.5)
    p = rotate(p, goal, angle * rotate_coef)

    if group < -8 then
        local back = (goal - p)
        local k = progress(1 - input_goal_distance / 15, 2.5)
        if k > 0.55 then k = 0.55 end
        p = p + (back * k)
    elseif group < -5 then
        local points = {
            vec2(-10, 7),
            vec2(-10, -7),
        }
        local dist = interest(points, input)
        local front = (input - p)
        local k = progress(1 - dist / 15, 1)
        if k > 0.65 then k = 0.65 end
        p = p + (front * k)
        local angle2 = -(angle * (progress(1 - dist / 15, 5) + 0.3))
        p = rotate(p, input, angle2)
        if distance(p, goal) < 5 then
            p = goal + ((p - goal):normalize() * (5 + 5 - distance(p, goal)))
        end
    else
        local player_input = input - p
        local player_goal = input - goal
        local corner_1 = vec2(0, 10)
        local corner_2 = vec2(0, -10)
        local icd_1 = distance(input, corner_1)
        local icd_2 = distance(input, corner_2)
        local input_corner_distance = math.min(icd_1, icd_2)
        local front = (input - p)
        local k = progress(1 - input_corner_distance / 15, 1)
        if k > 0.65 then k = 0.65 end
        p = p + (front * k)
        p = rotate(p, input, -angle * progress(1 - input_corner_distance / 15, 3))
    end

    p = clamp(p, vec2(-15, -10), vec2(15, 10))
    formation["playerX_" .. n], formation["playerY_" .. n] = p:get()
end
