#!/usr/bin/env bash

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -z "$LUA_PATH" ]]
then
    LUA_PATH="${SCRIPT_DIR%%/}/strategies/l3mlib-math.lua"
fi

LUA_PATH="$LUA_PATH" $@
