#!/bin/bash

./bahiart -u 1 -robot naotoe.xml -h $1 -p $2 >/dev/null 2>&1 &
