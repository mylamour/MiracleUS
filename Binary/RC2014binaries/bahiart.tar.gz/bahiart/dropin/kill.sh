#!/bin/bash
killall -9 bahiart
