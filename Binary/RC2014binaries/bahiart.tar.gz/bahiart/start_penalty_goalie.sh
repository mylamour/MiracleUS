#!/bin/bash
# BahiaRT 2013 binary

echo "Launch 1"
./bahiart -u 1 -g -h $1 >/dev/null 2>&1 &
sleep 1.0 
