#!/bin/bash

killall -9 MithrasAgent 


