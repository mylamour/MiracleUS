#!/bin/bash
#
# 
#
killall -9 MithrasAgent 

./MithrasAgent --number 1 --host $1 --type 1 > /dev/null &
sleep 1

