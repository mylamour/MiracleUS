#!/bin/bash
#
# 
#
killall -9 MithrasAgent 

cd run/

./MithrasAgent --number 1 --host $1 > /dev/null &

sleep 1
./MithrasAgent --number 2 --host $1 > /dev/null &

sleep 1
./MithrasAgent --number 3 --host $1 > /dev/null &
sleep 1
./MithrasAgent --number 6 --host $1 > /dev/null &
sleep 1
./MithrasAgent --number 5 --host $1 > /dev/null &
sleep 1
./MithrasAgent --number 4 --host $1 > /dev/null &
sleep 1
./MithrasAgent --number 7 --host $1 > /dev/null &
sleep 1
./MithrasAgent --number 8 --host $1 > /dev/null &
sleep 1
./MithrasAgent --number 9 --host $1 > /dev/null &
sleep 1
./MithrasAgent --number 10 --host $1 > /dev/null &
sleep 1
./MithrasAgent --number 11 --host $1 > /dev/null &

