#!/bin/bash
#
# 
#
killall -9 MithrasAgent 

./MithrasAgent --number 1 --host $1 --penalty 1 > /dev/null &
sleep 2
./MithrasAgent --number 10 --host $1 --penalty 1 > /dev/null &

