#!/bin/bash

BINARY=mono

killall -9 $BINARY

