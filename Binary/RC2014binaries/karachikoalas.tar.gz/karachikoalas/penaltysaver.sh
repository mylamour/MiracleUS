#!/bin/bash

BINARY=penaltysaver.exe


#killall -9 mono

#./$BINARY 1 $1 >stdout1 2>stderr1 &
mono penaltysaver.exe 1 $1 $2> log/stdout9 2>log/stderr9 &

