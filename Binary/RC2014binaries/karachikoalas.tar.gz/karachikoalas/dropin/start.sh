#!/bin/bash

#BINARY="mono karachikoalas.exe"

#Goalie=1
#LeftBack=2
#RightBack=3
#Striker=4
#LeftWing=5
#RightWing=6
#CenterBack=7
#MidFieldRight=8
#MidFieldLeft=9

# OLD: ./karachikoalas.exe $Goalie $1 >stdout1 2>stderr1 &
# NEW: mono karachikoalas.exe $Goalie $1 >stdout1 2>stderr1 &

#killall -9 mono

#sleep 5
sleep 1
mono karachikoalas.exe 1 $1 $2> log/stdout1 2>log/stderr1 &
sleep 1
mono karachikoalas.exe 2 $1 $2> log/stdout2 2>log/stderr2 &
#PID=$!
#sleep 5
sleep 1
mono karachikoalas.exe 3 $1 $2> log/stdout3 2>log/stderr3 &
sleep 1
mono karachikoalas.exe 4 $1 $2> log/stdout4 2>log/stderr4 &
sleep 1
mono karachikoalas.exe 5 $1 $2> log/stdout5 2>log/stderr5 &
sleep 1
mono karachikoalas.exe 6 $1 $2> log/stdout6 2>log/stderr6 &
sleep 1
mono karachikoalas.exe 7 $1 $2> log/stdout7 2>log/stderr7 &
sleep 1
mono karachikoalas.exe 8 $1 $2> log/stdout8 2>log/stderr8 &
sleep 1
mono karachikoalas.exe 9 $1 $2> log/stdout9 2>log/stderr9 &
sleep 1
mono karachikoalas.exe 10 $1 $2> log/stdout10 2>log/stderr10 &
sleep 1
mono karachikoalas.exe 11 $1 $2> log/stdout11 2>log/stderr11 &
sleep 1
#kill $PID
#sleep 1
#mono karachikoalas.exe 2 $1 $2> log/stdout2 2>log/stderr2 &

