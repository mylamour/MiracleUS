#!/bin/bash
#
# Kill Script for 3D Soccer Simulation
#

killall -9 hfutengine > /dev/null

