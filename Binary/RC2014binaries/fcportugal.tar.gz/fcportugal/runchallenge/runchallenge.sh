
cd /home/teams/fcportugal/runchallenge

export LD_LIBRARY_PATH=/home/teams/fcportugal/lib:$LD_LIBRARY_PATH

./fcpagent -u 4 -r 3 -h $1 -p $2 -t "FCPortugal" >/dev/null 2>&1 &



