#!/bin/bash
killall -9 fcpagent
killall -9 optAgent
killall -9 preCondLearn
killall -9 behaviorTest
killall -9 simspark
killall -9 rcssserver3d
killall -9 rcssmonitor3d 
#killall -9 roboviz
