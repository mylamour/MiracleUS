#!/bin/bash
# FC Portugal 3D 2014 binary

echo "Launch 1"
./fcpagent -u 1 -h $1 >/dev/null 2>&1 &
sleep 1.0 
