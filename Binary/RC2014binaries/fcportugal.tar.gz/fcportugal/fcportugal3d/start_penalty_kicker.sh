#!/bin/bash
# FC Portugal 3D 2014 binary

echo "Launch 11"
./fcpagent_kicker -u 11 -h $1 >/dev/null 2>&1 &
sleep 0.5
