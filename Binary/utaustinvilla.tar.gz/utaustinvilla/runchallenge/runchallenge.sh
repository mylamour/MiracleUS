#!/bin/bash

export LD_LIBRARY_PATH=./libs:$LD_LIBRARY_PATH

DIR="$( cd "$( dirname "$0" )" && pwd )" 
cd $DIR/..

./utaustinvilla --runchallenge --unum 2 --type 3 --host=$1 --port $2 &> /dev/null &
