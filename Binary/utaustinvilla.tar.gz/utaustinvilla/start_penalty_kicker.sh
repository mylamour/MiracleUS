#!/bin/bash
#
# IranOpen 2008 sample start script for 3D Simulation Competitions
#
team="UTAustinVilla-sh"
AGENT_BINARY=utaustinvilla
BINARY_DIR="."
LIBS_DIR="./libs"
export LD_LIBRARY_PATH=$LIBS_DIR:$LD_LIBRARY_PATH

#killall -9 $AGENT_BINARY

DIR="$( cd "$( dirname "$0" )" && pwd )" 
cd $DIR

"$BINARY_DIR/$AGENT_BINARY" --host=$1 --team $team --unum 2 --type 4 --pkshooter &> /dev/null &
#"$BINARY_DIR/$AGENT_BINARY" --host=$1 --team $team --unum 2 --type 4 --pkshooter > stdoutsh 2> stderrsh &

sleep 2
