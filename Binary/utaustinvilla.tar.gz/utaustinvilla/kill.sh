#!/bin/bash
#
# Kill script for 3D Simulation Competitions
#

# Kill agents
AGENT="utaustinvilla"
killall -9 $AGENT
sleep 1


