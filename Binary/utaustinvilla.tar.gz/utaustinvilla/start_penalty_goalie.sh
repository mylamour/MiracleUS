#!/bin/bash
#
# IranOpen 2008 sample start script for 3D Simulation Competitions
#
team="UTAustinVilla-gk"
AGENT_BINARY=utaustinvilla
BINARY_DIR="."
LIBS_DIR="./libs"
export LD_LIBRARY_PATH=$LIBS_DIR:$LD_LIBRARY_PATH

#killall -9 $AGENT_BINARY

DIR="$( cd "$( dirname "$0" )" && pwd )" 
cd $DIR

"$BINARY_DIR/$AGENT_BINARY" --host=$1 --team $team --unum 1 --pkgoalie &> /dev/null &
#"$BINARY_DIR/$AGENT_BINARY" --host=$1 --team $team --unum 1 --pkgoalie > stdoutgk 2> stderrgk &

sleep 2
