#!/bin/bash
#
# ChinaOpen 2014 sample kill script for 3D soccer simulation
#
killall -9 "strive3d" &> /dev/null

