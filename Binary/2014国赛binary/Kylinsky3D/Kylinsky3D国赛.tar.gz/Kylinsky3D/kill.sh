#!/bin/bash

killall -9 rcssserver3d &

killall -9 kylinsky
